<section>
    <header class="mb-3">
        <h5 class="account-section-title mb-1"><?php echo e(__('Hapus Akun')); ?></h5>
        <p class="account-section-desc mb-0">
            <?php echo e(__('Setelah akun dihapus, semua data terkait akan dihapus secara permanen. Silakan unduh data yang ingin Anda simpan sebelum menghapus akun.')); ?>

        </p>
    </header>

    <button type="button" class="btn btn-outline-danger fw-semibold mt-2" data-bs-toggle="modal" data-bs-target="#confirmUserDeletion">
        <?php echo e(__('Hapus Akun')); ?>

    </button>

    <div class="modal fade" id="confirmUserDeletion" tabindex="-1" aria-labelledby="confirmUserDeletionLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="border-radius: 20px;">
                <form method="post" action="<?php echo e(route('profile.destroy')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>

                    <div class="modal-body p-4">
                        <h5 class="mb-2" id="confirmUserDeletionLabel"><?php echo e(__('Yakin ingin menghapus akun Anda?')); ?></h5>
                        <p class="text-muted small">
                            <?php echo e(__('Setelah akun dihapus, semua data terkait akan dihapus secara permanen. Masukkan password Anda untuk mengonfirmasi.')); ?>

                        </p>

                        <div class="mt-3">
                            <label for="password" class="visually-hidden"><?php echo e(__('Password')); ?></label>
                            <input id="password" name="password" type="password"
                                   class="form-control <?php $__errorArgs = ['password', 'userDeletion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="<?php echo e(__('Password')); ?>">
                            <?php $__errorArgs = ['password', 'userDeletion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('Batal')); ?></button>
                        <button type="submit" class="btn btn-danger"><?php echo e(__('Hapus Akun')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if($errors->userDeletion->isNotEmpty()): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                new bootstrap.Modal(document.getElementById('confirmUserDeletion')).show();
            });
        </script>
    <?php endif; ?>
</section>
<?php /**PATH C:\Users\farha\hans-golfc\resources\views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>