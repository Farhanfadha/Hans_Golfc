<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChatMessage extends Model
{
    protected $fillable = [
        'chat_id',
        'sender_type',
        'message',
        'is_read_admin',
        'is_read_user',
    ];

    protected $casts = [
        'is_read_admin' => 'boolean',
        'is_read_user' => 'boolean',
    ];

    public function chat()
    {
        return $this->belongsTo(Chat::class);
    }
}