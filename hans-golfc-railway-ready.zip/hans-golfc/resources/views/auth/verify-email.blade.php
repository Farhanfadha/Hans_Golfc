<x-guest-layout>
    <style>
        .auth-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            position: relative;
            overflow: hidden;
        }

        .auth-page::before {
            content: "";
            position: fixed;
            inset: 0;
            background:
                linear-gradient(rgba(15, 23, 42, 0.58), rgba(15, 23, 42, 0.74)),
                url('https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1600&q=80');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            z-index: 0;
        }

        .auth-page::after {
            content: "";
            position: fixed;
            inset: 0;
            background:
                radial-gradient(circle at top right, rgba(250, 204, 21, 0.10), transparent 24%),
                radial-gradient(circle at bottom left, rgba(34, 197, 94, 0.08), transparent 30%);
            z-index: 0;
            pointer-events: none;
        }

        .auth-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 980px;
        }

        .auth-card {
            display: grid;
            grid-template-columns: 1fr 1fr;
            border-radius: 30px;
            overflow: hidden;
            background: rgba(255, 255, 255, 0.97);
            box-shadow: 0 30px 70px rgba(0, 0, 0, 0.22);
            min-height: 560px;
        }

        .auth-left {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: white;
            padding: 56px 48px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
        }

        .auth-left::before {
            content: "";
            position: absolute;
            top: -60px;
            right: -60px;
            width: 220px;
            height: 220px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(250, 204, 21, 0.16), transparent 70%);
        }

        .left-content {
            position: relative;
            z-index: 1;
        }

        .brand-badge {
            display: inline-block;
            padding: 8px 14px;
            border-radius: 999px;
            background: rgba(255,255,255,0.10);
            color: #fde68a;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 18px;
        }

        .brand-title {
            font-size: 42px;
            font-weight: 800;
            line-height: 1.08;
            margin-bottom: 16px;
        }

        .brand-subtitle {
            font-size: 17px;
            line-height: 1.8;
            color: #cbd5e1;
            max-width: 430px;
            margin-bottom: 28px;
        }

        .feature-box {
            padding: 16px 18px;
            border-radius: 18px;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.08);
            max-width: 430px;
        }

        .feature-box strong {
            display: block;
            font-size: 16px;
            margin-bottom: 4px;
        }

        .feature-box span {
            color: #cbd5e1;
            font-size: 14px;
        }

        .auth-right {
            padding: 56px 48px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-badge {
            display: inline-block;
            padding: 8px 13px;
            border-radius: 999px;
            background: #f8fafc;
            color: #0f172a;
            font-size: 12px;
            font-weight: 800;
            border: 1px solid #e2e8f0;
            margin-bottom: 14px;
        }

        .form-title {
            font-size: 34px;
            font-weight: 800;
            color: #0f172a;
            margin-bottom: 8px;
        }

        .form-subtitle {
            color: #64748b;
            font-size: 15px;
            margin-bottom: 28px;
            line-height: 1.7;
        }

        .btn-modern {
            width: 100%;
            min-height: 56px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: white;
            font-weight: 800;
            font-size: 15px;
            transition: 0.2s ease;
            margin-top: 6px;
        }

        .btn-modern:hover {
            background: linear-gradient(135deg, #111827, #334155);
            color: white;
            transform: translateY(-1px);
        }

        .btn-logout-lite {
            width: 100%;
            min-height: 52px;
            border-radius: 15px;
            border: 1px solid #dbe3ec;
            background: #f8fafc;
            color: #0f172a;
            font-weight: 700;
            font-size: 15px;
            transition: 0.2s ease;
            margin-top: 12px;
        }

        .btn-logout-lite:hover {
            background: #eef2f7;
        }

        .custom-status {
            margin-bottom: 16px;
            border-radius: 14px;
            background: #ecfdf3;
            color: #166534;
            padding: 12px 14px;
            border: 1px solid #bbf7d0;
            font-size: 14px;
        }

        @media (max-width: 991.98px) {
            .auth-card {
                grid-template-columns: 1fr;
                min-height: auto;
            }

            .auth-left,
            .auth-right {
                padding: 36px 28px;
            }

            .brand-title {
                font-size: 34px;
            }

            .form-title {
                font-size: 28px;
            }
        }

        @media (max-width: 575.98px) {
            .auth-page {
                padding: 16px;
            }

            .brand-title {
                font-size: 28px;
            }

            .form-title {
                font-size: 24px;
            }
        }
    </style>

    <div class="auth-page">
        <div class="auth-wrapper">
            <div class="auth-card">
                <div class="auth-left">
                    <div class="left-content">
                        <span class="brand-badge">Hans Golf Verification</span>
                        <h1 class="brand-title">Verifikasi Email Anda</h1>
                        <p class="brand-subtitle">
                            Sebelum melanjutkan, cek email Anda lalu klik link verifikasi yang telah kami kirim.
                        </p>

                        <div class="feature-box">
                            <strong>Akun Lebih Aman</strong>
                            <span>Verifikasi email membantu menjaga keamanan akun Anda di Hans Golf.</span>
                        </div>
                    </div>
                </div>

                <div class="auth-right">
                    <span class="form-badge">Email Verification</span>
                    <h2 class="form-title">Cek Inbox Anda</h2>
                    <p class="form-subtitle">
                        Jika belum menerima email verifikasi, Anda bisa meminta link baru di bawah ini.
                    </p>

                    @if (session('status') == 'verification-link-sent')
                        <div class="custom-status">
                            Link verifikasi baru telah dikirim ke alamat email yang Anda gunakan saat registrasi.
                        </div>
                    @endif

                    <form method="POST" action="{{ route('verification.send') }}">
                        @csrf
                        <button type="submit" class="btn-modern">
                            Kirim Ulang Link Verifikasi
                        </button>
                    </form>

                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="btn-logout-lite">
                            Logout
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-guest-layout>