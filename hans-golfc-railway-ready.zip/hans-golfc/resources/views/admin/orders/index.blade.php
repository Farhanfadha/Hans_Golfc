@extends('layouts.app')

@section('content')
<style>
    .admin-page {
        padding-bottom: 50px;
    }

    .admin-hero {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        border-radius: 28px;
        padding: 34px;
        margin-bottom: 24px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.16);
    }

    .admin-hero h1 {
        font-size: 34px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .admin-hero p {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .stat-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 22px;
        padding: 20px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
        height: 100%;
    }

    .stat-label {
        color: #64748b;
        font-weight: 800;
        font-size: 13px;
        text-transform: uppercase;
        margin-bottom: 8px;
    }

    .stat-value {
        color: #0f172a;
        font-size: 28px;
        font-weight: 900;
    }

    .admin-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 24px;
        padding: 24px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
    }

    .table-modern {
        margin-bottom: 0;
    }

    .table-modern thead th {
        color: #64748b;
        font-size: 13px;
        text-transform: uppercase;
        border-bottom: 1px solid #e5e7eb;
        white-space: nowrap;
    }

    .table-modern tbody td {
        vertical-align: middle;
        color: #0f172a;
        font-weight: 600;
    }

    .order-code {
        font-weight: 900;
        color: #0f172a;
    }

    .status-badge {
        display: inline-block;
        padding: 7px 12px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 900;
        white-space: nowrap;
    }

    .badge-muted {
        background: #f1f5f9;
        color: #334155;
    }

    .badge-blue {
        background: #dbeafe;
        color: #1e40af;
    }

    .badge-green {
        background: #dcfce7;
        color: #166534;
    }

    .badge-red {
        background: #fee2e2;
        color: #991b1b;
    }

    .badge-yellow {
        background: #fef3c7;
        color: #92400e;
    }

    .btn-detail {
        background: #0f172a;
        color: white;
        border-radius: 12px;
        padding: 9px 14px;
        text-decoration: none;
        font-weight: 800;
        display: inline-block;
    }

    .btn-detail:hover {
        background: #1e293b;
        color: white;
    }

    .empty-box {
        text-align: center;
        padding: 42px;
        color: #64748b;
    }

    @media (max-width: 991.98px) {
        .admin-hero h1 {
            font-size: 28px;
        }

        .admin-card {
            padding: 16px;
        }
    }
</style>

@php
    $totalOrders = $orders->count();
    $newOrders = $orders->where('status', 'new')->count();
    $paidOrders = $orders->where('payment_status', 'paid')->count();
    $shippedOrders = $orders->where('shipping_status', 'shipped')->count();

    $orderStatusLabels = [
        'new' => 'Order Baru',
        'processing' => 'Diproses',
        'completed' => 'Selesai',
        'cancelled' => 'Dibatalkan',
    ];

    $orderStatusClasses = [
        'new' => 'badge-muted',
        'processing' => 'badge-blue',
        'completed' => 'badge-green',
        'cancelled' => 'badge-red',
    ];

    $paymentStatusLabels = [
        'pending' => 'Menunggu Bayar',
        'waiting_confirmation' => 'Menunggu Konfirmasi',
        'paid' => 'Lunas',
        'rejected' => 'Ditolak',
    ];

    $paymentStatusClasses = [
        'pending' => 'badge-yellow',
        'waiting_confirmation' => 'badge-blue',
        'paid' => 'badge-green',
        'rejected' => 'badge-red',
    ];

    $shippingStatusLabels = [
        'not_shipped' => 'Belum Dikirim',
        'shipped' => 'Sudah Dikirim',
    ];

    $shippingStatusClasses = [
        'not_shipped' => 'badge-yellow',
        'shipped' => 'badge-green',
    ];
@endphp

<div class="container admin-page">
    <div class="admin-hero">
        <h1>Kelola Pesanan</h1>
        <p>Pantau pesanan, pembayaran, bukti transfer, dan pengiriman customer Hans Golf.</p>
    </div>

    @if(session('success'))
        <div class="alert alert-success mb-4">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger mb-4">
            {{ session('error') }}
        </div>
    @endif

    <div class="row g-3 mb-4">
        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Total Order</div>
                <div class="stat-value">{{ $totalOrders }}</div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Order Baru</div>
                <div class="stat-value">{{ $newOrders }}</div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Pembayaran Lunas</div>
                <div class="stat-value">{{ $paidOrders }}</div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="stat-card">
                <div class="stat-label">Sudah Dikirim</div>
                <div class="stat-value">{{ $shippedOrders }}</div>
            </div>
        </div>
    </div>

    <div class="admin-card">
        <div class="table-responsive">
            <table class="table table-modern align-middle">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kode Order</th>
                        <th>Customer</th>
                        <th>WhatsApp</th>
                        <th>Total</th>
                        <th>Status Pesanan</th>
                        <th>Pembayaran</th>
                        <th>Pengiriman</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($orders as $order)
                        @php
                            $orderStatus = $order->status ?? 'new';
                            $paymentStatus = $order->payment_status ?? 'pending';
                            $shippingStatus = $order->shipping_status ?? 'not_shipped';
                        @endphp

                        <tr>
                            <td>#{{ $order->id }}</td>
                            <td>
                                <div class="order-code">{{ $order->order_code }}</div>
                            </td>
                            <td>{{ $order->customer_name }}</td>
                            <td>{{ $order->customer_phone }}</td>
                            <td>Rp {{ number_format($order->total_price, 0, ',', '.') }}</td>
                            <td>
                                <span class="status-badge {{ $orderStatusClasses[$orderStatus] ?? 'badge-muted' }}">
                                    {{ $orderStatusLabels[$orderStatus] ?? $orderStatus }}
                                </span>
                            </td>
                            <td>
                                <span class="status-badge {{ $paymentStatusClasses[$paymentStatus] ?? 'badge-yellow' }}">
                                    {{ $paymentStatusLabels[$paymentStatus] ?? $paymentStatus }}
                                </span>
                            </td>
                            <td>
                                <span class="status-badge {{ $shippingStatusClasses[$shippingStatus] ?? 'badge-yellow' }}">
                                    {{ $shippingStatusLabels[$shippingStatus] ?? 'Belum Dikirim' }}
                                </span>
                            </td>
                            <td>{{ $order->created_at->format('d-m-Y H:i') }}</td>
                            <td>
                                <a href="{{ route('admin.orders.show', $order->id) }}" class="btn-detail">
                                    Detail
                                </a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="10">
                                <div class="empty-box">
                                    Belum ada pesanan.
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection