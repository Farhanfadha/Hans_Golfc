<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            if (!Schema::hasColumn('orders', 'shipping_service')) {
                $table->string('shipping_service')->default('reguler');
            }

            if (!Schema::hasColumn('orders', 'shipping_courier')) {
                $table->string('shipping_courier')->nullable();
            }

            if (!Schema::hasColumn('orders', 'shipping_cost')) {
                $table->decimal('shipping_cost', 12, 2)->default(0);
            }
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $columns = [];

            foreach (['shipping_service', 'shipping_courier', 'shipping_cost'] as $col) {
                if (Schema::hasColumn('orders', $col)) {
                    $columns[] = $col;
                }
            }

            if (count($columns) > 0) {
                $table->dropColumn($columns);
            }
        });
    }
};
