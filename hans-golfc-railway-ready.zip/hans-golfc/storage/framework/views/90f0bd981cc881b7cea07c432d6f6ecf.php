

<?php $__env->startSection('content'); ?>
<style>
    .home-page {
        padding-bottom: 40px;
    }

    .hero-section {
        position: relative;
        overflow: hidden;
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.96), rgba(30, 41, 59, 0.92));
        border-radius: 28px;
        padding: 70px 50px;
        color: white;
        box-shadow: 0 20px 50px rgba(15, 23, 42, 0.12);
        margin-bottom: 40px;
    }

    .hero-section::before {
        content: '';
        position: absolute;
        top: -60px;
        right: -60px;
        width: 240px;
        height: 240px;
        background: radial-gradient(circle, rgba(250, 204, 21, 0.25), transparent 70%);
        border-radius: 50%;
    }

    .hero-section::after {
        content: '';
        position: absolute;
        bottom: -80px;
        left: -80px;
        width: 260px;
        height: 260px;
        background: radial-gradient(circle, rgba(255, 255, 255, 0.08), transparent 70%);
        border-radius: 50%;
    }

    .hero-content {
        position: relative;
        z-index: 2;
    }

    .hero-badge {
        display: inline-block;
        padding: 8px 14px;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.1);
        color: #fde68a;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 18px;
    }

    .hero-title {
        font-size: 52px;
        font-weight: 800;
        line-height: 1.1;
        margin-bottom: 18px;
        max-width: 720px;
    }

    .hero-subtitle {
        font-size: 18px;
        color: #cbd5e1;
        max-width: 650px;
        margin-bottom: 28px;
    }

    .hero-actions {
        display: flex;
        gap: 14px;
        flex-wrap: wrap;
        margin-bottom: 35px;
    }

    .btn-gold {
        background: #facc15;
        color: #111827;
        font-weight: 700;
        border-radius: 14px;
        padding: 12px 22px;
        text-decoration: none;
        transition: 0.25s ease;
        display: inline-block;
    }

    .btn-gold:hover {
        background: #eab308;
        color: #111827;
        transform: translateY(-2px);
    }

    .btn-soft-light {
        background: rgba(255,255,255,0.08);
        color: white;
        border: 1px solid rgba(255,255,255,0.14);
        font-weight: 600;
        border-radius: 14px;
        padding: 12px 22px;
        text-decoration: none;
        transition: 0.25s ease;
        display: inline-block;
    }

    .btn-soft-light:hover {
        background: rgba(255,255,255,0.14);
        color: white;
    }

    .hero-stats .stat-card {
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 18px;
        padding: 20px;
        height: 100%;
        backdrop-filter: blur(4px);
    }

    .hero-stats .stat-number {
        font-size: 28px;
        font-weight: 800;
        color: white;
        margin-bottom: 6px;
    }

    .hero-stats .stat-text {
        font-size: 14px;
        color: #cbd5e1;
        margin: 0;
    }

    .section-block {
        margin-bottom: 48px;
    }

    .section-title {
        font-size: 32px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 8px;
    }

    .section-subtitle {
        color: #64748b;
        margin-bottom: 24px;
        font-size: 16px;
    }

    .feature-card {
        background: white;
        border-radius: 22px;
        padding: 24px;
        height: 100%;
        box-shadow: 0 12px 30px rgba(15, 23, 42, 0.06);
        border: 1px solid #eef2f7;
        transition: 0.25s ease;
    }

    .feature-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 18px 36px rgba(15, 23, 42, 0.08);
    }

    .feature-icon {
        width: 56px;
        height: 56px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        font-size: 24px;
        margin-bottom: 16px;
    }

    .category-card-link {
        display: block;
        height: 100%;
        text-decoration: none;
        color: inherit;
    }

    .category-card {
        background: linear-gradient(135deg, #ffffff, #f8fafc);
        border-radius: 22px;
        padding: 26px 20px;
        text-align: center;
        height: 100%;
        box-shadow: 0 10px 25px rgba(15, 23, 42, 0.05);
        border: 1px solid #edf2f7;
        transition: 0.25s ease;
        cursor: pointer;
    }

    .category-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 18px 36px rgba(15, 23, 42, 0.08);
        border-color: #cbd5e1;
    }

    .category-icon {
        font-size: 42px;
        margin-bottom: 14px;
    }

    .category-title {
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 8px;
    }

    .category-desc {
        color: #64748b;
        margin-bottom: 0;
        font-size: 14px;
        line-height: 1.6;
    }

    .product-card {
        background: white;
        border: none;
        border-radius: 24px;
        overflow: hidden;
        height: 100%;
        box-shadow: 0 14px 35px rgba(15, 23, 42, 0.08);
        transition: 0.3s ease;
        cursor: pointer;
    }

    .product-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 22px 44px rgba(15, 23, 42, 0.12);
    }

    .product-thumb {
        height: 230px;
        background: linear-gradient(135deg, #dbe4ee, #f8fafc);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 56px;
        overflow: hidden;
    }

    .product-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: 0.25s ease;
    }

    .product-card:hover .product-image {
        transform: scale(1.04);
    }

    .product-body {
        padding: 22px;
    }

    .product-title {
        font-size: 20px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 10px;
    }

    .rating-line {
        color: #f59e0b;
        font-weight: 900;
        font-size: 14px;
        margin-bottom: 10px;
    }

    .rating-muted {
        color: #64748b;
        font-weight: 600;
    }

    .product-price {
        font-size: 22px;
        font-weight: 800;
        color: #ca8a04;
        margin-bottom: 10px;
    }

    .stock-badge {
        display: inline-block;
        background: #ecfdf3;
        color: #166534;
        font-size: 13px;
        font-weight: 700;
        padding: 6px 10px;
        border-radius: 999px;
        margin-bottom: 16px;
    }

    .btn-dark-custom {
        background: #111827;
        color: white;
        border-radius: 12px;
        padding: 10px 16px;
        text-decoration: none;
        font-weight: 700;
        display: inline-block;
        transition: 0.2s ease;
        position: relative;
        z-index: 5;
    }

    .btn-dark-custom:hover {
        background: #1f2937;
        color: white;
    }

    .btn-outline-soft {
        background: #f8fafc;
        color: #0f172a;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 10px 16px;
        text-decoration: none;
        font-weight: 700;
        display: inline-block;
        transition: 0.2s ease;
        position: relative;
        z-index: 5;
    }

    .btn-outline-soft:hover {
        background: #f1f5f9;
        color: #0f172a;
    }

    .cta-banner {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        border-radius: 28px;
        padding: 42px;
        box-shadow: 0 20px 50px rgba(15, 23, 42, 0.12);
    }

    .cta-banner h2 {
        font-size: 34px;
        font-weight: 800;
        margin-bottom: 10px;
    }

    .cta-banner p {
        color: #cbd5e1;
        margin-bottom: 0;
        font-size: 16px;
    }

    @media (max-width: 991.98px) {
        .hero-section {
            padding: 45px 28px;
        }

        .hero-title {
            font-size: 38px;
        }
    }

    @media (max-width: 575.98px) {
        .hero-title {
            font-size: 30px;
        }

        .section-title {
            font-size: 26px;
        }

        .cta-banner {
            padding: 28px 22px;
        }

        .product-thumb {
            height: 190px;
        }
    }
</style>

<?php
    $categoryIcons = ['🏌️', '⛳', '🎒', '🧤', '🏆', '👟', '🧢', '⭐'];
?>

<div class="container home-page">
    <section class="hero-section">
        <div class="hero-content">
            <span class="hero-badge">Premium Golf Equipment Store</span>
            <h1 class="hero-title">Selamat Datang di Hans Golf</h1>
            <p class="hero-subtitle">
                Temukan perlengkapan golf terbaik untuk latihan, permainan santai, hingga kompetisi.
                Tampil lebih percaya diri dengan produk pilihan yang berkualitas dan nyaman digunakan.
            </p>

            <div class="hero-actions">
                <a href="<?php echo e(route('products.index')); ?>" class="btn-gold">Lihat Produk</a>
                <a href="#produk-unggulan" class="btn-soft-light">Jelajahi Unggulan</a>
            </div>

            <div class="row g-3 hero-stats">
                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo e($featuredProducts->count()); ?>+</div>
                        <p class="stat-text">Produk unggulan siap dilihat dan dipilih.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-number"><?php echo e($categories->count()); ?>+</div>
                        <p class="stat-text">Kategori produk tersedia, termasuk Accessories jika sudah ditambahkan admin.</p>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="stat-card">
                        <div class="stat-number">Easy</div>
                        <p class="stat-text">Belanja produk golf jadi lebih mudah dan nyaman.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="section-block">
        <h2 class="section-title">Kenapa Pilih Hans Golf?</h2>
        <p class="section-subtitle">
            Kami menghadirkan pengalaman belanja perlengkapan golf yang lebih nyaman, rapi, dan meyakinkan.
        </p>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">🏌️</div>
                    <h5 class="fw-bold mb-2">Produk Berkualitas</h5>
                    <p class="text-muted mb-0">
                        Perlengkapan golf yang cocok untuk pemula hingga pemain berpengalaman.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">🚚</div>
                    <h5 class="fw-bold mb-2">Belanja Mudah</h5>
                    <p class="text-muted mb-0">
                        Alur produk, cart, checkout, dan pemantauan pesanan dibuat sederhana.
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="feature-card">
                    <div class="feature-icon">⭐</div>
                    <h5 class="fw-bold mb-2">Ulasan Customer</h5>
                    <p class="text-muted mb-0">
                        Rating dan ulasan membantu customer memilih produk dengan lebih yakin.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-block">
        <h2 class="section-title">Kategori Populer</h2>
        <p class="section-subtitle">
            Klik kategori untuk langsung melihat produk sesuai kategori yang dipilih.
        </p>

        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-3 col-sm-6">
                    <a href="<?php echo e(route('products.index', ['category' => $category->id])); ?>" class="category-card-link">
                        <div class="category-card">
                            <div class="category-icon">
                                <?php echo e($categoryIcons[$loop->index % count($categoryIcons)]); ?>

                            </div>

                            <h5 class="category-title">
                                <?php echo e($category->name); ?>

                            </h5>

                            <p class="category-desc">
                                Lihat produk kategori <?php echo e($category->name); ?>.
                            </p>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-light border rounded-4 p-4 shadow-sm">
                        Belum ada kategori. Tambahkan kategori dari halaman admin terlebih dahulu.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section id="produk-unggulan" class="section-block">
        <div class="d-flex justify-content-between align-items-md-center flex-column flex-md-row mb-3">
            <div>
                <h2 class="section-title mb-1">Produk Unggulan</h2>
                <p class="section-subtitle mb-0">
                    Klik card produk untuk langsung masuk ke halaman detail produk.
                </p>
            </div>

            <div class="mt-3 mt-md-0">
                <a href="<?php echo e(route('products.index')); ?>" class="btn-outline-soft">Lihat Semua Produk</a>
            </div>
        </div>

        <div class="row g-4">
            <?php $__empty_1 = true; $__currentLoopData = $featuredProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $detailUrl = route('products.show', $product->slug);
                    $avgRating = $product->reviews_avg_rating ? round($product->reviews_avg_rating, 1) : 0;
                    $reviewCount = $product->reviews_count ?? 0;
                ?>

                <div class="col-md-6 col-lg-4">
                    <div class="product-card home-product-card"
                         data-url="<?php echo e($detailUrl); ?>"
                         role="link"
                         tabindex="0"
                         aria-label="Lihat detail <?php echo e($product->name); ?>">
                        <div class="product-thumb">
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                     alt="<?php echo e($product->name); ?>"
                                     class="product-image">
                            <?php else: ?>
                                ⛳
                            <?php endif; ?>
                        </div>

                        <div class="product-body">
                            <h5 class="product-title"><?php echo e($product->name); ?></h5>

                            <?php if($reviewCount > 0): ?>
                                <div class="rating-line">
                                    ⭐ <?php echo e($avgRating); ?> / 5
                                    <span class="rating-muted">(<?php echo e($reviewCount); ?> ulasan)</span>
                                </div>
                            <?php else: ?>
                                <div class="rating-line">
                                    <span class="rating-muted">Belum ada ulasan</span>
                                </div>
                            <?php endif; ?>

                            <div class="product-price">
                                Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                            </div>

                            <div class="stock-badge">
                                Stok: <?php echo e($product->stock); ?>

                            </div>

                            <div class="d-flex gap-2 flex-wrap">
                                <a href="<?php echo e($detailUrl); ?>" class="btn-dark-custom">
                                    Detail Produk
                                </a>

                                <a href="<?php echo e(route('products.index', ['category' => $product->category_id])); ?>" class="btn-outline-soft">
                                    Produk Sejenis
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="alert alert-light border rounded-4 p-4 shadow-sm">
                        Belum ada produk unggulan yang ditampilkan.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="cta-banner">
        <div class="row align-items-center g-4">
            <div class="col-lg-8">
                <h2>Siap Memilih Peralatan Golf Terbaik?</h2>
                <p>
                    Jelajahi koleksi Hans Golf dan temukan perlengkapan yang tepat untuk latihan,
                    permainan santai, maupun kebutuhan kompetisi Anda.
                </p>
            </div>

            <div class="col-lg-4 text-lg-end">
                <a href="<?php echo e(route('products.index')); ?>" class="btn-gold">Mulai Belanja</a>
            </div>
        </div>
    </section>
</div>

<script>
    document.querySelectorAll('.home-product-card').forEach(function (card) {
        card.addEventListener('click', function (event) {
            const blockedElement = event.target.closest('a, button, form, input, select, textarea');

            if (blockedElement) {
                return;
            }

            const url = this.dataset.url;

            if (url) {
                window.location.href = url;
            }
        });

        card.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') {
                const url = this.dataset.url;

                if (url) {
                    window.location.href = url;
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\farha\hans-golfc\resources\views/home.blade.php ENDPATH**/ ?>