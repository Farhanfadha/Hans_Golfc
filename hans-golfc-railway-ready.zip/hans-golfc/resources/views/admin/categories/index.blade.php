@extends('layouts.app')

@section('content')
<style>
    .admin-page {
        padding-bottom: 50px;
    }

    .admin-hero {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        border-radius: 28px;
        padding: 34px;
        margin-bottom: 24px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.16);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 18px;
        flex-wrap: wrap;
    }

    .admin-hero h1 {
        font-size: 34px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .admin-hero p {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .btn-add {
        background: #16a34a;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: 900;
        display: inline-block;
        border: none;
    }

    .btn-add:hover {
        background: #15803d;
        color: white;
    }

    .admin-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 24px;
        padding: 24px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
    }

    .table-modern {
        margin-bottom: 0;
    }

    .table-modern thead th {
        color: #64748b;
        font-size: 13px;
        text-transform: uppercase;
        border-bottom: 1px solid #e5e7eb;
        white-space: nowrap;
    }

    .table-modern tbody td {
        vertical-align: middle;
        font-weight: 600;
    }

    .number-pill {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 42px;
        padding: 7px 12px;
        background: #f1f5f9;
        color: #0f172a;
        border-radius: 999px;
        font-weight: 900;
    }

    .category-name {
        font-weight: 900;
        color: #0f172a;
        font-size: 16px;
    }

    .slug-pill {
        display: inline-block;
        background: #f1f5f9;
        color: #334155;
        padding: 7px 12px;
        border-radius: 999px;
        font-weight: 800;
        font-size: 13px;
    }

    .product-count-pill {
        display: inline-block;
        background: #ecfdf5;
        color: #166534;
        padding: 7px 12px;
        border-radius: 999px;
        font-weight: 800;
        font-size: 13px;
    }

    .btn-action {
        border: none;
        border-radius: 12px;
        padding: 9px 13px;
        font-weight: 800;
        text-decoration: none;
        display: inline-block;
        font-size: 14px;
    }

    .btn-edit {
        background: #dbeafe;
        color: #1e40af;
    }

    .btn-edit:hover {
        background: #bfdbfe;
        color: #1e40af;
    }

    .btn-delete {
        background: #fee2e2;
        color: #991b1b;
    }

    .btn-delete:hover {
        background: #fecaca;
        color: #991b1b;
    }

    .empty-box {
        text-align: center;
        padding: 42px;
        color: #64748b;
    }

    @media (max-width: 991.98px) {
        .admin-hero h1 {
            font-size: 28px;
        }

        .admin-card {
            padding: 16px;
        }
    }
</style>

<div class="container admin-page">
    <div class="admin-hero">
        <div>
            <h1>Kelola Kategori</h1>
            <p>Tambah kategori seperti Bola Golf, Stick Golf, Golf Bags, Accessories, dan kategori lainnya.</p>
        </div>

        <a href="{{ route('admin.categories.create') }}" class="btn-add">
            + Tambah Kategori
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success mb-4">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger mb-4">
            {{ session('error') }}
        </div>
    @endif

    <div class="admin-card">
        <div class="table-responsive">
            <table class="table table-modern align-middle">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Kategori</th>
                        <th>Slug</th>
                        <th>Jumlah Produk</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($categories as $category)
                        <tr>
                            <td>
                                <span class="number-pill">
                                    #{{ $loop->iteration }}
                                </span>
                            </td>

                            <td>
                                <div class="category-name">
                                    {{ $category->name }}
                                </div>
                            </td>

                            <td>
                                <span class="slug-pill">
                                    {{ $category->slug }}
                                </span>
                            </td>

                            <td>
                                <span class="product-count-pill">
                                    {{ $category->products()->count() }} produk
                                </span>
                            </td>

                            <td class="text-end">
                                <a href="{{ route('admin.categories.edit', $category->id) }}" class="btn-action btn-edit">
                                    Edit
                                </a>

                                <form action="{{ route('admin.categories.destroy', $category->id) }}"
                                      method="POST"
                                      class="d-inline"
                                      onsubmit="return confirm('Yakin ingin menghapus kategori ini?')">
                                    @csrf
                                    @method('DELETE')

                                    <button type="submit" class="btn-action btn-delete">
                                        Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5">
                                <div class="empty-box">
                                    Belum ada kategori. Silakan tambah kategori terlebih dahulu.
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection