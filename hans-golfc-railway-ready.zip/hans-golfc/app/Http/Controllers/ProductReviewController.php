<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\ProductReview;
use Illuminate\Http\Request;

class ProductReviewController extends Controller
{
    public function store(Request $request, Order $order, OrderItem $orderItem)
    {
        if ($order->user_id !== auth()->id()) {
            abort(403);
        }

        if ($orderItem->order_id !== $order->id) {
            abort(404);
        }

        if ($order->status !== 'completed') {
            return back()->with('error', 'Ulasan hanya bisa diberikan setelah pesanan dinyatakan selesai oleh admin.');
        }

        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'review' => 'nullable|string|max:1000',
        ], [
            'rating.required' => 'Rating wajib dipilih.',
            'rating.min' => 'Rating minimal 1 bintang.',
            'rating.max' => 'Rating maksimal 5 bintang.',
            'review.max' => 'Ulasan maksimal 1000 karakter.',
        ]);

        ProductReview::updateOrCreate(
            [
                'user_id' => auth()->id(),
                'order_item_id' => $orderItem->id,
            ],
            [
                'product_id' => $orderItem->product_id,
                'order_id' => $order->id,
                'rating' => $request->rating,
                'review' => $request->review,
            ]
        );

        return back()->with('success', 'Ulasan produk berhasil disimpan.');
    }

    public function storeBatch(Request $request, Order $order)
    {
        if ($order->user_id !== auth()->id()) {
            abort(403);
        }

        if ($order->status !== 'completed') {
            return back()->with('error', 'Ulasan hanya bisa diberikan setelah pesanan dinyatakan selesai oleh admin.');
        }

        $order->load('items');

        $request->validate([
            'reviews' => 'required|array',
            'reviews.*.rating' => 'required|integer|min:1|max:5',
            'reviews.*.review' => 'nullable|string|max:1000',
        ], [
            'reviews.required' => 'Data ulasan wajib diisi.',
            'reviews.*.rating.required' => 'Semua produk wajib diberi rating.',
            'reviews.*.rating.min' => 'Rating minimal 1 bintang.',
            'reviews.*.rating.max' => 'Rating maksimal 5 bintang.',
            'reviews.*.review.max' => 'Ulasan maksimal 1000 karakter.',
        ]);

        $reviews = $request->input('reviews', []);

        foreach ($order->items as $item) {
            if (!isset($reviews[$item->id]['rating'])) {
                return back()
                    ->withInput()
                    ->with('error', 'Semua produk dalam pesanan ini wajib diberi rating.');
            }

            ProductReview::updateOrCreate(
                [
                    'user_id' => auth()->id(),
                    'order_item_id' => $item->id,
                ],
                [
                    'product_id' => $item->product_id,
                    'order_id' => $order->id,
                    'rating' => $reviews[$item->id]['rating'],
                    'review' => $reviews[$item->id]['review'] ?? null,
                ]
            );
        }

        return back()->with('success', 'Semua ulasan produk berhasil disimpan. Terima kasih atas penilaian Anda.');
    }
}