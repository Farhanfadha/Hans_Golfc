@extends('layouts.app')

@section('content')
<style>
    .chat-page {
        padding-bottom: 50px;
    }

    .chat-shell {
        background: white;
        border-radius: 28px;
        overflow: hidden;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.12);
        border: 1px solid #e5e7eb;
        max-width: 980px;
        margin: 0 auto;
    }

    .chat-header {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        padding: 28px 32px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 18px;
        flex-wrap: wrap;
    }

    .chat-title {
        font-size: 30px;
        font-weight: 900;
        margin-bottom: 6px;
    }

    .chat-subtitle {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .online-pill {
        background: rgba(22, 163, 74, 0.18);
        color: #bbf7d0;
        border: 1px solid rgba(187, 247, 208, 0.25);
        padding: 9px 14px;
        border-radius: 999px;
        font-weight: 800;
        font-size: 13px;
    }

    .chat-body {
        background: linear-gradient(180deg, #f8fafc, #ffffff);
        padding: 28px;
        min-height: 480px;
        max-height: 600px;
        overflow-y: auto;
    }

    .message-row {
        display: flex;
        margin-bottom: 16px;
    }

    .message-row.user {
        justify-content: flex-end;
    }

    .message-row.admin {
        justify-content: flex-start;
    }

    .message-bubble {
        max-width: 72%;
        padding: 14px 16px;
        border-radius: 18px;
        box-shadow: 0 8px 18px rgba(15, 23, 42, 0.06);
        position: relative;
    }

    .message-row.user .message-bubble {
        background: #16a34a;
        color: white;
        border-bottom-right-radius: 6px;
    }

    .message-row.admin .message-bubble {
        background: white;
        color: #0f172a;
        border: 1px solid #e5e7eb;
        border-bottom-left-radius: 6px;
    }

    .message-sender {
        font-size: 12px;
        font-weight: 900;
        margin-bottom: 5px;
        opacity: 0.85;
    }

    .message-text {
        white-space: pre-line;
        line-height: 1.6;
        font-weight: 600;
    }

    .message-time {
        font-size: 11px;
        opacity: 0.75;
        margin-top: 7px;
    }

    .empty-chat {
        text-align: center;
        padding: 80px 20px;
        color: #64748b;
    }

    .empty-icon {
        font-size: 54px;
        margin-bottom: 14px;
    }

    .quick-help {
        background: #f8fafc;
        border-top: 1px solid #e5e7eb;
        padding: 16px 28px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .quick-chip {
        border: 1px solid #dbe3ec;
        background: white;
        color: #334155;
        border-radius: 999px;
        padding: 8px 12px;
        font-weight: 800;
        font-size: 13px;
        cursor: pointer;
    }

    .quick-chip:hover {
        background: #f1f5f9;
    }

    .chat-form {
        border-top: 1px solid #e5e7eb;
        padding: 22px 28px;
        background: white;
    }

    .message-input {
        border-radius: 18px;
        border: 1px solid #dbe3ec;
        min-height: 54px;
        resize: none;
        padding: 14px 16px;
        font-weight: 600;
    }

    .message-input:focus {
        border-color: #94a3b8;
        box-shadow: 0 0 0 0.2rem rgba(148, 163, 184, 0.16);
    }

    .btn-send {
        background: #0f172a;
        color: white;
        border: none;
        border-radius: 16px;
        padding: 13px 20px;
        font-weight: 900;
        height: 54px;
        min-width: 130px;
    }

    .btn-send:hover {
        background: #1e293b;
        color: white;
    }

    @media (max-width: 768px) {
        .chat-header,
        .chat-body,
        .quick-help,
        .chat-form {
            padding-left: 18px;
            padding-right: 18px;
        }

        .message-bubble {
            max-width: 88%;
        }

        .chat-title {
            font-size: 26px;
        }

        .btn-send {
            width: 100%;
        }
    }
</style>

<div class="container chat-page">
    <div class="chat-shell">
        <div class="chat-header">
            <div>
                <h1 class="chat-title">Chat Admin Hans Golf</h1>
                <p class="chat-subtitle">
                    Tanyakan produk, pembayaran, stok, atau status pesanan Anda.
                </p>
            </div>

            <div class="online-pill">
                ● Admin siap membantu
            </div>
        </div>

        <div class="chat-body" id="chatBody">
            @if($messages->count() > 0)
                @foreach($messages as $message)
                    @php
                        $isUser = $message->sender_type === 'user';
                    @endphp

                    <div class="message-row {{ $isUser ? 'user' : 'admin' }}">
                        <div class="message-bubble">
                            <div class="message-sender">
                                {{ $isUser ? 'Anda' : 'Admin Hans Golf' }}
                            </div>

                            <div class="message-text">{{ $message->message }}</div>

                            <div class="message-time">
                                {{ $message->created_at->format('d M Y H:i') }}
                            </div>
                        </div>
                    </div>
                @endforeach
            @else
                <div class="empty-chat">
                    <div class="empty-icon">💬</div>
                    <h4>Belum ada pesan</h4>
                    <p class="mb-0">
                        Mulai percakapan dengan admin Hans Golf.
                    </p>
                </div>
            @endif
        </div>

        <div class="quick-help">
            <button type="button" class="quick-chip" data-message="Halo admin, saya ingin bertanya tentang produk Hans Golf.">
                Tanya Produk
            </button>

            <button type="button" class="quick-chip" data-message="Halo admin, saya ingin konfirmasi pembayaran pesanan saya.">
                Konfirmasi Pembayaran
            </button>

            <button type="button" class="quick-chip" data-message="Halo admin, saya ingin bertanya status pengiriman pesanan saya.">
                Status Pengiriman
            </button>
        </div>

        <form action="{{ route('chat.send') }}" method="POST" class="chat-form">
            @csrf

            <div class="row g-3 align-items-end">
                <div class="col-lg-10">
                    <textarea name="message"
                              id="messageInput"
                              class="form-control message-input"
                              rows="2"
                              placeholder="Tulis pesan Anda di sini..."
                              required>{{ old('message') }}</textarea>
                </div>

                <div class="col-lg-2">
                    <button type="submit" class="btn-send">
                        Kirim
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    const chatBody = document.getElementById('chatBody');
    const messageInput = document.getElementById('messageInput');
    const quickChips = document.querySelectorAll('.quick-chip');

    if (chatBody) {
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    quickChips.forEach(function (chip) {
        chip.addEventListener('click', function () {
            messageInput.value = this.dataset.message;
            messageInput.focus();
        });
    });
</script>
@endsection