@extends('layouts.app')

@section('content')
<style>
    .success-page {
        padding-bottom: 50px;
    }

    .success-card {
        background: white;
        border: none;
        border-radius: 28px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }

    .success-header {
        background: linear-gradient(135deg, #16a34a, #15803d);
        color: white;
        padding: 36px 32px;
    }

    .success-icon {
        font-size: 54px;
        margin-bottom: 10px;
    }

    .success-title {
        font-size: 34px;
        font-weight: 800;
        margin-bottom: 8px;
    }

    .success-subtitle {
        margin-bottom: 0;
        color: rgba(255,255,255,0.92);
    }

    .success-body {
        padding: 32px;
    }

    .info-card {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 20px;
        padding: 20px;
        height: 100%;
    }

    .payment-card {
        background: linear-gradient(135deg, #fffbeb, #ffffff);
        border: 1px solid #fde68a;
        border-radius: 24px;
        padding: 24px;
        margin-bottom: 24px;
    }

    .payment-title {
        font-size: 24px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 10px;
    }

    .payment-subtitle {
        color: #64748b;
        margin-bottom: 18px;
    }

    .bank-box {
        background: white;
        border: 1px solid #facc15;
        border-radius: 18px;
        padding: 18px;
        margin-bottom: 18px;
    }

    .bank-label {
        font-size: 13px;
        font-weight: 700;
        color: #64748b;
        text-transform: uppercase;
        margin-bottom: 6px;
    }

    .bank-number {
        font-size: 28px;
        font-weight: 900;
        color: #0f172a;
        letter-spacing: 1px;
        margin-bottom: 6px;
    }

    .bank-name {
        font-size: 16px;
        font-weight: 700;
        color: #334155;
        margin-bottom: 0;
    }

    .btn-copy {
        border: none;
        background: #111827;
        color: white;
        border-radius: 12px;
        padding: 10px 14px;
        font-weight: 800;
        margin-top: 12px;
    }

    .btn-copy:hover {
        background: #1f2937;
        color: white;
    }

    .info-label {
        font-size: 13px;
        font-weight: 700;
        color: #64748b;
        text-transform: uppercase;
        margin-bottom: 6px;
    }

    .info-value {
        font-size: 16px;
        color: #0f172a;
        font-weight: 600;
        margin: 0;
        line-height: 1.7;
    }

    .section-title {
        font-size: 24px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 18px;
    }

    .order-item {
        border: 1px solid #e2e8f0;
        border-radius: 18px;
        padding: 16px 18px;
        background: linear-gradient(135deg, #ffffff, #f8fafc);
    }

    .order-item-title {
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 6px;
    }

    .order-item-meta {
        color: #64748b;
        font-size: 14px;
        margin-bottom: 6px;
    }

    .order-item-total {
        font-weight: 800;
        color: #0f172a;
    }

    .form-label-custom {
        font-weight: 700;
        color: #0f172a;
        margin-bottom: 8px;
    }

    .form-control-custom {
        border-radius: 14px;
        border: 1px solid #dbe3ec;
        min-height: 48px;
        box-shadow: none;
    }

    .form-control-custom:focus {
        border-color: #94a3b8;
        box-shadow: 0 0 0 0.2rem rgba(148, 163, 184, 0.15);
    }

    .btn-upload-custom {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 12px 18px;
        font-weight: 800;
    }

    .btn-upload-custom:hover {
        background: #15803d;
        color: white;
    }

    .btn-home-custom {
        display: inline-block;
        background: #111827;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: 800;
        margin-top: 24px;
        margin-right: 8px;
    }

    .btn-home-custom:hover {
        background: #1f2937;
        color: white;
    }

    .btn-monitor-custom {
        display: inline-block;
        background: #16a34a;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: 800;
        margin-top: 24px;
    }

    .btn-monitor-custom:hover {
        background: #15803d;
        color: white;
    }

    .payment-preview {
        display: none;
        max-width: 260px;
        border-radius: 16px;
        border: 1px solid #e2e8f0;
        margin-top: 12px;
    }

    .status-badge-custom {
        display: inline-block;
        padding: 8px 12px;
        border-radius: 999px;
        font-weight: 800;
        font-size: 13px;
    }

    .status-pending {
        background: #fef3c7;
        color: #92400e;
    }

    .status-waiting {
        background: #dbeafe;
        color: #1e40af;
    }

    .status-paid {
        background: #dcfce7;
        color: #166534;
    }

    .status-rejected {
        background: #fee2e2;
        color: #991b1b;
    }
</style>

@php
    $paymentStatusLabels = [
        'pending' => 'Menunggu Pembayaran',
        'waiting_confirmation' => 'Menunggu Konfirmasi Admin',
        'paid' => 'Pembayaran Diterima',
        'rejected' => 'Pembayaran Ditolak',
    ];

    $paymentStatusClasses = [
        'pending' => 'status-pending',
        'waiting_confirmation' => 'status-waiting',
        'paid' => 'status-paid',
        'rejected' => 'status-rejected',
    ];

    $paymentStatus = $order->payment_status ?? 'pending';
@endphp

<div class="container success-page">
    <div class="success-card">
        <div class="success-header">
            <div class="success-icon">✅</div>
            <h1 class="success-title">Pesanan Berhasil Dibuat</h1>
            <p class="success-subtitle">
                Terima kasih, pesanan Anda sudah tercatat. Silakan lakukan pembayaran agar pesanan dapat diproses.
            </p>
        </div>

        <div class="success-body">
            @if(session('success'))
                <div class="alert alert-success mb-4">
                    {{ session('success') }}
                </div>
            @endif

            @if(session('error'))
                <div class="alert alert-danger mb-4">
                    {{ session('error') }}
                </div>
            @endif

            @if($errors->any())
                <div class="alert alert-danger mb-4">
                    <strong>Upload gagal.</strong>

                    <ul class="mb-0 mt-2">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="payment-card">
                <h2 class="payment-title">Informasi Pembayaran Transfer</h2>
                <p class="payment-subtitle">
                    Transfer sesuai total pembayaran ke rekening berikut, lalu upload bukti transfer.
                    Sertakan nama pengirim agar pembayaran mudah dicek.
                </p>

                <div class="row g-4">
                    <div class="col-lg-5">
                        <div class="bank-box">
                            <div class="bank-label">Nomor Rekening</div>
                            <div class="bank-number" id="rekeningNumber">765-147-4373</div>
                            <p class="bank-name">Bank BCA — Atas Nama: Farhan F.</p>

                            <button type="button" class="btn-copy" id="copyRekeningBtn">
                                Salin Nomor Rekening
                            </button>
                        </div>

                        <div class="info-card">
                            <div class="info-label">Total yang Harus Ditransfer</div>
                            <p class="info-value" style="font-size: 26px; font-weight: 900; color: #ca8a04;">
                                Rp {{ number_format($order->total_price, 0, ',', '.') }}
                            </p>

                            <div class="info-label mt-3">Kode Order</div>
                            <p class="info-value">{{ $order->order_code }}</p>

                            <div class="info-label mt-3">Status Pembayaran</div>
                            <span class="status-badge-custom {{ $paymentStatusClasses[$paymentStatus] ?? 'status-pending' }}">
                                {{ $paymentStatusLabels[$paymentStatus] ?? 'Menunggu Pembayaran' }}
                            </span>
                        </div>
                    </div>

                    <div class="col-lg-7">
                        <div class="info-card">
                            @if($paymentStatus === 'paid')
                                <div class="alert alert-success mb-0">
                                    Pembayaran Anda sudah dikonfirmasi admin. Pesanan akan segera diproses.
                                </div>
                            @elseif($paymentStatus === 'waiting_confirmation')
                                <div class="alert alert-info">
                                    Bukti transfer sudah dikirim dan sedang menunggu konfirmasi admin.
                                </div>

                                <div class="info-label">Nama Pengirim</div>
                                <p class="info-value mb-3">{{ $order->sender_name ?? '-' }}</p>

                                @if($order->payment_proof)
                                    <a href="{{ asset('storage/' . $order->payment_proof) }}" target="_blank" class="btn btn-outline-primary">
                                        Lihat Bukti Transfer
                                    </a>
                                @endif

                                <hr>

                                <p class="mb-3 text-muted">
                                    Jika bukti transfer sebelumnya salah, Anda bisa upload ulang bukti transfer di bawah ini.
                                </p>

                                <form action="{{ route('cart.uploadPaymentProof', $order->id) }}" method="POST" enctype="multipart/form-data">
                                    @csrf

                                    <div class="mb-3">
                                        <label class="form-label-custom">Nama Pengirim</label>
                                        <input type="text"
                                               name="sender_name"
                                               class="form-control form-control-custom"
                                               value="{{ old('sender_name', $order->sender_name) }}"
                                               placeholder="Contoh: Farhan F."
                                               required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label-custom">Upload Ulang Bukti Transfer</label>
                                        <input type="file"
                                               name="payment_proof"
                                               id="paymentProofInput"
                                               class="form-control form-control-custom"
                                               accept=".jpg,.jpeg,.png,.webp,.pdf"
                                               required>

                                        <small class="text-muted">
                                            Format: JPG, JPEG, PNG, WEBP, atau PDF. Maksimal 2 MB.
                                        </small>

                                        <img id="paymentPreview" class="payment-preview" alt="Preview Bukti Transfer">
                                    </div>

                                    <button type="submit" class="btn-upload-custom">
                                        Upload Ulang Bukti Transfer
                                    </button>
                                </form>
                            @else
                                @if($paymentStatus === 'rejected')
                                    <div class="alert alert-danger">
                                        Bukti transfer sebelumnya ditolak. Silakan upload ulang bukti transfer yang benar.
                                    </div>
                                @endif

                                <form action="{{ route('cart.uploadPaymentProof', $order->id) }}" method="POST" enctype="multipart/form-data">
                                    @csrf

                                    <div class="mb-3">
                                        <label class="form-label-custom">Nama Pengirim</label>
                                        <input type="text"
                                               name="sender_name"
                                               class="form-control form-control-custom"
                                               value="{{ old('sender_name', $order->sender_name) }}"
                                               placeholder="Masukkan nama pemilik rekening / nama pengirim"
                                               required>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label-custom">Upload Bukti Transfer</label>
                                        <input type="file"
                                               name="payment_proof"
                                               id="paymentProofInput"
                                               class="form-control form-control-custom"
                                               accept=".jpg,.jpeg,.png,.webp,.pdf"
                                               required>

                                        <small class="text-muted">
                                            Format: JPG, JPEG, PNG, WEBP, atau PDF. Maksimal 2 MB.
                                        </small>

                                        <img id="paymentPreview" class="payment-preview" alt="Preview Bukti Transfer">
                                    </div>

                                    <div class="alert alert-warning">
                                        Mohon pastikan nominal transfer sesuai dengan total pembayaran dan sertakan kode order
                                        <strong>{{ $order->order_code }}</strong> jika ada kolom catatan transfer.
                                    </div>

                                    <button type="submit" class="btn-upload-custom">
                                        Upload Bukti Transfer
                                    </button>
                                </form>
                            @endif
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <div class="info-card">
                        <div class="info-label">Kode Order</div>
                        <p class="info-value">{{ $order->order_code }}</p>

                        <div class="info-label mt-3">Nama</div>
                        <p class="info-value">{{ $order->customer_name }}</p>

                        <div class="info-label mt-3">No. WhatsApp</div>
                        <p class="info-value">{{ $order->customer_phone }}</p>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="info-card">
                        <div class="info-label">Alamat</div>
                        <p class="info-value">{{ $order->customer_address }}</p>

                        <div class="info-label mt-3">Catatan</div>
                        <p class="info-value">{{ $order->note ?? '-' }}</p>

                        <div class="info-label mt-3">Status Pesanan</div>
                        <p class="info-value text-success">{{ ucfirst($order->status) }}</p>
                    </div>
                </div>
            </div>

            <div class="info-card mb-4">
                <div class="info-label">Total Pembayaran</div>
                <p class="info-value" style="font-size: 24px; font-weight: 800; color: #ca8a04;">
                    Rp {{ number_format($order->total_price, 0, ',', '.') }}
                </p>
            </div>

            <h2 class="section-title">Detail Pesanan</h2>

            <div class="d-flex flex-column gap-3">
                @foreach($order->items as $item)
                    <div class="order-item">
                        <div class="order-item-title">{{ $item->product_name }}</div>
                        <div class="order-item-meta">
                            {{ $item->quantity }} x Rp {{ number_format($item->price, 0, ',', '.') }}
                        </div>
                        <div class="order-item-total">
                            Rp {{ number_format($item->subtotal, 0, ',', '.') }}
                        </div>
                    </div>
                @endforeach
            </div>

            <div>
                <a href="{{ route('home') }}" class="btn-home-custom">
                    Kembali ke Beranda
                </a>

                <a href="{{ route('orders.show', $order->id) }}" class="btn-monitor-custom">
                    Pantau Pesanan
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    const copyButton = document.getElementById('copyRekeningBtn');
    const rekeningNumber = document.getElementById('rekeningNumber');
    const paymentProofInput = document.getElementById('paymentProofInput');
    const paymentPreview = document.getElementById('paymentPreview');

    if (copyButton && rekeningNumber) {
        copyButton.addEventListener('click', function () {
            const number = rekeningNumber.innerText.replace(/-/g, '');

            navigator.clipboard.writeText(number).then(function () {
                copyButton.innerText = 'Nomor Rekening Disalin';

                setTimeout(function () {
                    copyButton.innerText = 'Salin Nomor Rekening';
                }, 2000);
            });
        });
    }

    if (paymentProofInput && paymentPreview) {
        paymentProofInput.addEventListener('change', function () {
            const file = this.files[0];

            if (!file) {
                paymentPreview.style.display = 'none';
                paymentPreview.src = '';
                return;
            }

            if (!file.type.startsWith('image/')) {
                paymentPreview.style.display = 'none';
                paymentPreview.src = '';
                return;
            }

            paymentPreview.src = URL.createObjectURL(file);
            paymentPreview.style.display = 'block';
        });
    }
</script>
@endsection