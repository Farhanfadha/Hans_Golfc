<section>
    <header class="mb-3">
        <h5 class="account-section-title mb-1">{{ __('Hapus Akun') }}</h5>
        <p class="account-section-desc mb-0">
            {{ __('Setelah akun dihapus, semua data terkait akan dihapus secara permanen. Silakan unduh data yang ingin Anda simpan sebelum menghapus akun.') }}
        </p>
    </header>

    <button type="button" class="btn btn-outline-danger fw-semibold mt-2" data-bs-toggle="modal" data-bs-target="#confirmUserDeletion">
        {{ __('Hapus Akun') }}
    </button>

    <div class="modal fade" id="confirmUserDeletion" tabindex="-1" aria-labelledby="confirmUserDeletionLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="border-radius: 20px;">
                <form method="post" action="{{ route('profile.destroy') }}">
                    @csrf
                    @method('delete')

                    <div class="modal-body p-4">
                        <h5 class="mb-2" id="confirmUserDeletionLabel">{{ __('Yakin ingin menghapus akun Anda?') }}</h5>
                        <p class="text-muted small">
                            {{ __('Setelah akun dihapus, semua data terkait akan dihapus secara permanen. Masukkan password Anda untuk mengonfirmasi.') }}
                        </p>

                        <div class="mt-3">
                            <label for="password" class="visually-hidden">{{ __('Password') }}</label>
                            <input id="password" name="password" type="password"
                                   class="form-control @error('password', 'userDeletion') is-invalid @enderror"
                                   placeholder="{{ __('Password') }}">
                            @error('password', 'userDeletion')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('Batal') }}</button>
                        <button type="submit" class="btn btn-danger">{{ __('Hapus Akun') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    @if ($errors->userDeletion->isNotEmpty())
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                new bootstrap.Modal(document.getElementById('confirmUserDeletion')).show();
            });
        </script>
    @endif
</section>
