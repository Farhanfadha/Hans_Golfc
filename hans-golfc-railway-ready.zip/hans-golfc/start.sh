#!/bin/sh
set -e

# Generate APP_KEY on first boot if not already set via env vars
if [ -z "$APP_KEY" ]; then
  echo "WARNING: APP_KEY is empty. Set it in Railway variables."
fi

php artisan storage:link || true
# NOTE: migrate --force is intentionally NOT run here because the database
# is populated by importing hans_golf.sql directly (see hosting tutorial).
# If you ever reset the database and need fresh empty tables instead,
# uncomment the line below:
# php artisan migrate --force
php artisan config:cache
php artisan route:cache
php artisan view:cache

php artisan serve --host=0.0.0.0 --port="${PORT:-8080}"
