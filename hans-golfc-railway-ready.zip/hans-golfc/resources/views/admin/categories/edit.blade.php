@extends('layouts.app')

@section('content')
<style>
    .form-page {
        padding-bottom: 50px;
    }

    .form-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 28px;
        box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
        overflow: hidden;
        max-width: 850px;
        margin: 0 auto;
    }

    .form-header {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        padding: 32px;
    }

    .form-header h1 {
        font-size: 32px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .form-header p {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .form-body {
        padding: 32px;
    }

    .form-label {
        font-weight: 800;
        color: #0f172a;
    }

    .form-control {
        border-radius: 14px;
        min-height: 48px;
        border: 1px solid #dbe3ec;
    }

    .slug-preview {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        padding: 14px;
        color: #334155;
        font-weight: 700;
    }

    .info-box {
        background: #eff6ff;
        border: 1px solid #bfdbfe;
        border-radius: 18px;
        padding: 16px;
        color: #1e40af;
        font-weight: 600;
        margin-bottom: 22px;
    }

    .btn-save {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 12px 18px;
        font-weight: 900;
    }

    .btn-save:hover {
        background: #15803d;
        color: white;
    }

    .btn-back {
        background: #64748b;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: 900;
        display: inline-block;
    }

    .btn-back:hover {
        background: #475569;
        color: white;
    }
</style>

<div class="container form-page">
    <div class="form-card">
        <div class="form-header">
            <h1>Edit Kategori</h1>
            <p>Perbarui nama kategori produk Hans Golf.</p>
        </div>

        <div class="form-body">
            @if($errors->any())
                <div class="alert alert-danger">
                    <strong>Terjadi kesalahan.</strong>

                    <ul class="mb-0 mt-2">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="info-box">
                Jika nama kategori diubah, slug akan otomatis ikut berubah.
            </div>

            <form action="{{ route('admin.categories.update', $category->id) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="mb-4">
                    <label class="form-label">Nama Kategori</label>
                    <input type="text"
                           name="name"
                           class="form-control"
                           value="{{ old('name', $category->name) }}"
                           required>
                </div>

                <div class="mb-4">
                    <label class="form-label">Slug Saat Ini</label>
                    <div class="slug-preview">
                        {{ $category->slug }}
                    </div>
                </div>

                <div class="d-flex gap-2 flex-wrap">
                    <button type="submit" class="btn-save">
                        Update Kategori
                    </button>

                    <a href="{{ route('admin.categories.index') }}" class="btn-back">
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection