<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\OrderItem;
use App\Models\User;

class Order extends Model
{
    protected $fillable = [
        'user_id',
        'order_code',
        'customer_name',
        'customer_phone',
        'customer_address',
        'note',
        'total_price',
        'status',
        'payment_status',
        'sender_name',
        'payment_proof',
        'paid_at',
        'shipping_status',
        'courier_name',
        'tracking_number',
        'shipped_at',
        'shipping_service',
        'shipping_courier',
        'shipping_cost',
        'stock_restored',
    ];

    protected $casts = [
        'paid_at' => 'datetime',
        'shipped_at' => 'datetime',
        'stock_restored' => 'boolean',
    ];

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}