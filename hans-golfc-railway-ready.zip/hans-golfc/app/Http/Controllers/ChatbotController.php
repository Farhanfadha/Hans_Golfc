<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ChatbotController extends Controller
{
    protected function knowledgeBase(): array
    {
        return [
            'bola' => [
                'keywords' => ['bola golf', 'bola'],
                'answer' => "🏌️ BOLA GOLF\n\n".
                    "Bola golf punya lapisan (layer) berbeda-beda yang memengaruhi jarak, spin, dan feel saat dipukul. Semakin banyak layer, biasanya semakin bagus kontrolnya tapi harganya juga lebih mahal.\n\n".
                    "Kelebihan bola golf premium (contoh: Titleist Pro V1): spin lebih terkontrol, jarak pukulan maksimal, feel lembut saat kena putter. Kekurangannya: harga lebih mahal dan lebih cepat 'wafat' kalau sering nyangkut di rumput/air.\n\n".
                    "Kelebihan bola golf ekonomis/durable (contoh: Callaway Warbird): harganya lebih hemat dan lebih tahan lama (awet dipakai berkali-kali). Kekurangannya: spin & feel-nya tidak sehalus bola premium, jadi kontrol di sekitar green sedikit lebih sulit.\n\n".
                    "Rekomendasi: pemula/latihan santai -> Callaway Warbird (second/baru, hemat & awet). Golfer yang mau tampil maksimal di lapangan -> cari bola premium seperti Titleist Pro V1.",
            ],
            'driver' => [
                'keywords' => ['driver'],
                'answer' => "🏌️ DRIVER (Stik Golf)\n\n".
                    "Driver adalah stik dengan kepala paling besar, dipakai untuk pukulan pertama (tee shot) di lubang par 4 dan par 5, tujuannya jarak sejauh mungkin.\n\n".
                    "Kelebihan: menghasilkan jarak pukulan paling jauh dibanding stik lain, sweet spot besar sehingga lebih 'memaafkan' pukulan yang kurang sempurna (forgiving).\n\n".
                    "Kekurangan: karena kepala besar dan shaft panjang, driver termasuk stik yang paling sulit dikontrol arahnya untuk pemula, mudah melenceng (slice/hook) kalau ayunan belum konsisten.\n\n".
                    "Rekomendasi: pemula sebaiknya pilih driver dengan loft lebih tinggi (10.5-12 derajat) supaya bola lebih mudah naik dan tidak terlalu melenceng.",
            ],
            'fairway' => [
                'keywords' => ['fairway wood', 'kayu fairway'],
                'answer' => "🏌️ FAIRWAY WOOD\n\n".
                    "Fairway wood (biasa disebut 'kayu 3' atau 'kayu 5') dipakai untuk pukulan jarak jauh dari fairway, atau sebagai alternatif driver dari tee box.\n\n".
                    "Kelebihan: lebih mudah dikontrol dibanding driver, tetap bisa hasilkan jarak cukup jauh, cocok dipakai dari rumput pendek maupun agak tinggi.\n\n".
                    "Kekurangan: jaraknya tetap kalah jauh dibanding driver, dan butuh teknik pukulan yang cukup bersih (clean contact) supaya hasil maksimal.\n\n".
                    "Rekomendasi: pemula yang kesulitan pakai driver bisa mulai belajar pakai fairway wood dulu karena lebih forgiving.",
            ],
            'hybrid' => [
                'keywords' => ['hybrid'],
                'answer' => "🏌️ HYBRID\n\n".
                    "Hybrid adalah gabungan antara fairway wood dan iron, bentuknya seperti wood tapi ukurannya lebih kecil, dipakai menggantikan long iron (iron 3-4) yang biasanya susah dipukul pemula.\n\n".
                    "Kelebihan: jauh lebih mudah dipukul dibanding long iron, bola lebih gampang naik, cocok dipakai dari rumput tebal (rough) sekalipun.\n\n".
                    "Kekurangan: kontrol trajectory (lintasan bola) tidak seakurat iron untuk pemain yang sudah mahir, dan jaraknya di bawah fairway wood.\n\n".
                    "Rekomendasi: sangat direkomendasikan untuk pemula atau golfer casual sebagai pengganti iron jarak jauh yang sulit.",
            ],
            'iron' => [
                'keywords' => ['iron', 'besi golf', 'stik besi'],
                'answer' => "🏌️ IRON (Stik Besi)\n\n".
                    "Iron dipakai untuk pukulan jarak menengah menuju green, biasanya satu set berisi beberapa nomor (misal iron 4 sampai 9), semakin besar nomornya, jarak makin pendek tapi bola makin tinggi.\n\n".
                    "Kelebihan: akurasi lebih tinggi dibanding wood/driver, kontrol jarak lebih presisi, cocok untuk approach shot ke green.\n\n".
                    "Kekurangan: butuh teknik ayunan yang lebih rapi supaya kontak bola bersih (clean strike), long iron (nomor kecil) tergolong sulit untuk pemula.\n\n".
                    "Rekomendasi: pemula bisa pilih iron tipe 'game improvement' yang punya sweet spot lebih besar dan lebih forgiving.",
            ],
            'wedge' => [
                'keywords' => ['wedge'],
                'answer' => "🏌️ WEDGE\n\n".
                    "Wedge adalah stik dengan loft paling tinggi, dipakai untuk pukulan jarak dekat (pitching), keluar dari bunker, atau chip di sekitar green.\n\n".
                    "Kelebihan: memberi kontrol spin dan ketinggian bola terbaik untuk pukulan presisi jarak dekat, sangat membantu menurunkan skor di sekitar green.\n\n".
                    "Kekurangan: butuh feel/sentuhan yang halus, kalau belum terbiasa hasil pukulan bisa terlalu jauh (thin) atau malah tertahan tanah (fat/chunk).\n\n".
                    "Rekomendasi: minimal punya 1 wedge (pitching wedge) sudah cukup untuk pemula, baru tambah sand wedge/lob wedge kalau sudah terbiasa main di bunker.",
            ],
            'putter' => [
                'keywords' => ['putter'],
                'answer' => "🏌️ PUTTER\n\n".
                    "Putter dipakai khusus di atas green untuk memasukkan bola ke lubang (putting). Ada dua bentuk utama: blade (bilah tipis) dan mallet (kepala lebih besar/berat).\n\n".
                    "Kelebihan blade: lebih mudah dikontrol untuk golfer dengan gerakan putting konsisten, tampilan klasik dan ringan. Kelebihan mallet: sweet spot lebih besar, lebih stabil/forgiving untuk pemula.\n\n".
                    "Kekurangan blade: kurang forgiving kalau kontak bola meleset dari titik tengah. Kekurangan mallet: bobotnya lebih berat, feel-nya beda dan butuh penyesuaian.\n\n".
                    "Rekomendasi: pemula lebih disarankan pakai putter tipe mallet karena lebih stabil dan memaafkan kesalahan kecil.",
            ],
            'tas' => [
                'keywords' => ['tas golf', 'tas'],
                'answer' => "🏌️ TAS GOLF (Golf Bag)\n\n".
                    "Tas golf berfungsi menyimpan dan membawa seluruh set stik beserta perlengkapan lain saat bermain. Ada 2 tipe utama: cart bag (untuk dipakai di trolley/cart) dan stand bag (punya kaki lipat, bisa ditenteng sendiri).\n\n".
                    "Kelebihan cart bag: kompartemen lebih banyak dan luas, nyaman dipakai kalau main pakai golf cart. Kelebihan stand bag: lebih ringan, praktis dibawa jalan kaki keliling lapangan.\n\n".
                    "Kekurangan cart bag: berat dan kurang praktis kalau harus jalan kaki jauh. Kekurangan stand bag: kapasitas simpan lebih terbatas dibanding cart bag.\n\n".
                    "Rekomendasi: kalau sering main sambil jalan kaki pilih stand bag, kalau sering pakai golf cart pilih cart bag seperti Titleist Golf Cart Bag atau Homma Golf Cart Bag.",
            ],
            'sarung tangan' => [
                'keywords' => ['sarung tangan', 'glove'],
                'answer' => "🏌️ SARUNG TANGAN GOLF (Glove)\n\n".
                    "Sarung tangan golf dipakai di tangan non-dominan (kanan untuk pemain kidal, kiri untuk pemain kanan) supaya grip ke stik lebih kuat dan tidak licin.\n\n".
                    "Kelebihan: meningkatkan cengkraman/grip terutama saat cuaca panas atau berkeringat, mengurangi risiko lecet di tangan.\n\n".
                    "Kekurangan: bahan kulit asli (leather) lebih cepat aus dan perlu diganti berkala, sedangkan bahan sintetis lebih awet tapi grip-nya biasanya sedikit di bawah kulit asli.\n\n".
                    "Rekomendasi: pilih ukuran yang pas (tidak kelonggaran/kesempitan) karena sangat memengaruhi feel saat memegang stik.",
            ],
            'sepatu' => [
                'keywords' => ['sepatu golf', 'sepatu'],
                'answer' => "🏌️ SEPATU GOLF\n\n".
                    "Sepatu golf dirancang khusus supaya kaki tetap stabil (grip ke tanah kuat) saat melakukan ayunan (swing), berbeda dari sepatu olahraga biasa.\n\n".
                    "Kelebihan sepatu bersepatu (spiked): traksi/cengkraman ke tanah paling maksimal, sangat membantu di lapangan basah/licin. Kelebihan sepatu tanpa pul (spikeless): lebih nyaman dipakai sehari-hari, ringan, dan tetap punya grip cukup baik di kondisi kering.\n\n".
                    "Kekurangan spiked: kurang nyaman kalau dipakai jalan lama di permukaan keras. Kekurangan spikeless: traksi sedikit di bawah spiked terutama di tanah basah/menanjak.\n\n".
                    "Rekomendasi: pemain casual/santai cukup pakai spikeless, pemain yang sering main di kondisi basah sebaiknya pilih spiked.",
            ],
            'tee' => [
                'keywords' => ['tee golf', ' tee ', 'tee,'],
                'answer' => "🏌️ TEE GOLF\n\n".
                    "Tee adalah pasak kecil (biasanya dari kayu atau plastik) untuk menyangga bola saat pukulan pertama (tee shot), supaya bola tidak menyentuh tanah langsung.\n\n".
                    "Kelebihan tee kayu: harganya murah, ramah lingkungan, dan mudah didapat. Kelebihan tee plastik: lebih tahan lama dan tidak gampang patah dibanding kayu.\n\n".
                    "Kekurangan tee kayu: gampang patah terutama kalau kena pukulan driver yang keras. Kekurangan tee plastik: sedikit lebih mahal dan kurang ramah lingkungan.\n\n".
                    "Rekomendasi: selalu bawa cadangan tee lebih dari satu karena barang ini paling sering hilang/patah saat main.",
            ],
            'trolley' => [
                'keywords' => ['trolley', 'golf cart', 'cart golf'],
                'answer' => "🏌️ TROLLEY / GOLF CART\n\n".
                    "Trolley adalah alat beroda (manual atau elektrik) untuk membawa tas golf berkeliling lapangan tanpa perlu ditenteng.\n\n".
                    "Kelebihan trolley manual: harga lebih terjangkau, ringan dan mudah dilipat. Kelebihan trolley elektrik: hemat tenaga karena jalan sendiri mengikuti remote/sensor, sangat membantu di lapangan yang luas atau berbukit.\n\n".
                    "Kekurangan trolley manual: tetap harus didorong sendiri sepanjang permainan, cukup melelahkan di lapangan luas. Kekurangan trolley elektrik: harganya jauh lebih mahal dan butuh perawatan baterai.\n\n".
                    "Rekomendasi: untuk pemain casual/hemat, trolley manual sudah cukup membantu dibanding menenteng tas sendiri.",
            ],
            'topi' => [
                'keywords' => ['topi golf', 'topi', 'cap golf'],
                'answer' => "🏌️ TOPI GOLF\n\n".
                    "Topi golf melindungi wajah dan mata dari sinar matahari langsung selama bermain, biasanya berbentuk cap atau bucket hat.\n\n".
                    "Kelebihan: melindungi dari panas & silau matahari sehingga pandangan ke bola lebih jelas, juga menyerap keringat di area kepala.\n\n".
                    "Kekurangan: perlindungan area leher/telinga terbatas dibanding bucket hat yang bentuknya lebih lebar.\n\n".
                    "Rekomendasi: pilih bahan yang menyerap keringat (quick-dry) supaya nyaman dipakai seharian di lapangan.",
            ],
            'grip' => [
                'keywords' => ['grip stik', 'grip golf', 'grip'],
                'answer' => "🏌️ GRIP STIK GOLF\n\n".
                    "Grip adalah lapisan karet/sintetis yang membungkus pegangan stik. Kondisi grip sangat memengaruhi kualitas pegangan dan hasil pukulan.\n\n".
                    "Kelebihan grip baru: cengkraman lebih maksimal, mengurangi risiko stik terpuntir/terlepas saat swing. Kekurangan grip yang sudah aus: licin terutama saat berkeringat atau lapangan lembap, bisa memengaruhi konsistensi pukulan.\n\n".
                    "Rekomendasi: ganti grip minimal setahun sekali (atau lebih sering kalau sering main), terutama kalau permukaannya sudah terasa licin atau mengkilap.",
            ],
            'titleist' => [
                'keywords' => ['titleist'],
                'answer' => "🏷️ TITLEIST\n\n".
                    "Titleist dikenal sebagai raja bola golf dunia (Pro V1 dipakai banyak pro tour), dan juga punya lini stik/iron kelas atas.\n\n".
                    "Keunggulan: kualitas & konsistensi produk sangat tinggi, spin dan feel bola golf-nya termasuk terbaik di kelasnya, sangat cocok untuk golfer yang serius meningkatkan performa.\n\n".
                    "Kekurangan: harga di kelas premium, jadi kurang cocok untuk pemula yang baru belajar dan sering kehilangan bola.\n\n".
                    "Cocok untuk: golfer menengah ke atas yang mengutamakan performa dan sudah punya swing cukup konsisten.",
            ],
            'callaway' => [
                'keywords' => ['callaway'],
                'answer' => "🏷️ CALLAWY\n\n".
                    "Callaway punya lini produk yang luas, dari bola golf ekonomis (seperti Warbird) sampai driver/iron teknologi tinggi.\n\n".
                    "Keunggulan: pilihan produk sangat beragam untuk semua level (pemula sampai mahir), teknologi head driver-nya terkenal membantu jarak pukulan lebih jauh, harga cukup bersaing dibanding Titleist.\n\n".
                    "Kekurangan: beberapa lini entry-level tidak se-presisi lini premium Titleist untuk kontrol spin.\n\n".
                    "Cocok untuk: golfer segala level, terutama yang cari keseimbangan antara harga dan performa.",
            ],
            'taylormade' => [
                'keywords' => ['taylormade', 'taylor made'],
                'answer' => "🏷️ TAYLORMADE\n\n".
                    "TaylorMade terkenal lewat inovasi teknologi driver & fairway wood-nya, sering jadi pilihan pemain profesional untuk jarak maksimal.\n\n".
                    "Keunggulan: teknologi head driver termutakhir menghasilkan jarak pukulan sangat jauh, desain stik modern dan sering update model tiap tahun.\n\n".
                    "Kekurangan: karena sering rilis model baru, harga model terbaru cenderung mahal, sedangkan model lama lebih terjangkau tapi teknologinya sedikit ketinggalan.\n\n".
                    "Cocok untuk: golfer yang fokus mengejar jarak pukulan maksimal (terutama driver).",
            ],
            'ping' => [
                'keywords' => ['ping'],
                'answer' => "🏷️ PING\n\n".
                    "PING dikenal dengan iron & putter yang sangat presisi, banyak dipakai golfer yang mengutamakan akurasi dan konsistensi.\n\n".
                    "Keunggulan: sweet spot besar dan sangat forgiving (memaafkan pukulan kurang sempurna), custom fitting-nya termasuk paling detail di industri.\n\n".
                    "Kekurangan: pilihan model tidak se-flashy/trendy brand lain, lebih fokus ke fungsi daripada gaya.\n\n".
                    "Cocok untuk: golfer yang mengutamakan akurasi & konsistensi, termasuk pemula yang butuh stik forgiving.",
            ],
            'mizuno' => [
                'keywords' => ['mizuno'],
                'answer' => "🏷️ MIZUNO\n\n".
                    "Mizuno sangat terkenal dengan kualitas iron buatan tangan (forged iron) yang punya feel lembut khas saat kontak dengan bola.\n\n".
                    "Keunggulan: feel/sentuhan iron-nya termasuk paling halus di industri, sangat disukai golfer yang mementingkan feedback saat memukul.\n\n".
                    "Kekurangan: iron forged Mizuno kurang forgiving untuk pemula, karena sweet spot lebih kecil dibanding iron 'game improvement' merek lain.\n\n".
                    "Cocok untuk: golfer menengah-mahir yang sudah punya kontak bola (ball striking) konsisten.",
            ],
            'honma' => [
                'keywords' => ['honma'],
                'answer' => "🏷️ HONMA\n\n".
                    "Honma adalah brand asal Jepang yang identik dengan kualitas premium dan detail craftsmanship, termasuk untuk tas golf.\n\n".
                    "Keunggulan: material dan finishing produk kelas atas, desain elegan, tas golf Honma terkenal ringan tapi tetap kokoh.\n\n".
                    "Kekurangan: harga cenderung lebih tinggi dibanding brand sekelas karena positioning premium.\n\n".
                    "Cocok untuk: golfer yang mengutamakan kualitas material dan tampilan premium, termasuk untuk tas golf.",
            ],
            'srixon' => [
                'keywords' => ['srixon'],
                'answer' => "🏷️ SRIXON\n\n".
                    "Srixon dikenal sebagai alternatif bola golf & stik berkualitas dengan harga lebih terjangkau dibanding brand premium lain.\n\n".
                    "Keunggulan: rasio harga terhadap performa (value for money) sangat baik, bola golf-nya cukup kompetitif dengan Titleist di kelas menengah.\n\n".
                    "Kekurangan: brand image tidak se-prestis Titleist/TaylorMade, walau performanya sebenarnya tidak kalah jauh.\n\n".
                    "Cocok untuk: golfer yang cari performa bagus tanpa harus bayar harga brand premium.",
            ],
            'cleveland' => [
                'keywords' => ['cleveland'],
                'answer' => "🏷️ CLEVELAND\n\n".
                    "Cleveland Golf adalah spesialis wedge, sangat dikenal di kalangan golfer yang serius soal permainan jarak dekat (short game).\n\n".
                    "Keunggulan: spin control wedge-nya termasuk terbaik, groove pada permukaan wedge dirancang khusus untuk kontrol presisi di sekitar green.\n\n".
                    "Kekurangan: lini produk di luar wedge (seperti driver) tidak seterkenal brand lain.\n\n".
                    "Cocok untuk: golfer yang ingin memperbaiki short game (pitching, chipping, bunker).",
            ],
            'cobra' => [
                'keywords' => ['cobra'],
                'answer' => "🏷️ COBRA\n\n".
                    "Cobra Golf dikenal dengan desain stik yang berani/modern dan cukup banyak opsi kustomisasi (adjustable loft/weight).\n\n".
                    "Keunggulan: banyak fitur yang bisa disesuaikan (adjustable), harga relatif lebih terjangkau dibanding brand sekelas, desain menarik untuk golfer muda.\n\n".
                    "Kekurangan: kurang punya lini bola golf premium sekuat kompetitor seperti Titleist/Callaway.\n\n".
                    "Cocok untuk: golfer yang suka eksperimen setting stik sendiri (adjustable driver/fairway).",
            ],
        ];
    }

    public function chat(Request $request)
    {
        $input = strtolower((string) $request->message);

        if (str_contains($input, 'alat golf') || str_contains($input, 'peralatan golf') || str_contains($input, 'perlengkapan golf')) {
            return response()->json(['reply' =>
                "🏌️ PERALATAN GOLF SECARA UMUM\n\n".
                "Peralatan golf lengkap biasanya terdiri dari:\n".
                "1. Stik golf (driver, fairway wood, hybrid, iron, wedge, putter)\n".
                "2. Bola golf\n".
                "3. Tas golf (cart bag / stand bag)\n".
                "4. Sarung tangan golf\n".
                "5. Sepatu golf\n".
                "6. Tee golf\n".
                "7. Trolley/golf cart\n".
                "8. Topi golf\n".
                "9. Grip stik\n\n".
                "Tanya saja ke saya nama alatnya (misalnya 'driver itu apa' atau 'kelebihan wedge'), nanti saya jelasin detail beserta kelebihan-kekurangannya. Kalau mau tau rekomendasi, tambahkan kata 'rekomendasi' ya, misal 'rekomendasi bola golf'. Kamu juga bisa tanya soal merek, misal 'apa itu Titleist' atau ketik 'merek golf' untuk lihat daftar semua merek.",
            ]);
        }

        if (str_contains($input, 'merek') || str_contains($input, 'brand')) {
            return response()->json(['reply' =>
                "🏷️ MEREK GOLF YANG BISA SAYA JELASKAN\n\n".
                "1. Titleist — kualitas & performa nomor satu, favorit golfer serius\n".
                "2. Callaway — pilihan lengkap semua level, harga bersaing\n".
                "3. TaylorMade — juara teknologi driver, jarak pukulan maksimal\n".
                "4. PING — iron & putter paling presisi, sangat forgiving\n".
                "5. Mizuno — feel iron paling halus, favorit golfer mahir\n".
                "6. Honma — kualitas material premium asal Jepang\n".
                "7. Srixon — value for money terbaik\n".
                "8. Cleveland — spesialis wedge/short game\n".
                "9. Cobra — desain modern & adjustable\n\n".
                "Ketik nama mereknya untuk penjelasan lengkap keunggulan & kekurangannya, misal 'kelebihan Titleist' atau 'Callaway itu apa'.",
            ]);
        }

        $knowledge = $this->knowledgeBase();

        foreach ($knowledge as $topic => $data) {
            foreach ($data['keywords'] as $keyword) {
                if (str_contains($input, $keyword)) {
                    return response()->json(['reply' => $data['answer']]);
                }
            }
        }

        if (str_contains($input, 'harga')) {
            return response()->json(['reply' => 'Semua produk golf kami saat ini dibanderol dengan harga Rp300.000. Cek halaman Produk untuk detail lengkap tiap item ya!']);
        }

        return response()->json(['reply' => 'Maaf, saya belum memiliki informasi tersebut. Coba tanya soal peralatan golf seperti "driver", "iron", "putter", "tas golf", atau merek seperti "Titleist", "Callaway", "TaylorMade", dll, atau tanyakan langsung ke admin kami melalui menu Chat ya!']);
    }
}
