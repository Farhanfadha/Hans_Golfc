

<?php $__env->startSection('content'); ?>
<style>
    .orders-page {
        padding-bottom: 50px;
    }

    .orders-header {
        background: linear-gradient(135deg, #111827, #1f2937);
        color: white;
        border-radius: 28px;
        padding: 34px;
        margin-bottom: 28px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.12);
    }

    .orders-title {
        font-size: 34px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .orders-subtitle {
        color: rgba(255,255,255,0.82);
        margin-bottom: 0;
    }

    .order-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 22px;
        padding: 22px;
        margin-bottom: 16px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
        transition: 0.2s;
    }

    .order-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 18px 34px rgba(15, 23, 42, 0.1);
    }

    .order-code {
        font-size: 20px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 4px;
    }

    .order-date {
        color: #64748b;
        font-size: 14px;
    }

    .order-total {
        font-size: 22px;
        font-weight: 900;
        color: #ca8a04;
        margin-bottom: 4px;
    }

    .status-badge-custom {
        display: inline-block;
        padding: 7px 12px;
        border-radius: 999px;
        font-size: 13px;
        font-weight: 800;
        margin-right: 6px;
        margin-bottom: 6px;
    }

    .status-order-new {
        background: #f1f5f9;
        color: #334155;
    }

    .status-order-processing {
        background: #dbeafe;
        color: #1e40af;
    }

    .status-order-completed {
        background: #dcfce7;
        color: #166534;
    }

    .status-order-cancelled {
        background: #fee2e2;
        color: #991b1b;
    }

    .status-payment-pending {
        background: #fef3c7;
        color: #92400e;
    }

    .status-payment-waiting {
        background: #dbeafe;
        color: #1e40af;
    }

    .status-payment-paid {
        background: #dcfce7;
        color: #166534;
    }

    .status-payment-rejected {
        background: #fee2e2;
        color: #991b1b;
    }

    .status-shipping-not-shipped {
        background: #fef3c7;
        color: #92400e;
    }

    .status-shipping-shipped {
        background: #dcfce7;
        color: #166534;
    }

    .btn-detail-order {
        background: #111827;
        color: white;
        border-radius: 14px;
        padding: 10px 16px;
        text-decoration: none;
        font-weight: 800;
        display: inline-block;
        border: none;
    }

    .btn-detail-order:hover {
        background: #1f2937;
        color: white;
    }

    .btn-review-order {
        background: #f59e0b;
        color: white;
        border-radius: 14px;
        padding: 10px 16px;
        text-decoration: none;
        font-weight: 800;
        display: inline-block;
        border: none;
        margin-bottom: 8px;
    }

    .btn-review-order:hover {
        background: #d97706;
        color: white;
    }

    .review-panel {
        margin-top: 18px;
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 20px;
        padding: 20px;
    }

    .review-panel-title {
        font-size: 20px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 6px;
    }

    .review-panel-subtitle {
        color: #64748b;
        font-weight: 600;
        margin-bottom: 18px;
    }

    .review-item-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        padding: 18px;
        margin-bottom: 16px;
    }

    .review-product-name {
        font-size: 17px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 4px;
    }

    .review-product-meta {
        color: #64748b;
        font-size: 14px;
        margin-bottom: 14px;
    }

    .review-done-alert {
        background: #dcfce7;
        color: #166534;
        border: 1px solid #bbf7d0;
        border-radius: 14px;
        padding: 10px 12px;
        font-weight: 700;
        margin-bottom: 14px;
    }

    .form-control,
    .form-select {
        border-radius: 14px;
        border: 1px solid #dbe3ec;
        min-height: 48px;
    }

    textarea.form-control {
        min-height: 90px;
    }

    .btn-submit-review {
        background: linear-gradient(135deg, #16a34a, #15803d);
        color: white;
        border: none;
        border-radius: 16px;
        padding: 14px 24px;
        font-weight: 900;
        min-width: 220px;
        box-shadow: 0 10px 22px rgba(22, 163, 74, 0.25);
        transition: 0.2s ease;
    }

    .btn-submit-review:hover {
        background: linear-gradient(135deg, #15803d, #166534);
        color: white;
        transform: translateY(-1px);
        box-shadow: 0 14px 28px rgba(22, 163, 74, 0.32);
    }

    .btn-submit-review:active {
        transform: translateY(0);
        box-shadow: 0 8px 18px rgba(22, 163, 74, 0.22);
    }

    .empty-card {
        background: white;
        border-radius: 24px;
        padding: 42px;
        text-align: center;
        border: 1px solid #e5e7eb;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
    }

    .btn-shop {
        background: #16a34a;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: 800;
        display: inline-block;
        margin-top: 18px;
    }

    .btn-shop:hover {
        background: #15803d;
        color: white;
    }

    @media (max-width: 991.98px) {
        .orders-title {
            font-size: 28px;
        }

        .order-card {
            padding: 18px;
        }

        .btn-detail-order,
        .btn-review-order {
            width: 100%;
            text-align: center;
        }

        .btn-submit-review {
            width: 100%;
            min-width: unset;
        }
    }
</style>

<?php
    $orderStatusLabels = [
        'new' => 'Order Baru',
        'processing' => 'Diproses',
        'completed' => 'Selesai',
        'cancelled' => 'Dibatalkan',
    ];

    $orderStatusClasses = [
        'new' => 'status-order-new',
        'processing' => 'status-order-processing',
        'completed' => 'status-order-completed',
        'cancelled' => 'status-order-cancelled',
    ];

    $paymentStatusLabels = [
        'pending' => 'Menunggu Pembayaran',
        'waiting_confirmation' => 'Menunggu Konfirmasi',
        'paid' => 'Lunas',
        'rejected' => 'Pembayaran Ditolak',
    ];

    $paymentStatusClasses = [
        'pending' => 'status-payment-pending',
        'waiting_confirmation' => 'status-payment-waiting',
        'paid' => 'status-payment-paid',
        'rejected' => 'status-payment-rejected',
    ];

    $shippingStatusLabels = [
        'not_shipped' => 'Belum Dikirim',
        'shipped' => 'Sudah Dikirim',
    ];

    $shippingStatusClasses = [
        'not_shipped' => 'status-shipping-not-shipped',
        'shipped' => 'status-shipping-shipped',
    ];
?>

<div class="container orders-page">
    <div class="orders-header">
        <h1 class="orders-title">Pesanan Saya</h1>
        <p class="orders-subtitle">
            Pantau status pesanan, pembayaran, pengiriman, dan berikan ulasan produk yang sudah selesai.
        </p>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-4">
            <strong>Terjadi kesalahan.</strong>
            <ul class="mb-0 mt-2">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if($orders->count() > 0): ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $orderStatus = $order->status ?? 'new';
                $paymentStatus = $order->payment_status ?? 'pending';
                $shippingStatus = $order->shipping_status ?? 'not_shipped';

                $reviewedItems = $order->items->filter(function ($item) {
                    return !is_null($item->review);
                })->count();

                $totalItems = $order->items->count();
            ?>

            <div class="order-card">
                <div class="row align-items-center g-3">
                    <div class="col-lg-3">
                        <div class="order-code"><?php echo e($order->order_code); ?></div>
                        <div class="order-date">
                            Dibuat pada <?php echo e($order->created_at->format('d M Y H:i')); ?>

                        </div>
                    </div>

                    <div class="col-lg-3">
                        <div class="order-total">
                            Rp <?php echo e(number_format($order->total_price, 0, ',', '.')); ?>

                        </div>

                        <div class="text-muted">
                            <?php echo e($order->items->count()); ?> item pesanan
                        </div>

                        <?php if($shippingStatus === 'shipped' && $order->tracking_number): ?>
                            <div class="mt-2 text-muted" style="font-size: 13px;">
                                Resi: <strong><?php echo e($order->tracking_number); ?></strong>
                            </div>
                        <?php endif; ?>

                        <?php if($orderStatus === 'completed'): ?>
                            <div class="mt-2 text-muted" style="font-size: 13px;">
                                Ulasan:
                                <strong><?php echo e($reviewedItems); ?>/<?php echo e($totalItems); ?></strong>
                                produk
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="col-lg-4">
                        <span class="status-badge-custom <?php echo e($orderStatusClasses[$orderStatus] ?? 'status-order-new'); ?>">
                            <?php echo e($orderStatusLabels[$orderStatus] ?? $orderStatus); ?>

                        </span>

                        <span class="status-badge-custom <?php echo e($paymentStatusClasses[$paymentStatus] ?? 'status-payment-pending'); ?>">
                            <?php echo e($paymentStatusLabels[$paymentStatus] ?? $paymentStatus); ?>

                        </span>

                        <span class="status-badge-custom <?php echo e($shippingStatusClasses[$shippingStatus] ?? 'status-shipping-not-shipped'); ?>">
                            <?php echo e($shippingStatusLabels[$shippingStatus] ?? 'Belum Dikirim'); ?>

                        </span>
                    </div>

                    <div class="col-lg-2 text-lg-end">
                        <?php if($orderStatus === 'completed'): ?>
                            <button class="btn-review-order"
                                    type="button"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#reviewPanel<?php echo e($order->id); ?>"
                                    aria-expanded="false"
                                    aria-controls="reviewPanel<?php echo e($order->id); ?>">
                                <?php echo e($reviewedItems > 0 ? 'Edit Ulasan' : 'Beri Ulasan'); ?>

                            </button>
                        <?php endif; ?>

                        <a href="<?php echo e(route('orders.show', $order->id)); ?>" class="btn-detail-order">
                            Lihat Detail
                        </a>
                    </div>
                </div>

                <?php if($orderStatus === 'completed'): ?>
                    <div class="collapse" id="reviewPanel<?php echo e($order->id); ?>">
                        <div class="review-panel">
                            <div class="review-panel-title">
                                Ulasan Produk
                            </div>

                            <div class="review-panel-subtitle">
                                Berikan rating dan ulasan untuk semua produk yang sudah Anda beli, lalu klik satu kali tombol kirim.
                            </div>

                            <form action="<?php echo e(route('reviews.batchStore', $order->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="review-item-card">
                                        <div class="review-product-name">
                                            <?php echo e($item->product_name); ?>

                                        </div>

                                        <div class="review-product-meta">
                                            <?php echo e($item->quantity); ?> x Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?>

                                        </div>

                                        <?php if($item->review): ?>
                                            <div class="review-done-alert">
                                                Anda sudah memberi ulasan untuk produk ini. Anda masih bisa mengubahnya.
                                            </div>
                                        <?php endif; ?>

                                        <div class="row g-3">
                                            <div class="col-lg-4">
                                                <label class="form-label fw-bold">Rating Bintang</label>

                                                <select name="reviews[<?php echo e($item->id); ?>][rating]" class="form-select" required>
                                                    <option value="">Pilih Rating</option>

                                                    <option value="5" <?php echo e(old('reviews.' . $item->id . '.rating', optional($item->review)->rating) == 5 ? 'selected' : ''); ?>>
                                                        ⭐⭐⭐⭐⭐ - Sangat Puas
                                                    </option>

                                                    <option value="4" <?php echo e(old('reviews.' . $item->id . '.rating', optional($item->review)->rating) == 4 ? 'selected' : ''); ?>>
                                                        ⭐⭐⭐⭐ - Puas
                                                    </option>

                                                    <option value="3" <?php echo e(old('reviews.' . $item->id . '.rating', optional($item->review)->rating) == 3 ? 'selected' : ''); ?>>
                                                        ⭐⭐⭐ - Cukup
                                                    </option>

                                                    <option value="2" <?php echo e(old('reviews.' . $item->id . '.rating', optional($item->review)->rating) == 2 ? 'selected' : ''); ?>>
                                                        ⭐⭐ - Kurang
                                                    </option>

                                                    <option value="1" <?php echo e(old('reviews.' . $item->id . '.rating', optional($item->review)->rating) == 1 ? 'selected' : ''); ?>>
                                                        ⭐ - Tidak Puas
                                                    </option>
                                                </select>
                                            </div>

                                            <div class="col-lg-8">
                                                <label class="form-label fw-bold">Ulasan</label>

                                                <textarea name="reviews[<?php echo e($item->id); ?>][review]"
                                                          class="form-control"
                                                          rows="2"
                                                          placeholder="Ceritakan pengalaman Anda membeli produk ini..."><?php echo e(old('reviews.' . $item->id . '.review', optional($item->review)->review)); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <div class="text-end mt-3">
                                    <button type="submit" class="btn-submit-review">
                                        Kirim Semua Ulasan
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="mt-4">
            <?php echo e($orders->links()); ?>

        </div>
    <?php else: ?>
        <div class="empty-card">
            <h3>Belum Ada Pesanan</h3>
            <p class="text-muted mb-0">
                Anda belum membuat pesanan. Silakan pilih produk Hans Golf terlebih dahulu.
            </p>

            <a href="<?php echo e(route('products.index')); ?>" class="btn-shop">
                Belanja Sekarang
            </a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\farha\hans-golfc\resources\views/orders/index.blade.php ENDPATH**/ ?>