

<?php $__env->startSection('content'); ?>
<style>
    .products-page {
        padding-bottom: 60px;
    }

    .products-header {
        text-align: center;
        margin-bottom: 26px;
    }

    .products-title {
        font-size: 42px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 10px;
    }

    .products-subtitle {
        color: #64748b;
        font-weight: 600;
        margin-bottom: 0;
    }

    .filter-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 24px;
        padding: 22px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
        margin-bottom: 26px;
        position: relative;
        z-index: 20;
    }

    .form-control {
        border-radius: 14px;
        min-height: 48px;
        border: 1px solid #dbe3ec;
        font-weight: 600;
    }

    .form-control:focus {
        border-color: #94a3b8;
        box-shadow: 0 0 0 0.2rem rgba(148, 163, 184, 0.18);
    }

    .category-dropdown {
        position: relative;
    }

    .category-dropdown-button {
        width: 100%;
        min-height: 48px;
        background: #ffffff;
        border: 1px solid #dbe3ec;
        border-radius: 14px;
        padding: 0 14px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        font-weight: 800;
        color: #0f172a;
        transition: 0.2s ease;
    }

    .category-dropdown-button:hover {
        background: #f8fafc;
        border-color: #cbd5e1;
    }

    .category-dropdown-button.active {
        border-color: #0f172a;
        box-shadow: 0 0 0 0.2rem rgba(15, 23, 42, 0.10);
    }

    .category-selected-left {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
    }

    .category-selected-icon {
        width: 32px;
        height: 32px;
        border-radius: 999px;
        background: #f1f5f9;
        color: #0f172a;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        flex-shrink: 0;
    }

    .category-selected-text {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .category-chevron {
        color: #64748b;
        transition: 0.2s ease;
        flex-shrink: 0;
    }

    .category-dropdown-button.active .category-chevron {
        transform: rotate(180deg);
    }

    .category-dropdown-menu {
        display: none;
        position: absolute;
        left: 0;
        right: 0;
        top: calc(100% + 10px);
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        padding: 10px;
        box-shadow: 0 18px 42px rgba(15, 23, 42, 0.16);
        z-index: 99;
        max-height: 310px;
        overflow-y: auto;
    }

    .category-dropdown-menu.show {
        display: block;
        animation: dropdownFade 0.16s ease;
    }

    .category-option {
        width: 100%;
        border: none;
        background: transparent;
        border-radius: 14px;
        padding: 11px 12px;
        color: #0f172a;
        font-weight: 800;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        text-align: left;
        transition: 0.15s ease;
    }

    .category-option:hover {
        background: #f8fafc;
    }

    .category-option.active {
        background: #0f172a;
        color: white;
    }

    .category-option-left {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
    }

    .category-option-icon {
        width: 34px;
        height: 34px;
        border-radius: 999px;
        background: #f1f5f9;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }

    .category-option.active .category-option-icon {
        background: rgba(255,255,255,0.14);
    }

    .category-option-name {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .category-check {
        opacity: 0;
        font-weight: 900;
    }

    .category-option.active .category-check {
        opacity: 1;
    }

    .btn-filter {
        background: #111827;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 12px 18px;
        font-weight: 900;
        min-height: 48px;
    }

    .btn-filter:hover {
        background: #1f2937;
        color: white;
    }

    .btn-reset {
        background: #64748b;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        font-weight: 900;
        text-decoration: none;
        min-height: 48px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .btn-reset:hover {
        background: #475569;
        color: white;
    }

    .category-shortcuts {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 18px;
    }

    .category-shortcut {
        background: #f8fafc;
        color: #0f172a;
        border: 1px solid #e2e8f0;
        border-radius: 999px;
        padding: 9px 14px;
        text-decoration: none;
        font-weight: 800;
        font-size: 14px;
        transition: 0.2s ease;
    }

    .category-shortcut:hover {
        background: #e2e8f0;
        color: #0f172a;
    }

    .category-shortcut.active {
        background: #111827;
        color: white;
        border-color: #111827;
    }

    .active-filter {
        background: #ecfdf5;
        border: 1px solid #bbf7d0;
        color: #166534;
        border-radius: 16px;
        padding: 12px 16px;
        font-weight: 800;
        margin-bottom: 24px;
    }

    .product-card {
        background: white;
        border-radius: 26px;
        overflow: hidden;
        border: 1px solid #e5e7eb;
        box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
        height: 100%;
        transition: 0.22s ease;
        cursor: pointer;
        position: relative;
    }

    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 24px 44px rgba(15, 23, 42, 0.14);
    }

    .product-card:focus {
        outline: 3px solid rgba(59, 130, 246, 0.35);
        outline-offset: 4px;
    }

    .product-image-wrap {
        height: 230px;
        background: #f8fafc;
        overflow: hidden;
        position: relative;
    }

    .product-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: 0.25s ease;
    }

    .product-card:hover .product-image {
        transform: scale(1.04);
    }

    .product-placeholder {
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #64748b;
        font-size: 58px;
        background: #f1f5f9;
    }

    .category-pill {
        display: inline-block;
        background: #f1f5f9;
        color: #334155;
        padding: 8px 13px;
        border-radius: 999px;
        font-size: 13px;
        font-weight: 800;
        margin-bottom: 14px;
    }

    .product-body {
        padding: 22px;
    }

    .product-name {
        font-size: 22px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 12px;
        line-height: 1.3;
    }

    .rating-line {
        color: #f59e0b;
        font-weight: 900;
        font-size: 14px;
        margin-bottom: 12px;
    }

    .rating-muted {
        color: #64748b;
        font-weight: 600;
    }

    .price-text {
        font-size: 22px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 12px;
    }

    .stock-badge {
        display: inline-block;
        padding: 8px 12px;
        border-radius: 999px;
        font-size: 13px;
        font-weight: 800;
        margin-bottom: 18px;
    }

    .stock-ready {
        background: #dcfce7;
        color: #166534;
    }

    .stock-empty {
        background: #fee2e2;
        color: #991b1b;
    }

    .product-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 10px;
        margin-top: 4px;
    }

    .btn-detail {
        background: #e2e8f0;
        color: #0f172a;
        border-radius: 14px;
        padding: 12px 14px;
        text-decoration: none;
        font-weight: 900;
        text-align: center;
        display: inline-block;
        border: none;
        position: relative;
        z-index: 5;
    }

    .btn-detail:hover {
        background: #cbd5e1;
        color: #0f172a;
    }

    .btn-cart {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 12px 14px;
        font-weight: 900;
        width: 100%;
        position: relative;
        z-index: 5;
    }

    .btn-cart:hover {
        background: #15803d;
        color: white;
    }

    .btn-cart:disabled {
        background: #94a3b8;
        cursor: not-allowed;
    }

    .empty-card {
        background: white;
        border-radius: 24px;
        padding: 44px;
        text-align: center;
        border: 1px solid #e5e7eb;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
    }

    @keyframes dropdownFade {
        from {
            opacity: 0;
            transform: translateY(-6px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media (max-width: 768px) {
        .products-title {
            font-size: 34px;
        }

        .product-actions {
            grid-template-columns: 1fr;
        }

        .product-image-wrap {
            height: 190px;
        }
    }
</style>

<?php
    $categoryIcons = ['🏌️', '⛳', '🎒', '🧤', '🏆', '👟', '🧢', '⭐'];
    $selectedCategoryId = request('category');
    $selectedCategoryName = $selectedCategory ? $selectedCategory->name : 'Semua Kategori';
    $selectedCategoryIcon = '🏷️';

    if ($selectedCategory) {
        foreach ($categories as $index => $category) {
            if ((string) $category->id === (string) $selectedCategory->id) {
                $selectedCategoryIcon = $categoryIcons[$index % count($categoryIcons)];
                break;
            }
        }
    }
?>

<div class="container products-page">
    <div class="products-header">
        <h1 class="products-title">Daftar Produk</h1>

        <p class="products-subtitle">
            Temukan perlengkapan golf terbaik untuk kebutuhan permainan Anda.
        </p>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="filter-card">
        <form action="<?php echo e(route('products.index')); ?>" method="GET" id="productFilterForm">
            <input type="hidden" name="category" id="categoryInput" value="<?php echo e(request('category')); ?>">

            <div class="row g-3 align-items-end">
                <div class="col-lg-5">
                    <label class="form-label fw-bold">Cari Produk</label>
                    <input type="text"
                           name="search"
                           class="form-control"
                           value="<?php echo e(request('search')); ?>"
                           placeholder="Cari nama produk...">
                </div>

                <div class="col-lg-4">
                    <label class="form-label fw-bold">Kategori</label>

                    <div class="category-dropdown">
                        <button type="button" class="category-dropdown-button" id="categoryDropdownButton">
                            <span class="category-selected-left">
                                <span class="category-selected-icon" id="categorySelectedIcon">
                                    <?php echo e($selectedCategoryIcon); ?>

                                </span>

                                <span class="category-selected-text" id="categorySelectedText">
                                    <?php echo e($selectedCategoryName); ?>

                                </span>
                            </span>

                            <span class="category-chevron">⌄</span>
                        </button>

                        <div class="category-dropdown-menu" id="categoryDropdownMenu">
                            <button type="button"
                                    class="category-option <?php echo e(request('category') ? '' : 'active'); ?>"
                                    data-category-id=""
                                    data-category-name="Semua Kategori"
                                    data-category-icon="🏷️">
                                <span class="category-option-left">
                                    <span class="category-option-icon">🏷️</span>
                                    <span class="category-option-name">Semua Kategori</span>
                                </span>

                                <span class="category-check">✓</span>
                            </button>

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $icon = $categoryIcons[$loop->index % count($categoryIcons)];
                                ?>

                                <button type="button"
                                        class="category-option <?php echo e(request('category') == $category->id ? 'active' : ''); ?>"
                                        data-category-id="<?php echo e($category->id); ?>"
                                        data-category-name="<?php echo e($category->name); ?>"
                                        data-category-icon="<?php echo e($icon); ?>">
                                    <span class="category-option-left">
                                        <span class="category-option-icon"><?php echo e($icon); ?></span>
                                        <span class="category-option-name"><?php echo e($category->name); ?></span>
                                    </span>

                                    <span class="category-check">✓</span>
                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn-filter flex-fill">
                            Filter
                        </button>

                        <a href="<?php echo e(route('products.index')); ?>" class="btn-reset">
                            Reset
                        </a>
                    </div>
                </div>
            </div>
        </form>

        <div class="category-shortcuts">
            <a href="<?php echo e(route('products.index')); ?>"
               class="category-shortcut <?php echo e(request('category') ? '' : 'active'); ?>">
                Semua
            </a>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('products.index', ['category' => $category->id])); ?>"
                   class="category-shortcut <?php echo e(request('category') == $category->id ? 'active' : ''); ?>">
                    <?php echo e($category->name); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <?php if($selectedCategory): ?>
        <div class="active-filter">
            Menampilkan produk kategori:
            <strong><?php echo e($selectedCategory->name); ?></strong>
        </div>
    <?php endif; ?>

    <?php if($products->count() > 0): ?>
        <div class="row g-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $avgRating = $product->reviews_avg_rating ? round($product->reviews_avg_rating, 1) : 0;
                    $reviewCount = $product->reviews_count ?? 0;
                    $detailUrl = route('products.show', $product->slug);
                ?>

                <div class="col-md-6 col-lg-4">
                    <div class="product-card"
                         data-url="<?php echo e($detailUrl); ?>"
                         role="link"
                         tabindex="0"
                         aria-label="Lihat detail <?php echo e($product->name); ?>">
                        <div class="product-image-wrap">
                            <?php if($product->image): ?>
                                <img src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                     alt="<?php echo e($product->name); ?>"
                                     class="product-image">
                            <?php else: ?>
                                <div class="product-placeholder">
                                    🏌️
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="product-body">
                            <div class="category-pill">
                                <?php echo e(optional($product->category)->name ?? 'Tanpa Kategori'); ?>

                            </div>

                            <h2 class="product-name">
                                <?php echo e($product->name); ?>

                            </h2>

                            <?php if($reviewCount > 0): ?>
                                <div class="rating-line">
                                    ⭐ <?php echo e($avgRating); ?> / 5
                                    <span class="rating-muted">
                                        (<?php echo e($reviewCount); ?> ulasan)
                                    </span>
                                </div>
                            <?php else: ?>
                                <div class="rating-line">
                                    <span class="rating-muted">Belum ada ulasan</span>
                                </div>
                            <?php endif; ?>

                            <div class="price-text">
                                Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                            </div>

                            <?php if($product->stock > 0): ?>
                                <div class="stock-badge stock-ready">
                                    Stok: <?php echo e($product->stock); ?>

                                </div>
                            <?php else: ?>
                                <div class="stock-badge stock-empty">
                                    Stok Habis
                                </div>
                            <?php endif; ?>

                            <div class="product-actions">
                                <a href="<?php echo e($detailUrl); ?>" class="btn-detail">
                                    Detail
                                </a>

                                <?php if(auth()->guard()->check()): ?>
                                    <form action="<?php echo e(route('cart.add', $product->id)); ?>" method="POST" class="cart-form">
                                        <?php echo csrf_field(); ?>

                                        <button type="submit"
                                                class="btn-cart"
                                                <?php echo e($product->stock <= 0 ? 'disabled' : ''); ?>>
                                            <?php echo e($product->stock > 0 ? 'Keranjang' : 'Habis'); ?>

                                        </button>
                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo e(route('login')); ?>" class="btn-cart text-decoration-none d-flex align-items-center justify-content-center">
                                        Login
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="empty-card">
            <h3>Produk Tidak Ditemukan</h3>
            <p class="text-muted mb-0">
                Produk dengan filter yang dipilih belum tersedia.
            </p>
        </div>
    <?php endif; ?>
</div>

<script>
    const productFilterForm = document.getElementById('productFilterForm');
    const categoryInput = document.getElementById('categoryInput');
    const categoryDropdownButton = document.getElementById('categoryDropdownButton');
    const categoryDropdownMenu = document.getElementById('categoryDropdownMenu');
    const categorySelectedText = document.getElementById('categorySelectedText');
    const categorySelectedIcon = document.getElementById('categorySelectedIcon');
    const categoryOptions = document.querySelectorAll('.category-option');

    if (categoryDropdownButton && categoryDropdownMenu) {
        categoryDropdownButton.addEventListener('click', function () {
            categoryDropdownButton.classList.toggle('active');
            categoryDropdownMenu.classList.toggle('show');
        });

        categoryOptions.forEach(function (option) {
            option.addEventListener('click', function () {
                const categoryId = this.dataset.categoryId;
                const categoryName = this.dataset.categoryName;
                const categoryIcon = this.dataset.categoryIcon;

                categoryInput.value = categoryId;
                categorySelectedText.textContent = categoryName;
                categorySelectedIcon.textContent = categoryIcon;

                categoryOptions.forEach(function (item) {
                    item.classList.remove('active');
                });

                this.classList.add('active');
                categoryDropdownButton.classList.remove('active');
                categoryDropdownMenu.classList.remove('show');

                productFilterForm.submit();
            });
        });

        document.addEventListener('click', function (event) {
            const isInsideDropdown = event.target.closest('.category-dropdown');

            if (!isInsideDropdown) {
                categoryDropdownButton.classList.remove('active');
                categoryDropdownMenu.classList.remove('show');
            }
        });
    }

    document.querySelectorAll('.product-card').forEach(function (card) {
        card.addEventListener('click', function (event) {
            const blockedElement = event.target.closest('a, button, form, input, select, textarea');

            if (blockedElement) {
                return;
            }

            const url = this.dataset.url;

            if (url) {
                window.location.href = url;
            }
        });

        card.addEventListener('keydown', function (event) {
            if (event.key === 'Enter') {
                const url = this.dataset.url;

                if (url) {
                    window.location.href = url;
                }
            }
        });
    });

    document.querySelectorAll('.cart-form').forEach(function (form) {
        form.addEventListener('click', function (event) {
            event.stopPropagation();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\farha\hans-golfc\resources\views/products/index.blade.php ENDPATH**/ ?>