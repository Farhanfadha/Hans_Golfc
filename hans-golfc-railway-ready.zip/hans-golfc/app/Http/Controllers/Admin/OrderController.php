<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::latest()->get();

        return view('admin.orders.index', compact('orders'));
    }

    public function show($id)
    {
        $order = Order::with('items')->findOrFail($id);

        return view('admin.orders.show', compact('order'));
    }

    public function paymentProof($id)
    {
        $order = Order::findOrFail($id);

        if (! $order->payment_proof || ! Storage::disk('public')->exists($order->payment_proof)) {
            abort(404, 'Bukti transfer tidak ditemukan.');
        }

        return Storage::disk('public')->response($order->payment_proof);
    }

    public function updateStatus(Request $request, $id)
    {
        $request->validate([
            'status' => 'required|in:new,processing,completed,cancelled',
        ]);

        $order = Order::with('items')->findOrFail($id);
        $order->status = $request->status;

        if ($request->status === 'cancelled' && ! $order->stock_restored) {
            DB::transaction(function () use ($order) {
                foreach ($order->items as $item) {
                    if ($item->product_id) {
                        \App\Models\Product::where('id', $item->product_id)->increment('stock', $item->quantity);
                    }
                }

                $order->stock_restored = true;
                $order->save();
            });
        } else {
            $order->save();
        }

        return redirect()->route('admin.orders.show', $order->id)
            ->with('success', 'Status pesanan berhasil diperbarui.');
    }

    public function updatePaymentStatus(Request $request, $id)
    {
        $request->validate([
            'payment_status' => 'required|in:pending,waiting_confirmation,paid,rejected',
        ]);

        $order = Order::findOrFail($id);
        $order->payment_status = $request->payment_status;

        if ($request->payment_status === 'paid') {
            $order->paid_at = now();

            if ($order->status === 'new') {
                $order->status = 'processing';
            }
        }

        if (in_array($request->payment_status, ['pending', 'waiting_confirmation', 'rejected'])) {
            $order->paid_at = null;
        }

        $order->save();

        return redirect()->route('admin.orders.show', $order->id)
            ->with('success', 'Status pembayaran berhasil diperbarui.');
    }

    public function updateShipment(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        if ($order->payment_status !== 'paid') {
            return redirect()->route('admin.orders.show', $order->id)
                ->with('error', 'Resi hanya bisa ditambahkan setelah pembayaran dikonfirmasi.');
        }

        $request->validate([
            'shipping_status' => 'required|in:not_shipped,shipped',
            'courier_name' => 'required_if:shipping_status,shipped|nullable|string|max:255',
            'tracking_number' => 'required_if:shipping_status,shipped|nullable|string|max:255',
        ], [
            'courier_name.required_if' => 'Nama jasa pengiriman wajib diisi jika pesanan sudah dikirim.',
            'tracking_number.required_if' => 'Nomor resi wajib diisi jika pesanan sudah dikirim.',
        ]);

        if ($request->shipping_status === 'shipped') {
            $order->update([
                'shipping_status' => 'shipped',
                'courier_name' => $request->courier_name,
                'tracking_number' => $request->tracking_number,
                'shipped_at' => $order->shipped_at ?? now(),
                'status' => $order->status === 'new' ? 'processing' : $order->status,
            ]);

            return redirect()->route('admin.orders.show', $order->id)
                ->with('success', 'Data resi pengiriman berhasil ditambahkan.');
        }

        $order->update([
            'shipping_status' => 'not_shipped',
            'courier_name' => null,
            'tracking_number' => null,
            'shipped_at' => null,
        ]);

        return redirect()->route('admin.orders.show', $order->id)
            ->with('success', 'Status pengiriman berhasil diubah menjadi belum dikirim.');
    }
}