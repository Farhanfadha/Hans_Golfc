@extends('layouts.app')

@section('content')
<style>
    .admin-chat-page {
        padding-bottom: 50px;
    }

    .chat-hero {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        border-radius: 28px;
        padding: 34px;
        margin-bottom: 24px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.16);
    }

    .chat-hero h1 {
        font-size: 34px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .chat-hero p {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .chat-list-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 24px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
        overflow: hidden;
    }

    .chat-item {
        padding: 20px 24px;
        border-bottom: 1px solid #e5e7eb;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 18px;
        text-decoration: none;
        color: inherit;
        transition: 0.2s;
    }

    .chat-item:last-child {
        border-bottom: none;
    }

    .chat-item:hover {
        background: #f8fafc;
        color: inherit;
    }

    .avatar-circle {
        width: 52px;
        height: 52px;
        border-radius: 999px;
        background: linear-gradient(135deg, #16a34a, #15803d);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        font-size: 20px;
        flex-shrink: 0;
    }

    .chat-name {
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 4px;
    }

    .chat-email {
        color: #64748b;
        font-size: 13px;
        margin-bottom: 5px;
    }

    .last-message {
        color: #475569;
        font-size: 14px;
        font-weight: 600;
        max-width: 640px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .chat-meta {
        text-align: right;
        min-width: 160px;
    }

    .chat-time {
        color: #64748b;
        font-size: 13px;
        margin-bottom: 8px;
    }

    .unread-badge {
        display: inline-block;
        background: #ef4444;
        color: white;
        border-radius: 999px;
        padding: 6px 11px;
        font-size: 12px;
        font-weight: 900;
    }

    .read-badge {
        display: inline-block;
        background: #dcfce7;
        color: #166534;
        border-radius: 999px;
        padding: 6px 11px;
        font-size: 12px;
        font-weight: 900;
    }

    .empty-box {
        text-align: center;
        padding: 70px 20px;
        color: #64748b;
    }

    .empty-icon {
        font-size: 54px;
        margin-bottom: 12px;
    }

    @media (max-width: 768px) {
        .chat-item {
            align-items: flex-start;
            flex-direction: column;
        }

        .chat-meta {
            text-align: left;
            min-width: unset;
        }

        .last-message {
            max-width: 100%;
        }
    }
</style>

<div class="container admin-chat-page">
    <div class="chat-hero">
        <h1>Admin Chat</h1>
        <p>Kelola pertanyaan customer tentang produk, pembayaran, dan pengiriman.</p>
    </div>

    @if(session('success'))
        <div class="alert alert-success mb-4">
            {{ session('success') }}
        </div>
    @endif

    <div class="chat-list-card">
        @forelse($chats as $chat)
            @php
                $latestMessage = $chat->messages->first();
                $customerName = optional($chat->user)->name ?? 'Customer';
                $initial = strtoupper(substr($customerName, 0, 1));
            @endphp

            <a href="{{ route('admin.chats.show', $chat->id) }}" class="chat-item">
                <div class="d-flex align-items-center gap-3">
                    <div class="avatar-circle">
                        {{ $initial }}
                    </div>

                    <div>
                        <div class="chat-name">{{ $customerName }}</div>

                        <div class="chat-email">
                            {{ optional($chat->user)->email ?? '-' }}
                        </div>

                        <div class="last-message">
                            @if($latestMessage)
                                {{ $latestMessage->sender_type === 'admin' ? 'Admin: ' : 'Customer: ' }}
                                {{ $latestMessage->message }}
                            @else
                                Belum ada pesan.
                            @endif
                        </div>
                    </div>
                </div>

                <div class="chat-meta">
                    <div class="chat-time">
                        @if($latestMessage)
                            {{ $latestMessage->created_at->format('d M Y H:i') }}
                        @else
                            {{ $chat->created_at->format('d M Y H:i') }}
                        @endif
                    </div>

                    @if($chat->unread_admin_count > 0)
                        <span class="unread-badge">
                            {{ $chat->unread_admin_count }} pesan baru
                        </span>
                    @else
                        <span class="read-badge">
                            Sudah dibaca
                        </span>
                    @endif
                </div>
            </a>
        @empty
            <div class="empty-box">
                <div class="empty-icon">💬</div>
                <h4>Belum ada chat</h4>
                <p class="mb-0">Chat dari customer akan muncul di sini.</p>
            </div>
        @endforelse
    </div>
</div>
@endsection