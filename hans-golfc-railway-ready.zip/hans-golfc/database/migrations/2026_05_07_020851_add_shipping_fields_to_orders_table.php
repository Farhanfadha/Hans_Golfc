<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            if (!Schema::hasColumn('orders', 'shipping_status')) {
                $table->string('shipping_status')->default('not_shipped');
            }

            if (!Schema::hasColumn('orders', 'courier_name')) {
                $table->string('courier_name')->nullable();
            }

            if (!Schema::hasColumn('orders', 'tracking_number')) {
                $table->string('tracking_number')->nullable();
            }

            if (!Schema::hasColumn('orders', 'shipped_at')) {
                $table->timestamp('shipped_at')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $columns = [];

            if (Schema::hasColumn('orders', 'shipping_status')) {
                $columns[] = 'shipping_status';
            }

            if (Schema::hasColumn('orders', 'courier_name')) {
                $columns[] = 'courier_name';
            }

            if (Schema::hasColumn('orders', 'tracking_number')) {
                $columns[] = 'tracking_number';
            }

            if (Schema::hasColumn('orders', 'shipped_at')) {
                $columns[] = 'shipped_at';
            }

            if (count($columns) > 0) {
                $table->dropColumn($columns);
            }
        });
    }
};