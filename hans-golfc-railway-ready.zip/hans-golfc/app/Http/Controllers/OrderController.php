<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Support\Facades\Storage;

class OrderController extends Controller
{
    public function index()
    {
        $orders = Order::with([
                'items.product',
                'items.review',
            ])
            ->where('user_id', auth()->id())
            ->latest()
            ->paginate(10);

        return view('orders.index', compact('orders'));
    }

    public function show($id)
    {
        $order = Order::with([
                'items.product',
                'items.review',
            ])
            ->where('user_id', auth()->id())
            ->findOrFail($id);

        return view('orders.show', compact('order'));
    }

    public function paymentProof($id)
    {
        $order = Order::where('user_id', auth()->id())->findOrFail($id);

        if (! $order->payment_proof || ! Storage::disk('public')->exists($order->payment_proof)) {
            abort(404, 'Bukti transfer tidak ditemukan.');
        }

        return Storage::disk('public')->response($order->payment_proof);
    }
}