<?php

namespace App\Http\Controllers;

use App\Models\Chat;
use App\Models\ChatMessage;
use App\Models\Product;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function index(Request $request)
    {
        $chat = Chat::firstOrCreate(
            ['user_id' => auth()->id()],
            ['status' => 'open']
        );

        if ($request->filled('product_id')) {
            $product = Product::find($request->product_id);

            if ($product) {
                ChatMessage::create([
                    'chat_id' => $chat->id,
                    'sender_type' => 'user',
                    'message' => "Halo admin, saya ingin bertanya tentang produk: {$product->name}. Harga: Rp " . number_format($product->price, 0, ',', '.') . ".",
                    'is_read_admin' => false,
                    'is_read_user' => true,
                ]);

                return redirect()->route('chat.index')
                    ->with('success', 'Pesan tentang produk berhasil dikirim ke admin.');
            }
        }

        ChatMessage::where('chat_id', $chat->id)
            ->where('sender_type', 'admin')
            ->where('is_read_user', false)
            ->update([
                'is_read_user' => true,
            ]);

        $messages = $chat->messages()
            ->oldest()
            ->get();

        return view('chat.index', compact('chat', 'messages'));
    }

    public function send(Request $request)
    {
        $request->validate([
            'message' => 'required|string|max:2000',
        ]);

        $chat = Chat::firstOrCreate(
            ['user_id' => auth()->id()],
            ['status' => 'open']
        );

        ChatMessage::create([
            'chat_id' => $chat->id,
            'sender_type' => 'user',
            'message' => $request->message,
            'is_read_admin' => false,
            'is_read_user' => true,
        ]);

        return redirect()->route('chat.index')
            ->with('success', 'Pesan berhasil dikirim.');
    }
}