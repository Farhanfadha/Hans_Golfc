@extends('layouts.app')

@section('content')
<style>
    .checkout-page {
        padding-bottom: 50px;
    }

    .checkout-hero {
        position: relative;
        overflow: hidden;
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.96), rgba(30, 41, 59, 0.92));
        border-radius: 28px;
        padding: 50px 40px;
        color: white;
        box-shadow: 0 20px 50px rgba(15, 23, 42, 0.12);
        margin-bottom: 32px;
    }

    .checkout-hero::before {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 220px;
        height: 220px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(250, 204, 21, 0.22), transparent 70%);
    }

    .checkout-hero-content {
        position: relative;
        z-index: 2;
    }

    .checkout-badge {
        display: inline-block;
        padding: 8px 14px;
        border-radius: 999px;
        background: rgba(255,255,255,0.10);
        color: #fde68a;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 14px;
    }

    .checkout-title {
        font-size: 42px;
        font-weight: 800;
        margin-bottom: 10px;
        line-height: 1.1;
    }

    .checkout-subtitle {
        color: #cbd5e1;
        font-size: 16px;
        margin-bottom: 0;
        max-width: 700px;
    }

    .checkout-card,
    .summary-card {
        background: white;
        border: none;
        border-radius: 24px;
        box-shadow: 0 14px 35px rgba(15, 23, 42, 0.08);
        padding: 24px;
    }

    .section-title {
        font-size: 24px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 18px;
    }

    .form-label-custom {
        font-weight: 700;
        color: #0f172a;
        margin-bottom: 8px;
    }

    .form-control-custom {
        border-radius: 14px;
        border: 1px solid #dbe3ec;
        min-height: 48px;
        box-shadow: none;
    }

    .form-control-custom:focus {
        border-color: #94a3b8;
        box-shadow: 0 0 0 0.2rem rgba(148, 163, 184, 0.15);
    }

    .summary-item {
        padding: 14px 0;
        border-bottom: 1px solid #e2e8f0;
    }

    .summary-item:last-child {
        border-bottom: none;
    }

    .summary-name {
        font-weight: 700;
        color: #0f172a;
        margin-bottom: 4px;
    }

    .summary-meta {
        color: #64748b;
        font-size: 14px;
    }

    .summary-subtotal {
        font-weight: 700;
        color: #0f172a;
        margin-top: 6px;
    }

    .summary-total {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 18px;
        margin-top: 18px;
        border-top: 1px solid #e2e8f0;
        font-size: 22px;
        font-weight: 800;
        color: #0f172a;
    }

    .btn-submit-custom {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 12px 18px;
        font-weight: 800;
    }

    .btn-submit-custom:hover {
        background: #15803d;
        color: white;
    }

    .shipping-note {
        margin-top: 18px;
        background: #fffbeb;
        border: 1px solid #fde68a;
        color: #92400e;
        border-radius: 14px;
        padding: 14px 16px;
        font-size: 14px;
        font-weight: 600;
        line-height: 1.5;
    }

    .shipping-note a {
        color: #92400e;
        font-weight: 800;
        text-decoration: underline;
    }

    @media (max-width: 991.98px) {
        .checkout-hero {
            padding: 40px 26px;
        }

        .checkout-title {
            font-size: 34px;
        }
    }
</style>

<div class="container checkout-page">
    <section class="checkout-hero">
        <div class="checkout-hero-content">
            <span class="checkout-badge">Checkout</span>
            <h1 class="checkout-title">Selesaikan Pesanan Anda</h1>
            <p class="checkout-subtitle">
                Isi data pengiriman dengan benar untuk melanjutkan proses pemesanan produk Hans Golf.
            </p>
        </div>
    </section>

    <div class="row g-4">
        <div class="col-lg-7">
            <div class="checkout-card">
                <h2 class="section-title">Informasi Customer</h2>

                <form action="{{ route('cart.processCheckout') }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <label class="form-label-custom">Nama Lengkap</label>
                        <input type="text"
                               name="customer_name"
                               class="form-control form-control-custom"
                               value="{{ old('customer_name') }}"
                               required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label-custom">Nomor WhatsApp</label>
                        <input type="text"
                               name="customer_phone"
                               class="form-control form-control-custom"
                               value="{{ old('customer_phone') }}"
                               required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label-custom">Alamat</label>
                        <textarea name="customer_address"
                                  class="form-control form-control-custom"
                                  rows="4"
                                  required>{{ old('customer_address') }}</textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label-custom">Catatan</label>
                        <textarea name="note"
                                  class="form-control form-control-custom"
                                  rows="3">{{ old('note') }}</textarea>
                    </div>

                    <button type="submit" class="btn-submit-custom">
                        Buat Pesanan
                    </button>
                </form>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="summary-card">
                <h2 class="section-title">Ringkasan Belanja</h2>

                @php $total = 0; @endphp

                @foreach($cart as $item)
                    @php
                        $subtotal = $item['price'] * $item['quantity'];
                        $total += $subtotal;
                    @endphp

                    <div class="summary-item">
                        <div class="summary-name">{{ $item['name'] }}</div>
                        <div class="summary-meta">
                            {{ $item['quantity'] }} x Rp {{ number_format($item['price'], 0, ',', '.') }}
                        </div>
                        <div class="summary-subtotal">
                            Rp {{ number_format($subtotal, 0, ',', '.') }}
                        </div>
                    </div>
                @endforeach

                <div class="summary-item">
                    <div class="summary-name">Ongkir Reguler ({{ $shippingCourier }})</div>
                    <div class="summary-meta">Dikirim oleh ekspedisi {{ $shippingCourier }}</div>
                    <div class="summary-subtotal">
                        Rp {{ number_format($shippingCost, 0, ',', '.') }}
                    </div>
                </div>

                <div class="summary-total">
                    <span>Total</span>
                    <span>Rp {{ number_format($total + $shippingCost, 0, ',', '.') }}</span>
                </div>

                <div class="shipping-note">
                    ⚡ Butuh pengiriman <strong>Instant</strong> atau <strong>Sameday</strong>?
                    Silakan <a href="{{ route('chat.index') }}">chat admin kami</a> setelah pesanan dibuat untuk atur pengiriman cepat.
                </div>
            </div>
        </div>
    </div>
</div>
@endsection