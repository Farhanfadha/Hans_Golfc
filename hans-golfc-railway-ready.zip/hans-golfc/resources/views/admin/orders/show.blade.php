@extends('layouts.app')

@section('content')
@php
    $paymentStatusLabels = [
        'pending' => 'Menunggu Pembayaran',
        'waiting_confirmation' => 'Menunggu Konfirmasi Admin',
        'paid' => 'Pembayaran Diterima',
        'rejected' => 'Pembayaran Ditolak',
    ];

    $shippingStatusLabels = [
        'not_shipped' => 'Belum Dikirim',
        'shipped' => 'Sudah Dikirim',
    ];

    $paymentStatus = $order->payment_status ?? 'pending';
    $shippingStatus = $order->shipping_status ?? 'not_shipped';

    $isImageProof = false;

    if ($order->payment_proof) {
        $isImageProof = preg_match('/\.(jpg|jpeg|png|webp)$/i', $order->payment_proof);
    }
@endphp

<div class="container">
    <h1 class="mb-4">Detail Pesanan</h1>

    @if(session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger">
            {{ session('error') }}
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger">
            <strong>Terjadi kesalahan.</strong>
            <ul class="mb-0 mt-2">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-body">
            <h5>Data Pesanan</h5>

            <p><strong>Kode Order:</strong> {{ $order->order_code }}</p>
            <p><strong>Nama Customer:</strong> {{ $order->customer_name }}</p>
            <p><strong>No. WhatsApp:</strong> {{ $order->customer_phone }}</p>
            <p><strong>Alamat:</strong> {{ $order->customer_address }}</p>
            <p><strong>Catatan:</strong> {{ $order->note ?? '-' }}</p>
            @if($order->shipping_cost > 0)
                <p><strong>Subtotal Produk:</strong> Rp {{ number_format($order->total_price - $order->shipping_cost, 0, ',', '.') }}</p>
                <p><strong>Ongkir Reguler ({{ $order->shipping_courier ?? 'Anter Aja' }}):</strong> Rp {{ number_format($order->shipping_cost, 0, ',', '.') }}</p>
            @endif
            <p><strong>Total:</strong> Rp {{ number_format($order->total_price, 0, ',', '.') }}</p>
            <p><strong>Status Pesanan:</strong> {{ $order->status }}</p>
            <p><strong>Status Pembayaran:</strong> {{ $paymentStatusLabels[$paymentStatus] ?? $paymentStatus }}</p>
            <p><strong>Status Pengiriman:</strong> {{ $shippingStatusLabels[$shippingStatus] ?? 'Belum Dikirim' }}</p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <h5>Informasi Pembayaran</h5>

            <div class="row">
                <div class="col-md-6">
                    <p><strong>Nomor Rekening:</strong> 765-147-4373 (BCA)</p>
                    <p><strong>Atas Nama:</strong> Farhan F.</p>
                    <p><strong>Nama Pengirim:</strong> {{ $order->sender_name ?? '-' }}</p>
                    <p><strong>Status Pembayaran:</strong> {{ $paymentStatusLabels[$paymentStatus] ?? $paymentStatus }}</p>
                    <p>
                        <strong>Tanggal Dikonfirmasi:</strong>
                        {{ $order->paid_at ? $order->paid_at->format('d M Y H:i') : '-' }}
                    </p>
                </div>

                <div class="col-md-6">
                    <strong>Bukti Transfer:</strong>

                    @if($order->payment_proof)
                        <div class="mt-2">
                            @if($isImageProof)
                                <img src="{{ route('admin.orders.paymentProof', $order->id) }}"
                                     alt="Bukti Transfer"
                                     style="max-width: 100%; max-height: 320px; border-radius: 12px; border: 1px solid #ddd;">
                            @else
                                <p class="mt-2">File bukti transfer berupa PDF.</p>
                            @endif
                        </div>

                        <a href="{{ route('admin.orders.paymentProof', $order->id) }}"
                           target="_blank"
                           class="btn btn-sm btn-primary mt-3">
                            Buka Bukti Transfer
                        </a>
                    @else
                        <p class="text-muted mt-2">Customer belum upload bukti transfer.</p>
                    @endif
                </div>
            </div>

            <hr>

            <h5>Ubah Status Pembayaran</h5>

            <form action="{{ route('admin.orders.updatePaymentStatus', $order->id) }}" method="POST">
                @csrf

                <div class="row">
                    <div class="col-md-4">
                        <select name="payment_status" class="form-select">
                            <option value="pending" {{ $paymentStatus == 'pending' ? 'selected' : '' }}>
                                Menunggu Pembayaran
                            </option>

                            <option value="waiting_confirmation" {{ $paymentStatus == 'waiting_confirmation' ? 'selected' : '' }}>
                                Menunggu Konfirmasi Admin
                            </option>

                            <option value="paid" {{ $paymentStatus == 'paid' ? 'selected' : '' }}>
                                Pembayaran Diterima
                            </option>

                            <option value="rejected" {{ $paymentStatus == 'rejected' ? 'selected' : '' }}>
                                Pembayaran Ditolak
                            </option>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <button type="submit" class="btn btn-success">
                            Update Pembayaran
                        </button>
                    </div>
                </div>
            </form>

            @if($paymentStatus === 'waiting_confirmation')
                <div class="alert alert-info mt-3 mb-0">
                    Customer sudah mengirim bukti transfer. Silakan cek bukti transfer, lalu ubah status menjadi
                    <strong>Pembayaran Diterima</strong> jika sudah sesuai.
                </div>
            @endif
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <h5>Informasi Pengiriman</h5>

            <div class="mb-3">
                <p><strong>Status Pengiriman:</strong> {{ $shippingStatusLabels[$shippingStatus] ?? 'Belum Dikirim' }}</p>
                <p><strong>Jasa Pengiriman:</strong> {{ $order->courier_name ?? '-' }}</p>
                <p><strong>Nomor Resi:</strong> {{ $order->tracking_number ?? '-' }}</p>
                <p>
                    <strong>Tanggal Dikirim:</strong>
                    {{ $order->shipped_at ? $order->shipped_at->format('d M Y H:i') : '-' }}
                </p>
            </div>

            @if($paymentStatus !== 'paid')
                <div class="alert alert-warning">
                    Pembayaran belum dikonfirmasi. Admin baru bisa menambahkan resi setelah status pembayaran menjadi
                    <strong>Pembayaran Diterima</strong>.
                </div>
            @endif

            <form action="{{ route('admin.orders.updateShipment', $order->id) }}" method="POST">
                @csrf

                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Status Pengiriman</label>
                        <select name="shipping_status"
                                class="form-select"
                                {{ $paymentStatus !== 'paid' ? 'disabled' : '' }}>
                            <option value="not_shipped" {{ $shippingStatus === 'not_shipped' ? 'selected' : '' }}>
                                Belum Dikirim
                            </option>

                            <option value="shipped" {{ $shippingStatus === 'shipped' ? 'selected' : '' }}>
                                Sudah Dikirim
                            </option>
                        </select>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Nama Jasa Pengiriman</label>
                        <input type="text"
                               name="courier_name"
                               class="form-control"
                               value="{{ old('courier_name', $order->courier_name) }}"
                               placeholder="Contoh: JNE / J&T / SiCepat"
                               {{ $paymentStatus !== 'paid' ? 'disabled' : '' }}>
                    </div>

                    <div class="col-md-4 mb-3">
                        <label class="form-label">Nomor Resi</label>
                        <input type="text"
                               name="tracking_number"
                               class="form-control"
                               value="{{ old('tracking_number', $order->tracking_number) }}"
                               placeholder="Masukkan nomor resi"
                               {{ $paymentStatus !== 'paid' ? 'disabled' : '' }}>
                    </div>
                </div>

                <button type="submit"
                        class="btn btn-success"
                        {{ $paymentStatus !== 'paid' ? 'disabled' : '' }}>
                    Simpan Data Pengiriman
                </button>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <h5>Ubah Status Pesanan</h5>

            <form action="{{ route('admin.orders.updateStatus', $order->id) }}" method="POST">
                @csrf

                <div class="row">
                    <div class="col-md-4">
                        <select name="status" class="form-select">
                            <option value="new" {{ $order->status == 'new' ? 'selected' : '' }}>new</option>
                            <option value="processing" {{ $order->status == 'processing' ? 'selected' : '' }}>processing</option>
                            <option value="completed" {{ $order->status == 'completed' ? 'selected' : '' }}>completed</option>
                            <option value="cancelled" {{ $order->status == 'cancelled' ? 'selected' : '' }}>cancelled</option>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <button type="submit" class="btn btn-warning">
                            Update Status
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <h5>Item Pesanan</h5>

            <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Harga</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>

                <tbody>
                    @foreach($order->items as $item)
                        <tr>
                            <td>{{ $item->product_name }}</td>
                            <td>Rp {{ number_format($item->price, 0, ',', '.') }}</td>
                            <td>{{ $item->quantity }}</td>
                            <td>Rp {{ number_format($item->subtotal, 0, ',', '.') }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            </div>

            <a href="{{ route('admin.orders.index') }}" class="btn btn-secondary">
                Kembali
            </a>
        </div>
    </div>
</div>
@endsection