<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hans Golf</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html, body {
            min-height: 100%;
        }

        body {
            color: #0f172a;
            min-height: 100vh;
            background:
                linear-gradient(rgba(248, 250, 252, 0.80), rgba(248, 250, 252, 0.86)),
                url('https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1600&q=80');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }

        body::after {
            content: "";
            position: fixed;
            inset: 0;
            background:
                radial-gradient(circle at top right, rgba(34, 197, 94, 0.08), transparent 25%),
                radial-gradient(circle at bottom left, rgba(22, 163, 74, 0.06), transparent 30%);
            pointer-events: none;
            z-index: 0;
        }

        nav,
        main,
        .flash-wrapper {
            position: relative;
            z-index: 1;
        }

        .navbar-custom {
            background: linear-gradient(90deg, #0f172a, #1e293b);
            box-shadow: 0 8px 20px rgba(15, 23, 42, 0.12);
            padding-top: 14px;
            padding-bottom: 14px;
            backdrop-filter: blur(6px);
        }

        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            letter-spacing: 0.4px;
        }

        .navbar-main-links,
        .navbar-admin-links,
        .navbar-user-links {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .nav-link-custom {
            color: rgba(255,255,255,0.92);
            text-decoration: none;
            font-weight: 600;
            padding: 8px 10px;
            border-radius: 10px;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
        }

        .nav-link-custom:hover {
            color: #ffffff;
            background: rgba(255,255,255,0.08);
        }

        .nav-link-custom.active {
            color: #ffffff;
            background: rgba(255,255,255,0.12);
        }

        .admin-pill {
            background: rgba(250, 204, 21, 0.14);
            color: #facc15;
            text-decoration: none;
            font-weight: 700;
            padding: 8px 14px;
            border-radius: 999px;
            border: 1px solid rgba(250, 204, 21, 0.2);
            transition: all 0.2s ease;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
        }

        .admin-pill:hover {
            background: rgba(250, 204, 21, 0.22);
            color: #fde68a;
        }

        .chat-badge-wrapper {
            position: relative;
            display: inline-flex;
            align-items: center;
        }

        .chat-badge-count {
            position: absolute;
            top: -8px;
            right: -10px;
            min-width: 22px;
            height: 22px;
            padding: 0 6px;
            border-radius: 999px;
            background: linear-gradient(135deg, #ff4d4f, #e11d48);
            color: white;
            font-size: 12px;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            line-height: 1;
            box-shadow: 0 6px 14px rgba(225, 29, 72, 0.35);
            border: 2px solid #1e293b;
        }

        .user-badge {
            background: rgba(255,255,255,0.08);
            color: #ffffff;
            padding: 8px 14px;
            border-radius: 999px;
            font-size: 14px;
            white-space: nowrap;
            border: 1px solid rgba(255,255,255,0.08);
        }

        .btn-login-custom {
            background: #ffffff;
            color: #0f172a;
            font-weight: 700;
            border-radius: 999px;
            padding: 8px 18px;
            border: none;
        }

        .btn-login-custom:hover {
            background: #e2e8f0;
            color: #0f172a;
        }

        .btn-logout-custom {
            border-radius: 999px;
            padding: 8px 16px;
            font-weight: 700;
            border: none;
        }

        .flash-wrapper {
            margin-top: 20px;
        }

        .toast-alert {
            border: none;
            border-radius: 18px;
            padding: 14px 18px;
            font-weight: 700;
            box-shadow: 0 14px 30px rgba(15, 23, 42, 0.10);
            display: flex;
            align-items: center;
            gap: 12px;
            animation: toastDrop 0.45s ease;
            margin-bottom: 14px;
        }

        .toast-alert-success {
            background: linear-gradient(135deg, #dcfce7, #f0fdf4);
            color: #166534;
            border: 1px solid #bbf7d0;
        }

        .toast-alert-warning {
            background: linear-gradient(135deg, #fef3c7, #fffbeb);
            color: #92400e;
            border: 1px solid #fde68a;
        }

        .toast-alert-danger {
            background: linear-gradient(135deg, #fee2e2, #fff1f2);
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        .toast-alert-icon {
            width: 34px;
            height: 34px;
            border-radius: 999px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: 800;
            flex-shrink: 0;
        }

        .toast-alert-success .toast-alert-icon {
            background: #16a34a;
            color: white;
        }

        .toast-alert-warning .toast-alert-icon {
            background: #f59e0b;
            color: white;
        }

        .toast-alert-danger .toast-alert-icon {
            background: #dc2626;
            color: white;
        }

        main {
            min-height: calc(100vh - 80px);
        }

        .navbar-divider {
            width: 1px;
            height: 28px;
            background: rgba(255,255,255,0.12);
            margin: 0 4px;
        }

        @keyframes toastDrop {
            from {
                opacity: 0;
                transform: translateY(-12px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .footer-custom {
            background: linear-gradient(90deg, #0f172a, #1e293b);
            color: rgba(255,255,255,0.85);
            margin-top: 60px;
            padding: 48px 0 20px;
        }

        .footer-brand {
            color: #ffffff;
            font-weight: 800;
            font-size: 22px;
            margin-bottom: 10px;
        }

        .footer-tagline {
            color: rgba(255,255,255,0.65);
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 0;
        }

        .footer-heading {
            color: #ffffff;
            font-weight: 700;
            font-size: 15px;
            margin-bottom: 14px;
            letter-spacing: 0.3px;
        }

        .footer-links {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            font-size: 14px;
            transition: color 0.2s ease;
        }

        .footer-links a:hover {
            color: #ffffff;
        }

        .footer-contact li {
            color: rgba(255,255,255,0.7);
            font-size: 14px;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.08);
            margin-top: 36px;
            padding-top: 18px;
            text-align: center;
            font-size: 13px;
            color: rgba(255,255,255,0.5);
        }

        @media (max-width: 991.98px) {
            .navbar-collapse {
                margin-top: 16px;
                background: rgba(255,255,255,0.03);
                border-radius: 16px;
                padding: 16px;
            }

            .navbar-content {
                gap: 16px !important;
            }

            .navbar-main-links,
            .navbar-admin-links,
            .navbar-user-links {
                align-items: flex-start;
                flex-direction: column;
            }

            .navbar-divider {
                display: none;
            }
        }

        @media (max-width: 480px) {
            #chat-container {
                width: calc(100vw - 30px) !important;
                right: 15px !important;
                bottom: 15px !important;
            }

            #chat-window {
                width: 100% !important;
            }
        }
    </style>
</head>
<body>
<?php if(auth()->guard()->check()): ?>
<div id="chat-container" 
     style="position: fixed; bottom: 20px; right: 20px; z-index: 999999; width: 320px;">
     
    <button id="chat-toggle" 
            style="background: #2563eb; color: white; padding: 15px; border-radius: 50px; border: none; cursor: pointer; float: right; box-shadow: 0 4px 6px rgba(0,0,0,0.2);">
        💬 Chat HansGolf
    </button>

    <div id="chat-window" 
         style="display: none; background: white; border-radius: 12px; box-shadow: 0 10px 15px rgba(0,0,0,0.3); overflow: hidden; border: 1px solid #ccc;">
        
        <div style="background: #1e293b; color: white; padding: 10px; display: flex; justify-content: space-between;">
            <span>HANS-Bot</span>
            <button onclick="toggleChat()" style="background: none; border: none; color: white; cursor: pointer;">✕</button>
        </div>
        
        <div id="chat-box" style="height: 250px; padding: 10px; overflow-y: auto; background: #f9fafb; font-size: 14px;">
            <div style="background: #dbeafe; padding: 8px; border-radius: 8px; margin-bottom: 8px;">Halo! Ada yang bisa dibantu?</div>
        </div>
        
        <div style="padding: 10px; border-top: 1px solid #eee; display: flex;">
            <input type="text" id="chat-input" style="flex: 1; padding: 5px; border: 1px solid #ddd; border-radius: 4px;" placeholder="Tanya sesuatu...">
            <button onclick="sendMessage()" style="background: #2563eb; color: white; border: none; padding: 5px 10px; border-radius: 4px; margin-left: 5px; cursor: pointer;">Kirim</button>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if(auth()->guard()->check()): ?>
<script>
    function toggleChat() {
        const win = document.getElementById('chat-window');
        const tog = document.getElementById('chat-toggle');
        if (win.style.display === 'none') {
            win.style.display = 'block';
            tog.style.display = 'none';
        } else {
            win.style.display = 'none';
            tog.style.display = 'block';
        }
    }
    document.getElementById('chat-toggle').addEventListener('click', toggleChat);

    async function sendMessage() {
        const input = document.getElementById('chat-input');
        const chatBox = document.getElementById('chat-box');
        if (!input.value.trim()) return;

        chatBox.innerHTML += `<div style="background: #f3f4f6; padding: 8px; border-radius: 8px; margin-bottom: 8px; text-align: right;">${input.value}</div>`;
        const msg = input.value;
        input.value = '';

        const res = await fetch('/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
            body: JSON.stringify({ message: msg })
        });
        const data = await res.json();
        chatBox.innerHTML += `<div style="background: #dbeafe; padding: 8px; border-radius: 8px; margin-bottom: 8px;">${data.reply}</div>`;
        chatBox.scrollTop = chatBox.scrollHeight;
    }
</script>
<?php endif; ?>

<?php
    use App\Models\Chat;
    use App\Models\ChatMessage;

    $isLoggedIn = auth()->check();
    $userRole = $isLoggedIn ? trim(strtolower((string) auth()->user()->role)) : null;
    $isAdmin = $userRole === 'admin';

    $unreadAdminChats = 0;
    $unreadUserChats = 0;

    if ($isLoggedIn && $isAdmin) {
        $unreadAdminChats = ChatMessage::where('sender_type', 'user')
            ->where('is_read_admin', false)
            ->distinct('chat_id')
            ->count('chat_id');
    }

    if ($isLoggedIn && !$isAdmin) {
        $userChat = Chat::where('user_id', auth()->id())->first();

        if ($userChat) {
            $unreadUserChats = ChatMessage::where('chat_id', $userChat->id)
                ->where('sender_type', 'admin')
                ->where('is_read_user', false)
                ->exists() ? 1 : 0;
        }
    }
?>

<nav class="navbar navbar-expand-lg navbar-dark navbar-custom">
    <div class="container">
        <a class="navbar-brand text-white" href="<?php echo e(route('home')); ?>">Hans Golf</a>

        <button class="navbar-toggler border-0 shadow-none"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#mainNavbar"
                aria-controls="mainNavbar"
                aria-expanded="false"
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center w-100 mt-3 mt-lg-0 navbar-content">
                <div class="d-flex flex-column flex-lg-row align-items-lg-center gap-3">
                    <div class="navbar-main-links">
                        <a class="nav-link-custom <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>"
                           href="<?php echo e(route('home')); ?>">
                            Home
                        </a>

                        <a class="nav-link-custom <?php echo e(request()->routeIs('products.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('products.index')); ?>">
                            Produk
                        </a>

                        <?php if(auth()->guard()->check()): ?>
                            <a class="nav-link-custom <?php echo e(request()->routeIs('cart.*') ? 'active' : ''); ?>"
                               href="<?php echo e(route('cart.index')); ?>">
                                Keranjang
                            </a>

                            <?php if(!$isAdmin): ?>
                                <a class="nav-link-custom <?php echo e(request()->routeIs('orders.*') ? 'active' : ''); ?>"
                                   href="<?php echo e(route('orders.index')); ?>">
                                    Pesanan Saya
                                </a>

                                <div class="chat-badge-wrapper">
                                    <a class="nav-link-custom <?php echo e(request()->routeIs('chat.*') ? 'active' : ''); ?>"
                                       href="<?php echo e(route('chat.index')); ?>">
                                        Chat
                                    </a>

                                    <?php if($unreadUserChats > 0): ?>
                                        <span class="chat-badge-count">
                                            <?php echo e($unreadUserChats); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>

                    <?php if($isLoggedIn && $isAdmin): ?>
                        <div class="navbar-divider d-none d-lg-block"></div>

                        <div class="navbar-admin-links">
                            <a class="admin-pill" href="<?php echo e(route('admin.orders.index')); ?>">
                                Admin Order
                            </a>

                            <a class="admin-pill" href="<?php echo e(route('admin.categories.index')); ?>">
                                Admin Kategori
                            </a>

                            <a class="admin-pill" href="<?php echo e(route('admin.products.index')); ?>">
                                Admin Produk
                            </a>

                            <div class="chat-badge-wrapper">
                                <a class="admin-pill" href="<?php echo e(route('admin.chats.index')); ?>">
                                    Admin Chat
                                </a>

                                <?php if($unreadAdminChats > 0): ?>
                                    <span class="chat-badge-count">
                                        <?php echo e($unreadAdminChats > 99 ? '99+' : $unreadAdminChats); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="navbar-user-links">
                    <?php if(auth()->guard()->check()): ?>
                        <a class="nav-link-custom <?php echo e(request()->routeIs('profile.*') ? 'active' : ''); ?>"
                           href="<?php echo e(route('profile.edit')); ?>">
                            Akun Saya
                        </a>

                        <span class="user-badge">
                            Halo, <?php echo e(auth()->user()->name); ?>

                        </span>

                        <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger btn-sm btn-logout-custom">
                                Logout
                            </button>
                        </form>
                    <?php else: ?>
                        <a class="btn btn-sm btn-login-custom" href="<?php echo e(route('login')); ?>">
                            Login
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</nav>

<div class="container flash-wrapper">
    <?php if(session('success')): ?>
        <div class="toast-alert toast-alert-success">
            <span class="toast-alert-icon">✓</span>
            <span><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session('warning')): ?>
        <div class="toast-alert toast-alert-warning">
            <span class="toast-alert-icon">!</span>
            <span><?php echo e(session('warning')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="toast-alert toast-alert-danger">
            <span class="toast-alert-icon">✕</span>
            <span><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="toast-alert toast-alert-danger">
            <span class="toast-alert-icon">✕</span>

            <div>
                <ul class="mb-0 ps-3">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
</div>

<main class="py-4">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer class="footer-custom">
    <div class="container">
        <div class="row gy-4">
            <div class="col-6 col-lg-3">
                <div class="footer-brand">Hans Golf</div>
                <p class="footer-tagline">
                    Hans Golf menjual bola golf second dan baru yang berkualitas. Segar dari lapangan, terjaga mutunya, sampai langsung ke tangan Anda.
                </p>
            </div>

            <div class="col-6 col-lg-3">
                <div class="footer-heading">Belanja</div>
                <ul class="footer-links">
                    <li><a href="<?php echo e(route('products.index')); ?>">Semua Produk</a></li>
                    <li><a href="<?php echo e(route('cart.index')); ?>">Keranjang</a></li>
                    <li><a href="<?php echo e(route('orders.index')); ?>">Pesanan Saya</a></li>
                    <li><a href="<?php echo e(route('chat.index')); ?>">Chat</a></li>
                </ul>
            </div>

            <div class="col-6 col-lg-3">
                <div class="footer-heading">Akun</div>
                <ul class="footer-links">
                    <li><a href="<?php echo e(route('profile.edit')); ?>">Akun Saya</a></li>
                </ul>
            </div>

            <div class="col-6 col-lg-3">
                <div class="footer-heading">Kontak Kami</div>
                <ul class="footer-links footer-contact">
                    <li>📞 0812-9465-3298</li>
                    <li>📍 Jl. BDB Delima No.138 RT 01/15 Kota Depok Jawa Barat</li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            &copy; <?php echo e(date('Y')); ?> Hans Golf. Semua hak cipta dilindungi.
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH C:\Users\farha\hans-golfc\resources\views/layouts/app.blade.php ENDPATH**/ ?>