@extends('layouts.app')

@section('content')
<style>
    .product-detail-page {
        padding-bottom: 50px;
    }

    .detail-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 28px;
        overflow: hidden;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
    }

    .product-image-box {
        background: #f8fafc;
        min-height: 360px;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 24px;
    }

    .product-image {
        width: 100%;
        height: 100%;
        max-height: 360px;
        object-fit: contain;
    }

    .product-placeholder {
        font-size: 90px;
        color: #64748b;
    }

    .detail-body {
        padding: 34px;
    }

    .category-pill {
        display: inline-block;
        background: #f1f5f9;
        color: #334155;
        border-radius: 999px;
        padding: 8px 13px;
        font-size: 13px;
        font-weight: 900;
        text-transform: uppercase;
        margin-bottom: 14px;
    }

    .product-title {
        font-size: 36px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 12px;
    }

    .rating-summary {
        background: #fffbeb;
        border: 1px solid #fde68a;
        border-radius: 18px;
        padding: 14px 16px;
        margin-bottom: 18px;
    }

    .rating-score {
        font-size: 24px;
        font-weight: 900;
        color: #f59e0b;
        margin-bottom: 2px;
    }

    .rating-count {
        color: #64748b;
        font-weight: 700;
        font-size: 14px;
    }

    .price-text {
        color: #ca8a04;
        font-size: 32px;
        font-weight: 900;
        margin-bottom: 18px;
    }

    .meta-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
        margin-bottom: 20px;
    }

    .meta-box {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        padding: 15px;
    }

    .meta-label {
        color: #64748b;
        font-size: 13px;
        font-weight: 800;
        text-transform: uppercase;
        margin-bottom: 4px;
    }

    .meta-value {
        color: #0f172a;
        font-weight: 900;
    }

    .description-box {
        color: #334155;
        line-height: 1.8;
        margin-bottom: 24px;
        font-weight: 600;
    }

    .btn-cart {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 16px;
        padding: 13px 20px;
        font-weight: 900;
        width: 100%;
        min-height: 52px;
    }

    .btn-cart:hover {
        background: #15803d;
        color: white;
    }

    .btn-cart:disabled {
        background: #94a3b8;
        cursor: not-allowed;
    }

    .btn-back {
        background: #0f172a;
        color: white;
        border-radius: 16px;
        padding: 13px 20px;
        font-weight: 900;
        text-decoration: none;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        min-height: 52px;
    }

    .btn-back:hover {
        background: #1e293b;
        color: white;
    }

    .btn-chat {
        background: #f59e0b;
        color: white;
        border-radius: 16px;
        padding: 13px 20px;
        font-weight: 900;
        text-decoration: none;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        min-height: 52px;
    }

    .btn-chat:hover {
        background: #d97706;
        color: white;
    }

    .reviews-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 28px;
        padding: 28px;
        margin-top: 28px;
        box-shadow: 0 14px 32px rgba(15, 23, 42, 0.07);
    }

    .reviews-title {
        font-size: 28px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 18px;
    }

    .review-summary-box {
        background: linear-gradient(135deg, #fffbeb, #ffffff);
        border: 1px solid #fde68a;
        border-radius: 22px;
        padding: 20px;
        margin-bottom: 22px;
    }

    .review-score-large {
        font-size: 34px;
        font-weight: 900;
        color: #f59e0b;
        margin-bottom: 4px;
    }

    .review-item {
        border: 1px solid #e5e7eb;
        border-radius: 20px;
        padding: 18px;
        margin-bottom: 14px;
        background: #f8fafc;
    }

    .review-user {
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 4px;
    }

    .review-date {
        color: #64748b;
        font-size: 13px;
        margin-bottom: 8px;
    }

    .review-stars {
        color: #f59e0b;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .review-text {
        color: #334155;
        line-height: 1.7;
        font-weight: 600;
    }

    .empty-review {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 20px;
        padding: 24px;
        color: #64748b;
        text-align: center;
    }

    @media (max-width: 991.98px) {
        .product-title {
            font-size: 30px;
        }

        .product-image-box {
            min-height: 260px;
            padding: 18px;
        }

        .product-image {
            min-height: unset;
            max-height: 260px;
        }

        .detail-body {
            padding: 24px;
        }

        .meta-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

@php
    $avgRating = $product->reviews_avg_rating ? round($product->reviews_avg_rating, 1) : 0;
    $reviewCount = $product->reviews_count ?? 0;
@endphp

<div class="container product-detail-page">
    @if(session('success'))
        <div class="alert alert-success mb-4">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger mb-4">
            {{ session('error') }}
        </div>
    @endif

    <div class="detail-card">
        <div class="row g-0">
            <div class="col-lg-6">
                <div class="product-image-box">
                    @if($product->image)
                        <img src="{{ asset('storage/' . $product->image) }}"
                             alt="{{ $product->name }}"
                             class="product-image">
                    @else
                        <div class="product-placeholder">🏌️</div>
                    @endif
                </div>
            </div>

            <div class="col-lg-6">
                <div class="detail-body">
                    <div class="category-pill">
                        {{ optional($product->category)->name ?? 'Tanpa Kategori' }}
                    </div>

                    <h1 class="product-title">
                        {{ $product->name }}
                    </h1>

                    <div class="rating-summary">
                        @if($reviewCount > 0)
                            <div class="rating-score">
                                ⭐ {{ $avgRating }} / 5
                            </div>

                            <div class="rating-count">
                                Berdasarkan {{ $reviewCount }} ulasan customer
                            </div>
                        @else
                            <div class="rating-count">
                                Produk ini belum memiliki ulasan.
                            </div>
                        @endif
                    </div>

                    <div class="price-text">
                        Rp {{ number_format($product->price, 0, ',', '.') }}
                    </div>

                    <div class="meta-grid">
                        <div class="meta-box">
                            <div class="meta-label">Stok</div>
                            <div class="meta-value">
                                {{ $product->stock > 0 ? $product->stock . ' tersedia' : 'Stok habis' }}
                            </div>
                        </div>

                        <div class="meta-box">
                            <div class="meta-label">Kondisi</div>
                            <div class="meta-value">
                                {{ $product->condition ?? 'Baru' }}
                            </div>
                        </div>
                    </div>

                    <div class="description-box">
                        {!! nl2br(e($product->description ?? 'Belum ada deskripsi produk.')) !!}
                    </div>

                    <div class="row g-2">
                        <div class="col-md-12">
                            @auth
                                <form action="{{ route('cart.add', $product->id) }}" method="POST">
                                    @csrf

                                    <button type="submit"
                                            class="btn-cart"
                                            {{ $product->stock <= 0 ? 'disabled' : '' }}>
                                        {{ $product->stock > 0 ? 'Tambah ke Keranjang' : 'Stok Habis' }}
                                    </button>
                                </form>
                            @else
                                <a href="{{ route('login') }}" class="btn-cart text-decoration-none d-flex align-items-center justify-content-center">
                                    Login untuk Beli
                                </a>
                            @endauth
                        </div>

                        @auth
                            <div class="col-md-6">
                                <a href="{{ route('chat.index', ['product_id' => $product->id]) }}" class="btn-chat">
                                    Tanya Admin
                                </a>
                            </div>

                            <div class="col-md-6">
                                <a href="{{ route('products.index') }}" class="btn-back">
                                    Kembali
                                </a>
                            </div>
                        @else
                            <div class="col-md-12">
                                <a href="{{ route('products.index') }}" class="btn-back">
                                    Kembali ke Produk
                                </a>
                            </div>
                        @endauth
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="reviews-card">
        <h2 class="reviews-title">Ulasan Customer</h2>

        @if($reviewCount > 0)
            <div class="review-summary-box">
                <div class="review-score-large">
                    ⭐ {{ $avgRating }} / 5
                </div>

                <div class="text-muted fw-bold">
                    Berdasarkan {{ $reviewCount }} ulasan customer yang sudah membeli produk ini.
                </div>
            </div>

            @foreach($product->reviews as $review)
                <div class="review-item">
                    <div class="review-user">
                        {{ optional($review->user)->name ?? 'Customer' }}
                    </div>

                    <div class="review-date">
                        {{ $review->created_at->format('d M Y H:i') }}
                    </div>

                    <div class="review-stars">
                        @for($i = 1; $i <= 5; $i++)
                            {{ $i <= $review->rating ? '⭐' : '☆' }}
                        @endfor
                    </div>

                    <div class="review-text">
                        {{ $review->review ?? 'Customer tidak menulis ulasan.' }}
                    </div>
                </div>
            @endforeach
        @else
            <div class="empty-review">
                <h5>Belum Ada Ulasan</h5>
                <p class="mb-0">
                    Ulasan dari customer akan muncul setelah pesanan produk ini selesai dan customer memberikan penilaian.
                </p>
            </div>
        @endif
    </div>
</div>
@endsection