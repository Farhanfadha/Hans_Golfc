@extends('layouts.app')

@section('content')
<style>
    .cart-page {
        padding-bottom: 50px;
    }

    .cart-hero {
        position: relative;
        overflow: hidden;
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.96), rgba(30, 41, 59, 0.92));
        border-radius: 28px;
        padding: 50px 40px;
        color: white;
        box-shadow: 0 20px 50px rgba(15, 23, 42, 0.12);
        margin-bottom: 32px;
    }

    .cart-hero::before {
        content: '';
        position: absolute;
        top: -50px;
        right: -50px;
        width: 220px;
        height: 220px;
        border-radius: 50%;
        background: radial-gradient(circle, rgba(250, 204, 21, 0.22), transparent 70%);
    }

    .cart-hero-content {
        position: relative;
        z-index: 2;
    }

    .cart-badge {
        display: inline-block;
        padding: 8px 14px;
        border-radius: 999px;
        background: rgba(255,255,255,0.10);
        color: #fde68a;
        font-size: 14px;
        font-weight: 600;
        margin-bottom: 14px;
    }

    .cart-title {
        font-size: 42px;
        font-weight: 800;
        margin-bottom: 10px;
        line-height: 1.1;
    }

    .cart-subtitle {
        color: #cbd5e1;
        font-size: 16px;
        margin-bottom: 0;
        max-width: 700px;
    }

    .cart-card,
    .summary-card {
        background: white;
        border: none;
        border-radius: 24px;
        box-shadow: 0 14px 35px rgba(15, 23, 42, 0.08);
    }

    .cart-card {
        padding: 24px;
    }

    .summary-card {
        padding: 24px;
        position: sticky;
        top: 20px;
    }

    .section-title {
        font-size: 24px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 18px;
    }

    .cart-item {
        border: 1px solid #e2e8f0;
        border-radius: 20px;
        padding: 18px;
        transition: 0.25s ease;
        background: linear-gradient(135deg, #ffffff, #f8fafc);
    }

    .cart-item:hover {
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
    }

    .cart-thumb {
        width: 88px;
        height: 88px;
        border-radius: 18px;
        background: linear-gradient(135deg, #dbe4ee, #f8fafc);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 36px;
        color: #334155;
        flex-shrink: 0;
        overflow: hidden;
    }

    .cart-thumb img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .cart-item-title {
        font-size: 20px;
        font-weight: 800;
        color: #0f172a;
        margin-bottom: 6px;
    }

    .cart-item-meta {
        color: #64748b;
        font-size: 14px;
        margin-bottom: 10px;
    }

    .cart-price {
        font-size: 20px;
        font-weight: 800;
        color: #ca8a04;
        margin-bottom: 10px;
    }

    .qty-box {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .qty-input {
        width: 90px;
        border-radius: 12px;
        border: 1px solid #dbe3ec;
        padding: 8px 12px;
        min-height: 42px;
    }

    .qty-input:focus {
        border-color: #94a3b8;
        outline: none;
        box-shadow: 0 0 0 0.2rem rgba(148, 163, 184, 0.15);
    }

    .btn-update-custom {
        background: #111827;
        color: white;
        border: none;
        border-radius: 12px;
        padding: 9px 14px;
        font-weight: 700;
    }

    .btn-update-custom:hover {
        background: #1f2937;
        color: white;
    }

    .btn-remove-custom {
        background: #ef4444;
        color: white;
        border: none;
        border-radius: 12px;
        padding: 9px 14px;
        font-weight: 700;
    }

    .btn-remove-custom:hover {
        background: #dc2626;
        color: white;
    }

    .item-subtotal {
        font-size: 18px;
        font-weight: 800;
        color: #0f172a;
        text-align: right;
    }

    .summary-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 14px;
        color: #475569;
    }

    .summary-total {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding-top: 16px;
        margin-top: 16px;
        border-top: 1px solid #e2e8f0;
        font-size: 22px;
        font-weight: 800;
        color: #0f172a;
    }

    .btn-checkout-custom {
        display: block;
        width: 100%;
        text-align: center;
        background: #facc15;
        color: #111827;
        font-weight: 800;
        border-radius: 14px;
        padding: 13px 18px;
        text-decoration: none;
        margin-top: 18px;
        transition: 0.2s ease;
    }

    .btn-checkout-custom:hover {
        background: #eab308;
        color: #111827;
    }

    .btn-continue-custom {
        display: block;
        width: 100%;
        text-align: center;
        background: #f8fafc;
        color: #0f172a;
        border: 1px solid #e2e8f0;
        font-weight: 700;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        margin-top: 12px;
    }

    .btn-continue-custom:hover {
        background: #f1f5f9;
        color: #0f172a;
    }

    .empty-cart {
        background: white;
        border-radius: 24px;
        padding: 55px 24px;
        text-align: center;
        box-shadow: 0 14px 35px rgba(15, 23, 42, 0.08);
    }

    .empty-cart-icon {
        font-size: 56px;
        margin-bottom: 14px;
    }

    @media (max-width: 991.98px) {
        .cart-hero {
            padding: 40px 26px;
        }

        .cart-title {
            font-size: 34px;
        }

        .summary-card {
            position: static;
        }
    }
</style>

<div class="container cart-page">
    <section class="cart-hero">
        <div class="cart-hero-content">
            <span class="cart-badge">Shopping Cart</span>
            <h1 class="cart-title">Keranjang Belanja</h1>
            <p class="cart-subtitle">
                Tinjau kembali produk pilihan Anda, atur jumlah pembelian, dan lanjutkan ke proses checkout dengan mudah.
            </p>
        </div>
    </section>

    @if(count($cart) > 0)
        @php $total = 0; @endphp

        <div class="row g-4">
            <div class="col-lg-8">
                <div class="cart-card">
                    <h2 class="section-title">Item dalam Keranjang</h2>

                    <div class="d-flex flex-column gap-3">
                        @foreach($cart as $item)
                            @php
                                $subtotal = $item['price'] * $item['quantity'];
                                $total += $subtotal;
                            @endphp

                            <div class="cart-item">
                                <div class="d-flex gap-3 flex-column flex-md-row justify-content-between align-items-md-center">
                                    <div class="d-flex gap-3 align-items-start">
                                        <div class="cart-thumb">
                                            @if(!empty($item['image']))
                                                <img src="{{ asset('storage/' . $item['image']) }}" alt="{{ $item['name'] }}">
                                            @else
                                                ⛳
                                            @endif
                                        </div>

                                        <div>
                                            <h5 class="cart-item-title">{{ $item['name'] }}</h5>
                                            <div class="cart-item-meta">
                                                Harga satuan: Rp {{ number_format($item['price'], 0, ',', '.') }}
                                            </div>
                                            <div class="cart-price">
                                                Rp {{ number_format($item['price'], 0, ',', '.') }}
                                            </div>

                                            <form action="{{ route('cart.update', $item['id']) }}" method="POST" class="qty-box">
                                                @csrf
                                                <input type="number"
                                                       name="quantity"
                                                       value="{{ $item['quantity'] }}"
                                                       min="1"
                                                       class="qty-input">
                                                <button type="submit" class="btn-update-custom">
                                                    Update
                                                </button>
                                            </form>
                                        </div>
                                    </div>

                                    <div class="text-md-end">
                                        <div class="item-subtotal mb-3">
                                            Rp {{ number_format($subtotal, 0, ',', '.') }}
                                        </div>

                                        <form action="{{ route('cart.remove', $item['id']) }}" method="POST">
                                            @csrf
                                            <button type="submit" class="btn-remove-custom">
                                                Hapus
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="summary-card">
                    <h2 class="section-title">Ringkasan Belanja</h2>

                    <div class="summary-row">
                        <span>Total Item</span>
                        <strong>{{ count($cart) }}</strong>
                    </div>

                    <div class="summary-row">
                        <span>Status</span>
                        <strong>Siap Checkout</strong>
                    </div>

                    <div class="summary-total">
                        <span>Total</span>
                        <span>Rp {{ number_format($total, 0, ',', '.') }}</span>
                    </div>

                    <a href="{{ route('cart.checkout') }}" class="btn-checkout-custom">
                        Lanjut ke Checkout
                    </a>

                    <a href="{{ route('products.index') }}" class="btn-continue-custom">
                        Lanjut Belanja
                    </a>
                </div>
            </div>
        </div>
    @else
        <div class="empty-cart">
            <div class="empty-cart-icon">🛒</div>
            <h3 class="fw-bold mb-2">Keranjang masih kosong</h3>
            <p class="text-muted mb-4">
                Belum ada produk di keranjang. Yuk pilih produk terbaik dari Hans Golf.
            </p>
            <a href="{{ route('products.index') }}" class="btn-checkout-custom" style="max-width: 260px; margin: 0 auto;">
                Belanja Sekarang
            </a>
        </div>
    @endif
</div>
@endsection