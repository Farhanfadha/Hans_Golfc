@extends('layouts.app')

@section('content')
<style>
    .admin-chat-page {
        padding-bottom: 50px;
    }

    .chat-shell {
        background: white;
        border-radius: 28px;
        overflow: hidden;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.12);
        border: 1px solid #e5e7eb;
        max-width: 1050px;
        margin: 0 auto;
    }

    .chat-header {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        padding: 28px 32px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 18px;
        flex-wrap: wrap;
    }

    .customer-box {
        display: flex;
        align-items: center;
        gap: 14px;
    }

    .avatar-circle {
        width: 56px;
        height: 56px;
        border-radius: 999px;
        background: linear-gradient(135deg, #16a34a, #15803d);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        font-size: 22px;
        flex-shrink: 0;
    }

    .chat-title {
        font-size: 28px;
        font-weight: 900;
        margin-bottom: 4px;
    }

    .chat-subtitle {
        color: #cbd5e1;
        margin-bottom: 0;
        font-size: 14px;
    }

    .btn-back-chat {
        background: rgba(255,255,255,0.12);
        color: white;
        text-decoration: none;
        border-radius: 14px;
        padding: 10px 15px;
        font-weight: 900;
        border: 1px solid rgba(255,255,255,0.14);
    }

    .btn-back-chat:hover {
        background: rgba(255,255,255,0.18);
        color: white;
    }

    .chat-body {
        background: linear-gradient(180deg, #f8fafc, #ffffff);
        padding: 28px;
        min-height: 500px;
        max-height: 620px;
        overflow-y: auto;
    }

    .message-row {
        display: flex;
        margin-bottom: 16px;
    }

    .message-row.admin {
        justify-content: flex-end;
    }

    .message-row.user {
        justify-content: flex-start;
    }

    .message-bubble {
        max-width: 72%;
        padding: 14px 16px;
        border-radius: 18px;
        box-shadow: 0 8px 18px rgba(15, 23, 42, 0.06);
    }

    .message-row.admin .message-bubble {
        background: #0f172a;
        color: white;
        border-bottom-right-radius: 6px;
    }

    .message-row.user .message-bubble {
        background: white;
        color: #0f172a;
        border: 1px solid #e5e7eb;
        border-bottom-left-radius: 6px;
    }

    .message-sender {
        font-size: 12px;
        font-weight: 900;
        margin-bottom: 5px;
        opacity: 0.85;
    }

    .message-text {
        white-space: pre-line;
        line-height: 1.6;
        font-weight: 600;
    }

    .message-time {
        font-size: 11px;
        opacity: 0.75;
        margin-top: 7px;
    }

    .quick-help {
        background: #f8fafc;
        border-top: 1px solid #e5e7eb;
        padding: 16px 28px;
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
    }

    .quick-chip {
        border: 1px solid #dbe3ec;
        background: white;
        color: #334155;
        border-radius: 999px;
        padding: 8px 12px;
        font-weight: 800;
        font-size: 13px;
        cursor: pointer;
    }

    .quick-chip:hover {
        background: #f1f5f9;
    }

    .chat-form {
        border-top: 1px solid #e5e7eb;
        padding: 22px 28px;
        background: white;
    }

    .message-input {
        border-radius: 18px;
        border: 1px solid #dbe3ec;
        min-height: 54px;
        resize: none;
        padding: 14px 16px;
        font-weight: 600;
    }

    .message-input:focus {
        border-color: #94a3b8;
        box-shadow: 0 0 0 0.2rem rgba(148, 163, 184, 0.16);
    }

    .btn-send {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 16px;
        padding: 13px 20px;
        font-weight: 900;
        height: 54px;
        min-width: 130px;
    }

    .btn-send:hover {
        background: #15803d;
        color: white;
    }

    @media (max-width: 768px) {
        .chat-header,
        .chat-body,
        .quick-help,
        .chat-form {
            padding-left: 18px;
            padding-right: 18px;
        }

        .message-bubble {
            max-width: 88%;
        }

        .chat-title {
            font-size: 24px;
        }

        .btn-send {
            width: 100%;
        }
    }
</style>

@php
    $customerName = optional($chat->user)->name ?? 'Customer';
    $customerEmail = optional($chat->user)->email ?? '-';
    $initial = strtoupper(substr($customerName, 0, 1));
@endphp

<div class="container admin-chat-page">
    <div class="chat-shell">
        <div class="chat-header">
            <div class="customer-box">
                <div class="avatar-circle">
                    {{ $initial }}
                </div>

                <div>
                    <h1 class="chat-title">{{ $customerName }}</h1>
                    <p class="chat-subtitle">
                        {{ $customerEmail }} · Percakapan customer Hans Golf
                    </p>
                </div>
            </div>

            <a href="{{ route('admin.chats.index') }}" class="btn-back-chat">
                Kembali ke Daftar Chat
            </a>
        </div>

        <div class="chat-body" id="chatBody">
            @foreach($messages as $message)
                @php
                    $isAdmin = $message->sender_type === 'admin';
                @endphp

                <div class="message-row {{ $isAdmin ? 'admin' : 'user' }}">
                    <div class="message-bubble">
                        <div class="message-sender">
                            {{ $isAdmin ? 'Admin Hans Golf' : $customerName }}
                        </div>

                        <div class="message-text">{{ $message->message }}</div>

                        <div class="message-time">
                            {{ $message->created_at->format('d M Y H:i') }}
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="quick-help">
            <button type="button" class="quick-chip" data-message="Halo, terima kasih sudah menghubungi Hans Golf. Ada yang bisa kami bantu?">
                Salam Pembuka
            </button>

            <button type="button" class="quick-chip" data-message="Pembayaran Anda sudah kami terima dan pesanan akan segera diproses.">
                Pembayaran Diterima
            </button>

            <button type="button" class="quick-chip" data-message="Pesanan Anda sedang kami siapkan. Kami akan informasikan nomor resi setelah paket dikirim.">
                Pesanan Diproses
            </button>

            <button type="button" class="quick-chip" data-message="Mohon menunggu sebentar, kami akan cek terlebih dahulu.">
                Cek Dulu
            </button>
        </div>

        <form action="{{ route('admin.chats.send', $chat->id) }}" method="POST" class="chat-form">
            @csrf

            <div class="row g-3 align-items-end">
                <div class="col-lg-10">
                    <textarea name="message"
                              id="messageInput"
                              class="form-control message-input"
                              rows="2"
                              placeholder="Tulis balasan admin..."
                              required>{{ old('message') }}</textarea>
                </div>

                <div class="col-lg-2">
                    <button type="submit" class="btn-send">
                        Kirim
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    const chatBody = document.getElementById('chatBody');
    const messageInput = document.getElementById('messageInput');
    const quickChips = document.querySelectorAll('.quick-chip');

    if (chatBody) {
        chatBody.scrollTop = chatBody.scrollHeight;
    }

    quickChips.forEach(function (chip) {
        chip.addEventListener('click', function () {
            messageInput.value = this.dataset.message;
            messageInput.focus();
        });
    });
</script>
@endsection