@extends('layouts.app')

@section('content')
<style>
    .form-page {
        padding-bottom: 50px;
    }

    .form-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 28px;
        box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
        overflow: hidden;
        max-width: 850px;
        margin: 0 auto;
    }

    .form-header {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        padding: 32px;
    }

    .form-header h1 {
        font-size: 32px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .form-header p {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .form-body {
        padding: 32px;
    }

    .form-label {
        font-weight: 800;
        color: #0f172a;
    }

    .form-control {
        border-radius: 14px;
        min-height: 48px;
        border: 1px solid #dbe3ec;
    }

    .helper-box {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        padding: 16px;
        color: #475569;
        font-weight: 600;
        margin-bottom: 22px;
    }

    .example-pill {
        display: inline-block;
        background: #ecfdf5;
        color: #166534;
        border-radius: 999px;
        padding: 7px 11px;
        font-size: 13px;
        font-weight: 800;
        margin: 4px 4px 0 0;
    }

    .btn-save {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 12px 18px;
        font-weight: 900;
    }

    .btn-save:hover {
        background: #15803d;
        color: white;
    }

    .btn-back {
        background: #64748b;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: 900;
        display: inline-block;
    }

    .btn-back:hover {
        background: #475569;
        color: white;
    }
</style>

<div class="container form-page">
    <div class="form-card">
        <div class="form-header">
            <h1>Tambah Kategori</h1>
            <p>Buat kategori baru untuk mengelompokkan produk Hans Golf.</p>
        </div>

        <div class="form-body">
            @if($errors->any())
                <div class="alert alert-danger">
                    <strong>Terjadi kesalahan.</strong>

                    <ul class="mb-0 mt-2">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="helper-box">
                Contoh kategori yang bisa kamu tambahkan:
                <br>
                <span class="example-pill">Bola Golf</span>
                <span class="example-pill">Stick Golf</span>
                <span class="example-pill">Golf Bags</span>
                <span class="example-pill">Accessories</span>
            </div>

            <form action="{{ route('admin.categories.store') }}" method="POST">
                @csrf

                <div class="mb-4">
                    <label class="form-label">Nama Kategori</label>
                    <input type="text"
                           name="name"
                           class="form-control"
                           value="{{ old('name') }}"
                           placeholder="Contoh: Accessories"
                           required>
                </div>

                <div class="d-flex gap-2 flex-wrap">
                    <button type="submit" class="btn-save">
                        Simpan Kategori
                    </button>

                    <a href="{{ route('admin.categories.index') }}" class="btn-back">
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection