@extends('layouts.app')

@section('content')
<style>
    .order-detail-page {
        padding-bottom: 50px;
    }

    .detail-header {
        background: linear-gradient(135deg, #111827, #1f2937);
        color: white;
        border-radius: 28px;
        padding: 34px;
        margin-bottom: 28px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.12);
    }

    .detail-title {
        font-size: 32px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .detail-subtitle {
        color: rgba(255,255,255,0.82);
        margin-bottom: 0;
    }

    .custom-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 24px;
        padding: 24px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
        margin-bottom: 22px;
    }

    .section-title {
        font-size: 22px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 18px;
    }

    .info-label {
        font-size: 13px;
        font-weight: 800;
        color: #64748b;
        text-transform: uppercase;
        margin-bottom: 5px;
    }

    .info-value {
        color: #0f172a;
        font-size: 16px;
        font-weight: 700;
        margin-bottom: 14px;
    }

    .status-badge-custom {
        display: inline-block;
        padding: 8px 13px;
        border-radius: 999px;
        font-size: 13px;
        font-weight: 900;
        margin-right: 6px;
        margin-bottom: 6px;
    }

    .status-order-new {
        background: #f1f5f9;
        color: #334155;
    }

    .status-order-processing {
        background: #dbeafe;
        color: #1e40af;
    }

    .status-order-completed {
        background: #dcfce7;
        color: #166534;
    }

    .status-order-cancelled {
        background: #fee2e2;
        color: #991b1b;
    }

    .status-payment-pending {
        background: #fef3c7;
        color: #92400e;
    }

    .status-payment-waiting {
        background: #dbeafe;
        color: #1e40af;
    }

    .status-payment-paid {
        background: #dcfce7;
        color: #166534;
    }

    .status-payment-rejected {
        background: #fee2e2;
        color: #991b1b;
    }

    .status-shipping-not-shipped {
        background: #fef3c7;
        color: #92400e;
    }

    .status-shipping-shipped {
        background: #dcfce7;
        color: #166534;
    }

    .bank-box {
        background: linear-gradient(135deg, #fffbeb, #ffffff);
        border: 1px solid #fde68a;
        border-radius: 20px;
        padding: 20px;
        margin-bottom: 18px;
    }

    .bank-number {
        font-size: 28px;
        font-weight: 900;
        color: #0f172a;
        letter-spacing: 1px;
        margin-bottom: 5px;
    }

    .btn-copy {
        border: none;
        background: #111827;
        color: white;
        border-radius: 12px;
        padding: 10px 14px;
        font-weight: 800;
        margin-top: 10px;
    }

    .btn-copy:hover {
        background: #1f2937;
        color: white;
    }

    .btn-upload {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 12px 18px;
        font-weight: 900;
    }

    .btn-upload:hover {
        background: #15803d;
        color: white;
    }

    .btn-back {
        background: #64748b;
        color: white;
        border-radius: 14px;
        padding: 11px 16px;
        text-decoration: none;
        font-weight: 800;
        display: inline-block;
    }

    .btn-back:hover {
        background: #475569;
        color: white;
    }

    .btn-home {
        background: #111827;
        color: white;
        border-radius: 14px;
        padding: 11px 16px;
        text-decoration: none;
        font-weight: 800;
        display: inline-block;
    }

    .btn-home:hover {
        background: #1f2937;
        color: white;
    }

    .form-control-custom {
        border-radius: 14px;
        min-height: 48px;
        border: 1px solid #dbe3ec;
    }

    .payment-preview {
        display: none;
        max-width: 260px;
        border-radius: 16px;
        border: 1px solid #e2e8f0;
        margin-top: 12px;
    }

    .proof-img {
        max-width: 100%;
        max-height: 360px;
        border-radius: 16px;
        border: 1px solid #e5e7eb;
        margin-top: 10px;
    }

    .timeline {
        display: grid;
        gap: 12px;
    }

    .timeline-item {
        display: flex;
        gap: 12px;
        align-items: flex-start;
        padding: 14px;
        border-radius: 16px;
        background: #f8fafc;
        border: 1px solid #e5e7eb;
    }

    .timeline-dot {
        width: 22px;
        height: 22px;
        border-radius: 999px;
        background: #cbd5e1;
        flex-shrink: 0;
        margin-top: 2px;
    }

    .timeline-item.active .timeline-dot {
        background: #16a34a;
    }

    .timeline-title {
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 2px;
    }

    .timeline-desc {
        color: #64748b;
        font-size: 14px;
        margin-bottom: 0;
    }

    .item-row {
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        padding: 16px;
        margin-bottom: 12px;
        background: #f8fafc;
    }

    .item-name {
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 5px;
    }

    .item-meta {
        color: #64748b;
        font-size: 14px;
    }

    .item-subtotal {
        font-weight: 900;
        color: #ca8a04;
    }

    .shipping-box {
        background: linear-gradient(135deg, #ecfdf5, #ffffff);
        border: 1px solid #bbf7d0;
        border-radius: 20px;
        padding: 20px;
        margin-bottom: 18px;
    }

    .tracking-number {
        font-size: 24px;
        font-weight: 900;
        color: #0f172a;
        word-break: break-all;
        margin-bottom: 8px;
    }

    .review-box {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 18px;
        padding: 18px;
        margin-top: 14px;
    }

    .review-title {
        font-size: 18px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 12px;
    }

    .btn-review {
        background: #f59e0b;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 11px 16px;
        font-weight: 900;
    }

    .btn-review:hover {
        background: #d97706;
        color: white;
    }

    @media (max-width: 991.98px) {
        .detail-title {
            font-size: 28px;
        }

        .custom-card {
            padding: 20px;
        }
    }
</style>

@php
    $orderStatusLabels = [
        'new' => 'Order Baru',
        'processing' => 'Diproses',
        'completed' => 'Selesai',
        'cancelled' => 'Dibatalkan',
    ];

    $orderStatusClasses = [
        'new' => 'status-order-new',
        'processing' => 'status-order-processing',
        'completed' => 'status-order-completed',
        'cancelled' => 'status-order-cancelled',
    ];

    $paymentStatusLabels = [
        'pending' => 'Menunggu Pembayaran',
        'waiting_confirmation' => 'Menunggu Konfirmasi Admin',
        'paid' => 'Lunas',
        'rejected' => 'Pembayaran Ditolak',
    ];

    $paymentStatusClasses = [
        'pending' => 'status-payment-pending',
        'waiting_confirmation' => 'status-payment-waiting',
        'paid' => 'status-payment-paid',
        'rejected' => 'status-payment-rejected',
    ];

    $shippingStatusLabels = [
        'not_shipped' => 'Belum Dikirim',
        'shipped' => 'Sudah Dikirim',
    ];

    $shippingStatusClasses = [
        'not_shipped' => 'status-shipping-not-shipped',
        'shipped' => 'status-shipping-shipped',
    ];

    $orderStatus = $order->status ?? 'new';
    $paymentStatus = $order->payment_status ?? 'pending';
    $shippingStatus = $order->shipping_status ?? 'not_shipped';

    $isImageProof = false;

    if ($order->payment_proof) {
        $isImageProof = preg_match('/\.(jpg|jpeg|png|webp)$/i', $order->payment_proof);
    }

    $timeline = [
        [
            'title' => 'Pesanan Dibuat',
            'desc' => 'Pesanan Anda berhasil masuk ke sistem Hans Golf.',
            'active' => true,
        ],
        [
            'title' => 'Menunggu Pembayaran',
            'desc' => 'Silakan transfer sesuai total pembayaran.',
            'active' => in_array($paymentStatus, ['pending', 'waiting_confirmation', 'paid']),
        ],
        [
            'title' => 'Bukti Transfer Dikirim',
            'desc' => 'Bukti transfer sedang menunggu pengecekan admin.',
            'active' => in_array($paymentStatus, ['waiting_confirmation', 'paid']),
        ],
        [
            'title' => 'Pembayaran Dikonfirmasi',
            'desc' => 'Pembayaran sudah diterima dan pesanan akan diproses.',
            'active' => $paymentStatus === 'paid',
        ],
        [
            'title' => 'Pesanan Diproses',
            'desc' => 'Pesanan sedang diproses oleh admin Hans Golf.',
            'active' => in_array($orderStatus, ['processing', 'completed']),
        ],
        [
            'title' => 'Pesanan Dikirim',
            'desc' => $order->tracking_number
                ? 'Pesanan sudah dikirim melalui ' . $order->courier_name . ' dengan resi ' . $order->tracking_number . '.'
                : 'Pesanan akan dikirim setelah selesai diproses.',
            'active' => $shippingStatus === 'shipped',
        ],
        [
            'title' => 'Pesanan Selesai',
            'desc' => 'Pesanan sudah selesai. Anda dapat memberikan ulasan produk.',
            'active' => $orderStatus === 'completed',
        ],
    ];
@endphp

<div class="container order-detail-page">
    <div class="detail-header">
        <h1 class="detail-title">Detail Pesanan</h1>
        <p class="detail-subtitle">
            Pantau status pesanan {{ $order->order_code }} secara lengkap.
        </p>
    </div>

    @if(session('success'))
        <div class="alert alert-success mb-4">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger mb-4">
            {{ session('error') }}
        </div>
    @endif

    @if($errors->any())
        <div class="alert alert-danger mb-4">
            <strong>Terjadi kesalahan.</strong>

            <ul class="mb-0 mt-2">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="row g-4">
        <div class="col-lg-7">
            <div class="custom-card">
                <h2 class="section-title">Ringkasan Pesanan</h2>

                <div class="row">
                    <div class="col-md-6">
                        <div class="info-label">Kode Order</div>
                        <div class="info-value">{{ $order->order_code }}</div>
                    </div>

                    <div class="col-md-6">
                        <div class="info-label">Tanggal Order</div>
                        <div class="info-value">{{ $order->created_at->format('d M Y H:i') }}</div>
                    </div>

                    <div class="col-md-6">
                        <div class="info-label">Status Pesanan</div>
                        <span class="status-badge-custom {{ $orderStatusClasses[$orderStatus] ?? 'status-order-new' }}">
                            {{ $orderStatusLabels[$orderStatus] ?? $orderStatus }}
                        </span>
                    </div>

                    <div class="col-md-6">
                        <div class="info-label">Status Pembayaran</div>
                        <span class="status-badge-custom {{ $paymentStatusClasses[$paymentStatus] ?? 'status-payment-pending' }}">
                            {{ $paymentStatusLabels[$paymentStatus] ?? $paymentStatus }}
                        </span>
                    </div>

                    <div class="col-md-6 mt-3">
                        <div class="info-label">Status Pengiriman</div>
                        <span class="status-badge-custom {{ $shippingStatusClasses[$shippingStatus] ?? 'status-shipping-not-shipped' }}">
                            {{ $shippingStatusLabels[$shippingStatus] ?? 'Belum Dikirim' }}
                        </span>
                    </div>
                </div>

                <hr>

                @if($order->shipping_cost > 0)
                    <div class="d-flex justify-content-between mb-1" style="color:#475569; font-weight:600;">
                        <span>Subtotal Produk</span>
                        <span>Rp {{ number_format($order->total_price - $order->shipping_cost, 0, ',', '.') }}</span>
                    </div>
                    <div class="d-flex justify-content-between mb-2" style="color:#475569; font-weight:600;">
                        <span>Ongkir Reguler ({{ $order->shipping_courier ?? 'Anter Aja' }})</span>
                        <span>Rp {{ number_format($order->shipping_cost, 0, ',', '.') }}</span>
                    </div>
                @endif

                <div class="info-label">Total Pembayaran</div>
                <div style="font-size: 30px; font-weight: 900; color: #ca8a04;">
                    Rp {{ number_format($order->total_price, 0, ',', '.') }}
                </div>
            </div>

            <div class="custom-card">
                <h2 class="section-title">Data Customer</h2>

                <div class="info-label">Nama</div>
                <div class="info-value">{{ $order->customer_name }}</div>

                <div class="info-label">No. WhatsApp</div>
                <div class="info-value">{{ $order->customer_phone }}</div>

                <div class="info-label">Alamat</div>
                <div class="info-value">{{ $order->customer_address }}</div>

                <div class="info-label">Catatan</div>
                <div class="info-value">{{ $order->note ?? '-' }}</div>
            </div>

            <div class="custom-card">
                <h2 class="section-title">Item Pesanan</h2>

                @foreach($order->items as $item)
                    <div class="item-row">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <div class="item-name">{{ $item->product_name }}</div>
                                <div class="item-meta">
                                    {{ $item->quantity }} x Rp {{ number_format($item->price, 0, ',', '.') }}
                                </div>
                            </div>

                            <div class="col-md-6 text-md-end">
                                <div class="item-subtotal">
                                    Rp {{ number_format($item->subtotal, 0, ',', '.') }}
                                </div>
                            </div>
                        </div>

                        @if($orderStatus === 'completed')
                            <hr>

                            <div class="review-box">
                                <div class="review-title">
                                    Beri Ulasan Produk
                                </div>

                                @if($item->review)
                                    <div class="alert alert-success">
                                        Anda sudah memberi ulasan untuk produk ini. Anda tetap bisa mengubah ulasan di bawah.
                                    </div>
                                @else
                                    <div class="alert alert-info">
                                        Pesanan sudah selesai. Silakan beri rating dan ulasan untuk produk ini.
                                    </div>
                                @endif

                                <form action="{{ route('reviews.store', [$order->id, $item->id]) }}" method="POST">
                                    @csrf

                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Rating Bintang</label>
                                        <select name="rating" class="form-select" required>
                                            <option value="">Pilih Rating</option>
                                            <option value="5" {{ old('rating', optional($item->review)->rating) == 5 ? 'selected' : '' }}>
                                                ⭐⭐⭐⭐⭐ - Sangat Puas
                                            </option>
                                            <option value="4" {{ old('rating', optional($item->review)->rating) == 4 ? 'selected' : '' }}>
                                                ⭐⭐⭐⭐ - Puas
                                            </option>
                                            <option value="3" {{ old('rating', optional($item->review)->rating) == 3 ? 'selected' : '' }}>
                                                ⭐⭐⭐ - Cukup
                                            </option>
                                            <option value="2" {{ old('rating', optional($item->review)->rating) == 2 ? 'selected' : '' }}>
                                                ⭐⭐ - Kurang
                                            </option>
                                            <option value="1" {{ old('rating', optional($item->review)->rating) == 1 ? 'selected' : '' }}>
                                                ⭐ - Tidak Puas
                                            </option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label fw-bold">Ulasan</label>
                                        <textarea name="review"
                                                  class="form-control"
                                                  rows="3"
                                                  placeholder="Ceritakan pengalaman Anda membeli produk ini...">{{ old('review', optional($item->review)->review) }}</textarea>
                                    </div>

                                    <button type="submit" class="btn-review">
                                        {{ $item->review ? 'Update Ulasan' : 'Kirim Ulasan' }}
                                    </button>
                                </form>
                            </div>
                        @else
                            <hr>
                            <div class="alert alert-secondary mb-0">
                                Ulasan bisa diberikan setelah admin mengubah status pesanan menjadi <strong>completed / selesai</strong>.
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>

            <div class="custom-card">
                <h2 class="section-title">Timeline Pesanan</h2>

                <div class="timeline">
                    @foreach($timeline as $step)
                        <div class="timeline-item {{ $step['active'] ? 'active' : '' }}">
                            <div class="timeline-dot"></div>

                            <div>
                                <div class="timeline-title">{{ $step['title'] }}</div>
                                <p class="timeline-desc">{{ $step['desc'] }}</p>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="custom-card">
                <h2 class="section-title">Pembayaran Transfer</h2>

                <div class="bank-box">
                    <div class="info-label">Nomor Rekening</div>
                    <div class="bank-number" id="rekeningNumber">765-147-4373</div>
                    <div class="info-value mb-0">Bank BCA — Atas Nama: Farhan F.</div>

                    <button type="button" class="btn-copy" id="copyRekeningBtn">
                        Salin Nomor Rekening
                    </button>
                </div>

                <div class="info-label">Total yang Harus Ditransfer</div>
                <div style="font-size: 26px; font-weight: 900; color: #ca8a04; margin-bottom: 16px;">
                    Rp {{ number_format($order->total_price, 0, ',', '.') }}
                </div>

                @if($paymentStatus === 'paid')
                    <div class="alert alert-success">
                        Pembayaran Anda sudah dikonfirmasi admin.
                    </div>
                @elseif($paymentStatus === 'waiting_confirmation')
                    <div class="alert alert-info">
                        Bukti transfer sudah dikirim dan sedang menunggu konfirmasi admin.
                    </div>
                @elseif($paymentStatus === 'rejected')
                    <div class="alert alert-danger">
                        Bukti transfer sebelumnya ditolak. Silakan upload ulang bukti transfer yang benar.
                    </div>
                @else
                    <div class="alert alert-warning">
                        Silakan transfer sesuai nominal, lalu upload bukti transfer.
                    </div>
                @endif

                @if($order->sender_name)
                    <div class="info-label">Nama Pengirim</div>
                    <div class="info-value">{{ $order->sender_name }}</div>
                @endif

                @if($order->payment_proof)
                    <div class="info-label">Bukti Transfer</div>

                    @if($isImageProof)
                        <img src="{{ route('orders.paymentProof', $order->id) }}"
                             alt="Bukti Transfer"
                             class="proof-img">
                    @else
                        <p class="text-muted mt-2">Bukti transfer berupa PDF.</p>
                    @endif

                    <a href="{{ route('orders.paymentProof', $order->id) }}"
                       target="_blank"
                       class="btn btn-outline-primary mt-3">
                        Buka Bukti Transfer
                    </a>

                    <hr>
                @endif

                @if($paymentStatus !== 'paid')
                    <form action="{{ route('cart.uploadPaymentProof', $order->id) }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label fw-bold">Nama Pengirim</label>
                            <input type="text"
                                   name="sender_name"
                                   class="form-control form-control-custom"
                                   value="{{ old('sender_name', $order->sender_name) }}"
                                   placeholder="Masukkan nama pengirim transfer"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Upload Bukti Transfer</label>
                            <input type="file"
                                   name="payment_proof"
                                   id="paymentProofInput"
                                   class="form-control form-control-custom"
                                   accept=".jpg,.jpeg,.png,.webp,.pdf"
                                   required>

                            <small class="text-muted">
                                Format: JPG, JPEG, PNG, WEBP, atau PDF. Maksimal 2 MB.
                            </small>

                            <img id="paymentPreview" class="payment-preview" alt="Preview Bukti Transfer">
                        </div>

                        <div class="alert alert-warning">
                            Jika ada catatan transfer, sertakan kode order:
                            <strong>{{ $order->order_code }}</strong>
                        </div>

                        <button type="submit" class="btn-upload">
                            Upload Bukti Transfer
                        </button>
                    </form>
                @endif
            </div>

            <div class="custom-card">
                <h2 class="section-title">Informasi Pengiriman</h2>

                @if($shippingStatus === 'shipped')
                    <div class="alert alert-success">
                        Pesanan Anda sudah dikirim.
                    </div>

                    <div class="shipping-box">
                        <div class="info-label">Jasa Pengiriman</div>
                        <div class="info-value">{{ $order->courier_name ?? '-' }}</div>

                        <div class="info-label">Nomor Resi</div>
                        <div class="tracking-number" id="trackingNumber">
                            {{ $order->tracking_number ?? '-' }}
                        </div>

                        <button type="button" class="btn-copy" id="copyResiBtn">
                            Salin Nomor Resi
                        </button>
                    </div>

                    <div class="info-label">Tanggal Dikirim</div>
                    <div class="info-value">
                        {{ $order->shipped_at ? $order->shipped_at->format('d M Y H:i') : '-' }}
                    </div>

                    <div class="alert alert-info mb-0">
                        Silakan cek resi melalui website resmi jasa pengiriman terkait.
                    </div>
                @else
                    @if($paymentStatus === 'paid')
                        <div class="alert alert-warning mb-0">
                            Pembayaran sudah diterima. Pesanan Anda sedang disiapkan dan belum dikirim.
                        </div>
                    @else
                        <div class="alert alert-secondary mb-0">
                            Pesanan belum dikirim karena pembayaran belum selesai dikonfirmasi.
                        </div>
                    @endif
                @endif
            </div>

            <div class="d-flex gap-2 flex-wrap">
                <a href="{{ route('orders.index') }}" class="btn-back">
                    Kembali ke Pesanan Saya
                </a>

                <a href="{{ route('home') }}" class="btn-home">
                    Beranda
                </a>
            </div>
        </div>
    </div>
</div>

<script>
    const copyButton = document.getElementById('copyRekeningBtn');
    const rekeningNumber = document.getElementById('rekeningNumber');
    const paymentProofInput = document.getElementById('paymentProofInput');
    const paymentPreview = document.getElementById('paymentPreview');
    const copyResiButton = document.getElementById('copyResiBtn');
    const trackingNumber = document.getElementById('trackingNumber');

    if (copyButton && rekeningNumber) {
        copyButton.addEventListener('click', function () {
            const number = rekeningNumber.innerText.replace(/-/g, '');

            navigator.clipboard.writeText(number).then(function () {
                copyButton.innerText = 'Nomor Rekening Disalin';

                setTimeout(function () {
                    copyButton.innerText = 'Salin Nomor Rekening';
                }, 2000);
            });
        });
    }

    if (copyResiButton && trackingNumber) {
        copyResiButton.addEventListener('click', function () {
            const resi = trackingNumber.innerText.trim();

            navigator.clipboard.writeText(resi).then(function () {
                copyResiButton.innerText = 'Nomor Resi Disalin';

                setTimeout(function () {
                    copyResiButton.innerText = 'Salin Nomor Resi';
                }, 2000);
            });
        });
    }

    if (paymentProofInput && paymentPreview) {
        paymentProofInput.addEventListener('change', function () {
            const file = this.files[0];

            if (!file) {
                paymentPreview.style.display = 'none';
                paymentPreview.src = '';
                return;
            }

            if (!file.type.startsWith('image/')) {
                paymentPreview.style.display = 'none';
                paymentPreview.src = '';
                return;
            }

            paymentPreview.src = URL.createObjectURL(file);
            paymentPreview.style.display = 'block';
        });
    }
</script>
@endsection