@extends('layouts.app')

@section('content')
<style>
    .form-page {
        padding-bottom: 50px;
    }

    .form-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 28px;
        box-shadow: 0 16px 34px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }

    .form-header {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        padding: 32px;
    }

    .form-header h1 {
        font-size: 32px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .form-header p {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .form-body {
        padding: 32px;
    }

    .form-label {
        font-weight: 800;
        color: #0f172a;
    }

    .form-control,
    .form-select {
        border-radius: 14px;
        min-height: 48px;
        border: 1px solid #dbe3ec;
    }

    .preview-box {
        background: #f8fafc;
        border: 1px dashed #cbd5e1;
        border-radius: 20px;
        padding: 18px;
        text-align: center;
    }

    .current-img,
    .preview-img {
        max-width: 100%;
        max-height: 260px;
        object-fit: cover;
        border-radius: 18px;
        border: 1px solid #e5e7eb;
        margin-top: 12px;
    }

    .preview-img {
        display: none;
    }

    .empty-img {
        height: 180px;
        border-radius: 18px;
        background: #f1f5f9;
        border: 1px solid #e5e7eb;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #64748b;
        font-size: 42px;
        margin-top: 12px;
    }

    .btn-save {
        background: #16a34a;
        color: white;
        border: none;
        border-radius: 14px;
        padding: 12px 18px;
        font-weight: 900;
    }

    .btn-save:hover {
        background: #15803d;
        color: white;
    }

    .btn-back {
        background: #64748b;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: 900;
    }

    .btn-back:hover {
        background: #475569;
        color: white;
    }
</style>

<div class="container form-page">
    <div class="form-card">
        <div class="form-header">
            <h1>Edit Produk</h1>
            <p>Perbarui data produk yang tampil di katalog Hans Golf.</p>
        </div>

        <div class="form-body">
            @if($errors->any())
                <div class="alert alert-danger">
                    <strong>Terjadi kesalahan.</strong>

                    <ul class="mb-0 mt-2">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('admin.products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="mb-3">
                            <label class="form-label">Kategori</label>
                            <select name="category_id" class="form-select" required>
                                <option value="">Pilih Kategori</option>

                                @foreach($categories as $category)
                                    <option value="{{ $category->id }}"
                                        {{ old('category_id', $product->category_id) == $category->id ? 'selected' : '' }}>
                                        {{ $category->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nama Produk</label>
                            <input type="text"
                                   name="name"
                                   class="form-control"
                                   value="{{ old('name', $product->name) }}"
                                   required>
                        </div>

                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Harga</label>
                                <input type="number"
                                       name="price"
                                       class="form-control"
                                       value="{{ old('price', $product->price) }}"
                                       required>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">Stok</label>
                                <input type="number"
                                       name="stock"
                                       class="form-control"
                                       value="{{ old('stock', $product->stock) }}"
                                       required>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label">Kondisi</label>
                                <select name="condition" class="form-select">
                                    <option value="Baru" {{ old('condition', $product->condition) == 'Baru' ? 'selected' : '' }}>Baru</option>
                                    <option value="Bekas" {{ old('condition', $product->condition) == 'Bekas' ? 'selected' : '' }}>Bekas</option>
                                    <option value="Like New" {{ old('condition', $product->condition) == 'Like New' ? 'selected' : '' }}>Like New</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Status Aktif</label>
                            <select name="is_active" class="form-select" required>
                                <option value="1" {{ old('is_active', $product->is_active) == '1' ? 'selected' : '' }}>Aktif</option>
                                <option value="0" {{ old('is_active', $product->is_active) == '0' ? 'selected' : '' }}>Tidak Aktif</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea name="description"
                                      class="form-control"
                                      rows="5">{{ old('description', $product->description) }}</textarea>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="preview-box">
                            <label class="form-label d-block">Foto Produk</label>

                            <input type="file"
                                   name="image"
                                   id="imageInput"
                                   class="form-control"
                                   accept="image/*">

                            <small class="text-muted d-block mt-2">
                                Kosongkan jika tidak ingin mengganti foto.
                            </small>

                            @if($product->image)
                                <img src="{{ asset('storage/' . $product->image) }}"
                                     alt="{{ $product->name }}"
                                     class="current-img"
                                     id="currentImage">
                            @else
                                <div class="empty-img" id="currentImage">🏌️</div>
                            @endif

                            <img id="imagePreview" class="preview-img" alt="Preview Produk">
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2 flex-wrap mt-4">
                    <button type="submit" class="btn-save">
                        Update Produk
                    </button>

                    <a href="{{ route('admin.products.index') }}" class="btn-back">
                        Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const imageInput = document.getElementById('imageInput');
    const imagePreview = document.getElementById('imagePreview');
    const currentImage = document.getElementById('currentImage');

    if (imageInput && imagePreview) {
        imageInput.addEventListener('change', function () {
            const file = this.files[0];

            if (!file || !file.type.startsWith('image/')) {
                imagePreview.style.display = 'none';
                imagePreview.src = '';

                if (currentImage) {
                    currentImage.style.display = 'block';
                }

                return;
            }

            imagePreview.src = URL.createObjectURL(file);
            imagePreview.style.display = 'block';

            if (currentImage) {
                currentImage.style.display = 'none';
            }
        });
    }
</script>
@endsection