<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        if ($user->role === 'admin') {
            return $this->adminDashboard();
        }

        return $this->customerDashboard($user);
    }

    protected function adminDashboard()
    {
        $salesThisMonth = Order::where('payment_status', 'paid')
            ->whereMonth('paid_at', now()->month)
            ->whereYear('paid_at', now()->year)
            ->sum('total_price');

        $newOrdersCount = Order::where('status', 'new')->count();
        $waitingConfirmationCount = Order::where('payment_status', 'waiting_confirmation')->count();
        $totalProducts = Product::count();
        $lowStockCount = Product::where('is_active', true)->where('stock', '<=', 3)->count();

        $topProducts = OrderItem::select('product_name', DB::raw('SUM(quantity) as total_qty'))
            ->groupBy('product_name')
            ->orderByDesc('total_qty')
            ->take(5)
            ->get();

        $recentOrders = Order::latest()->take(5)->get();

        return view('dashboard', [
            'isAdmin' => true,
            'salesThisMonth' => $salesThisMonth,
            'newOrdersCount' => $newOrdersCount,
            'waitingConfirmationCount' => $waitingConfirmationCount,
            'totalProducts' => $totalProducts,
            'lowStockCount' => $lowStockCount,
            'topProducts' => $topProducts,
            'recentOrders' => $recentOrders,
        ]);
    }

    protected function customerDashboard($user)
    {
        $recentOrders = Order::where('user_id', $user->id)->latest()->take(5)->get();
        $needsPaymentCount = Order::where('user_id', $user->id)->where('payment_status', 'pending')->count();
        $totalOrdersCount = Order::where('user_id', $user->id)->count();
        $completedOrdersCount = Order::where('user_id', $user->id)->where('status', 'completed')->count();

        return view('dashboard', [
            'isAdmin' => false,
            'recentOrders' => $recentOrders,
            'needsPaymentCount' => $needsPaymentCount,
            'totalOrdersCount' => $totalOrdersCount,
            'completedOrdersCount' => $completedOrdersCount,
        ]);
    }
}
