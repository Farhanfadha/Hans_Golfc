@extends('layouts.app')

@section('content')
<style>
    .account-header {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        border-radius: 24px;
        padding: 34px;
        margin-bottom: 24px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.18);
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
    }

    .account-header-left {
        display: flex;
        align-items: center;
        gap: 18px;
    }

    .account-avatar {
        width: 64px;
        height: 64px;
        min-width: 64px;
        border-radius: 50%;
        background: linear-gradient(135deg, #facc15, #eab308);
        color: #111827;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 26px;
        font-weight: 900;
        border: 3px solid rgba(255,255,255,0.18);
    }

    .account-title {
        font-size: 26px;
        font-weight: 900;
        margin-bottom: 4px;
    }

    .account-subtitle {
        color: rgba(255,255,255,0.72);
        margin-bottom: 0;
        font-size: 14px;
    }

    .role-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 8px 18px;
        border-radius: 999px;
        font-weight: 800;
        font-size: 13px;
        white-space: nowrap;
    }

    .role-badge-admin {
        background: #fffbeb;
        color: #b45309;
        border: 1px solid #fde68a;
    }

    .role-badge-user {
        background: #ecfdf3;
        color: #166534;
        border: 1px solid #bbf7d0;
    }

    .account-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 20px;
        padding: 26px;
        margin-bottom: 20px;
        box-shadow: 0 10px 26px rgba(15, 23, 42, 0.05);
    }

    .account-card h5 {
        font-weight: 800;
        color: #0f172a;
        font-size: 17px;
        margin-bottom: 16px;
    }

    .account-meta {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }

    .meta-box {
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        padding: 13px 15px;
    }

    .meta-label {
        color: #64748b;
        font-size: 12px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        margin-bottom: 3px;
    }

    .meta-value {
        color: #0f172a;
        font-weight: 700;
        font-size: 14px;
        word-break: break-word;
    }

    .quick-links a {
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 10px;
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 13px 16px;
        font-weight: 700;
        font-size: 14px;
        color: #0f172a;
        margin-bottom: 10px;
        transition: 0.2s;
    }

    .quick-links a:last-child {
        margin-bottom: 0;
    }

    .quick-links a:hover {
        background: #fffbeb;
        border-color: #fde68a;
        transform: translateY(-1px);
    }

    .account-section-title {
        font-weight: 800;
        color: #0f172a;
        font-size: 17px;
        margin-bottom: 4px;
    }

    .account-section-desc {
        color: #64748b;
        font-size: 13px;
    }

    @media (max-width: 575.98px) {
        .account-header {
            padding: 26px 22px;
        }

        .account-title {
            font-size: 22px;
        }

        .account-card {
            padding: 20px;
        }
    }
</style>

<div class="account-header">
    <div class="account-header-left">
        <div class="account-avatar">{{ strtoupper(substr($user->name, 0, 1)) }}</div>
        <div>
            <div class="account-title">Akun Saya</div>
            <p class="account-subtitle">Kelola informasi profil, keamanan, dan akses cepat Anda.</p>
        </div>
    </div>
    <div>
        @if(auth()->user()->role === 'admin')
            <span class="role-badge role-badge-admin">🛡️ Administrator</span>
        @else
            <span class="role-badge role-badge-user">⛳ Pelanggan</span>
        @endif
    </div>
</div>

<div class="row">
    <div class="col-lg-4 mb-4">
        <div class="account-card">
            <h5>Ringkasan Akun</h5>
            <div class="account-meta">
                <div class="meta-box">
                    <div class="meta-label">Nama</div>
                    <div class="meta-value">{{ $user->name }}</div>
                </div>
                <div class="meta-box">
                    <div class="meta-label">Email</div>
                    <div class="meta-value">{{ $user->email }}</div>
                </div>
                <div class="meta-box">
                    <div class="meta-label">Role</div>
                    <div class="meta-value">{{ $user->role === 'admin' ? 'Administrator' : 'Pelanggan' }}</div>
                </div>
            </div>
        </div>

        <div class="account-card">
            <h5>Akses Cepat</h5>
            <div class="quick-links">
                @if(auth()->user()->role === 'admin')
                    <a href="{{ route('admin.orders.index') }}">📦 Kelola Pesanan</a>
                    <a href="{{ route('admin.products.index') }}">🏌️ Kelola Produk</a>
                    <a href="{{ route('admin.categories.index') }}">🗂️ Kelola Kategori</a>
                    <a href="{{ route('admin.chats.index') }}">💬 Chat Pelanggan</a>
                @else
                    <a href="{{ route('orders.index') }}">📦 Pesanan Saya</a>
                    <a href="{{ route('cart.index') }}">🛒 Keranjang</a>
                    <a href="{{ route('chat.index') }}">💬 Chat dengan Admin</a>
                @endif
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="account-card">
            @include('profile.partials.update-profile-information-form')
        </div>

        <div class="account-card">
            @include('profile.partials.update-password-form')
        </div>

        <div class="account-card">
            @include('profile.partials.delete-user-form')
        </div>
    </div>
</div>
@endsection
