<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;
use Illuminate\Http\Request;

class Authenticate extends Middleware
{
    /**
     * Redirect user yang belum login ke halaman login.
     */
    protected function redirectTo(Request $request): ?string
    {
        if (! $request->expectsJson()) {
            session()->flash('warning', 'Silakan login terlebih dahulu untuk melanjutkan.');
            return route('login');
        }

        return null;
    }
}