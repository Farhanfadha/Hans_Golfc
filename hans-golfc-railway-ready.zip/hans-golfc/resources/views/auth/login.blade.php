<x-guest-layout>
    <style>
        .login-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            position: relative;
            overflow: hidden;
        }

        .login-page::before {
            content: "";
            position: fixed;
            inset: 0;
            background:
                linear-gradient(rgba(15, 23, 42, 0.58), rgba(15, 23, 42, 0.74)),
                url('https://images.unsplash.com/photo-1535131749006-b7f58c99034b?auto=format&fit=crop&w=1600&q=80');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            z-index: 0;
        }

        .login-page::after {
            content: "";
            position: fixed;
            inset: 0;
            background:
                radial-gradient(circle at top right, rgba(250, 204, 21, 0.10), transparent 24%),
                radial-gradient(circle at bottom left, rgba(34, 197, 94, 0.08), transparent 30%);
            z-index: 0;
            pointer-events: none;
        }

        .login-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 1040px;
            animation: fadeUp 0.6s ease;
        }

        .login-card {
            display: grid;
            grid-template-columns: 1fr 1fr;
            border-radius: 30px;
            overflow: hidden;
            background: rgba(255, 255, 255, 0.97);
            box-shadow: 0 30px 70px rgba(0, 0, 0, 0.22);
            min-height: 620px;
        }

        .login-left {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: white;
            padding: 56px 48px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
        }

        .login-left::before {
            content: "";
            position: absolute;
            top: -60px;
            right: -60px;
            width: 220px;
            height: 220px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(250, 204, 21, 0.16), transparent 70%);
        }

        .left-content {
            position: relative;
            z-index: 1;
        }

        .brand-badge {
            display: inline-block;
            padding: 8px 14px;
            border-radius: 999px;
            background: rgba(255,255,255,0.10);
            color: #fde68a;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 18px;
        }

        .brand-title {
            font-size: 48px;
            font-weight: 800;
            line-height: 1.05;
            margin-bottom: 16px;
        }

        .brand-subtitle {
            font-size: 17px;
            line-height: 1.8;
            color: #cbd5e1;
            max-width: 430px;
            margin-bottom: 28px;
        }

        .feature-list {
            display: grid;
            gap: 14px;
            max-width: 430px;
        }

        .feature-box {
            padding: 16px 18px;
            border-radius: 18px;
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.08);
            transition: 0.25s ease;
        }

        .feature-box:hover {
            transform: translateY(-2px);
            background: rgba(255,255,255,0.11);
        }

        .feature-box strong {
            display: block;
            font-size: 16px;
            margin-bottom: 4px;
        }

        .feature-box span {
            color: #cbd5e1;
            font-size: 14px;
        }

        .login-right {
            padding: 56px 48px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .form-badge {
            display: inline-block;
            padding: 8px 13px;
            border-radius: 999px;
            background: #f8fafc;
            color: #0f172a;
            font-size: 12px;
            font-weight: 800;
            border: 1px solid #e2e8f0;
            margin-bottom: 14px;
        }

        .form-title {
            font-size: 34px;
            font-weight: 800;
            color: #0f172a;
            margin-bottom: 8px;
        }

        .form-subtitle {
            color: #64748b;
            font-size: 15px;
            margin-bottom: 28px;
        }

        .field-label {
            display: block;
            font-size: 14px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 8px;
        }

        .input-modern {
            width: 100%;
            min-height: 54px;
            border-radius: 15px;
            border: 1px solid #dbe3ec;
            background: #fff;
            padding: 12px 16px;
            color: #0f172a;
            transition: 0.2s ease;
            margin-bottom: 14px;
        }

        .input-modern:focus {
            outline: none;
            border-color: #94a3b8;
            box-shadow: 0 0 0 0.2rem rgba(148, 163, 184, 0.15);
        }

        .remember-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 4px;
            margin-bottom: 22px;
        }

        .remember-check {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .remember-check label {
            font-size: 14px;
            color: #475569;
            margin: 0;
        }

        .forgot-link {
            font-size: 14px;
            color: #475569;
            text-decoration: none;
        }

        .forgot-link:hover {
            color: #0f172a;
            text-decoration: underline;
        }

        .btn-login-modern {
            width: 100%;
            min-height: 56px;
            border-radius: 15px;
            border: none;
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: white;
            font-weight: 800;
            font-size: 15px;
            transition: 0.2s ease;
            box-shadow: 0 10px 25px rgba(15, 23, 42, 0.20);
        }

        .btn-login-modern:hover {
            background: linear-gradient(135deg, #111827, #334155);
            color: white;
            transform: translateY(-1px);
        }

        .register-switch {
            margin-top: 18px;
            text-align: center;
            font-size: 14px;
            color: #64748b;
        }

        .register-switch a {
            color: #0f172a;
            font-weight: 700;
            text-decoration: none;
        }

        .register-switch a:hover {
            text-decoration: underline;
        }

        .custom-status {
            margin-bottom: 16px;
            border-radius: 16px;
            background: #ecfdf3;
            color: #166534;
            padding: 14px 16px;
            border: 1px solid #bbf7d0;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 10px 25px rgba(22, 101, 52, 0.08);
            animation: fadeIn 0.5s ease;
        }

        .custom-success-toast {
            margin-bottom: 18px;
            border-radius: 18px;
            background: linear-gradient(135deg, #dcfce7, #f0fdf4);
            color: #166534;
            padding: 14px 18px;
            border: 1px solid #bbf7d0;
            font-size: 14px;
            font-weight: 700;
            box-shadow: 0 12px 28px rgba(34, 197, 94, 0.12);
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeInDown 0.6s ease;
        }

        .custom-warning-toast {
            margin-bottom: 18px;
            border-radius: 18px;
            background: linear-gradient(135deg, #fef3c7, #fffbeb);
            color: #92400e;
            padding: 14px 18px;
            border: 1px solid #fde68a;
            font-size: 14px;
            font-weight: 700;
            box-shadow: 0 12px 28px rgba(245, 158, 11, 0.14);
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeInDown 0.6s ease;
        }

        .toast-icon {
            width: 30px;
            height: 30px;
            border-radius: 999px;
            background: #16a34a;
            color: white;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }

        .toast-icon.warning {
            background: #f59e0b;
            color: white;
        }

        .custom-errors {
            margin-top: -6px;
            margin-bottom: 10px;
            color: #b91c1c;
            font-size: 13px;
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(18px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-12px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        @media (max-width: 991.98px) {
            .login-card {
                grid-template-columns: 1fr;
                min-height: auto;
            }

            .login-left,
            .login-right {
                padding: 36px 28px;
            }

            .brand-title {
                font-size: 36px;
            }

            .form-title {
                font-size: 28px;
            }
        }

        @media (max-width: 575.98px) {
            .login-page {
                padding: 16px;
            }

            .brand-title {
                font-size: 30px;
            }

            .form-title {
                font-size: 24px;
            }
        }
    </style>

    <div class="login-page">
        <div class="login-wrapper">
            <div class="login-card">
                <div class="login-left">
                    <div class="left-content">
                        <span class="brand-badge">Hans Golf Access</span>
                        <h1 class="brand-title">Masuk ke Hans Golf</h1>
                        <p class="brand-subtitle">
                            Belanja perlengkapan golf premium dengan pengalaman yang cepat, nyaman, dan modern.
                        </p>

                        <div class="feature-list">
                            <div class="feature-box">
                                <strong>Belanja Mudah</strong>
                                <span>Akses akun dan lanjutkan pesanan Anda dengan cepat.</span>
                            </div>

                            <div class="feature-box">
                                <strong>Tampilan Premium</strong>
                                <span>Desain modern yang selaras dengan identitas Hans Golf.</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="login-right">
                    <span class="form-badge">Secure Login</span>
                    <h2 class="form-title">Welcome Back</h2>
                    <p class="form-subtitle">
                        Masukkan email dan password untuk melanjutkan.
                    </p>

                    @if(session('success'))
                        <div class="custom-success-toast">
                            <span class="toast-icon">✓</span>
                            <span>{{ session('success') }}</span>
                        </div>
                    @endif

                    @if(request('from') == 'cart')
                        <div class="custom-warning-toast">
                            <span class="toast-icon warning">!</span>
                            <span>Login dulu untuk menambahkan produk ke keranjang.</span>
                        </div>
                    @endif

                    @if(session('warning'))
                        <div class="custom-warning-toast">
                            <span class="toast-icon warning">!</span>
                            <span>{{ session('warning') }}</span>
                        </div>
                    @endif

                    @if (session('status'))
                        <div class="custom-status">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <div>
                            <label for="email" class="field-label">Email</label>
                            <input id="email"
                                   class="input-modern"
                                   type="email"
                                   name="email"
                                   value="{{ old('email') }}"
                                   required
                                   autofocus
                                   autocomplete="username">
                            <x-input-error :messages="$errors->get('email')" class="custom-errors" />
                        </div>

                        <div>
                            <label for="password" class="field-label">Password</label>
                            <input id="password"
                                   class="input-modern"
                                   type="password"
                                   name="password"
                                   required
                                   autocomplete="current-password">
                            <x-input-error :messages="$errors->get('password')" class="custom-errors" />
                        </div>

                        <div class="remember-row">
                            <div class="remember-check">
                                <input id="remember_me" type="checkbox" name="remember">
                                <label for="remember_me">Remember me</label>
                            </div>

                            @if (Route::has('password.request'))
                                <a class="forgot-link" href="{{ route('password.request') }}">
                                    Forgot password?
                                </a>
                            @endif
                        </div>

                        <button type="submit" class="btn-login-modern">
                            Log In
                        </button>

                        @if (Route::has('register'))
                            <div class="register-switch">
                                Belum punya akun?
                                <a href="{{ route('register') }}">Register</a>
                            </div>
                        @endif
                    </form>
                </div>
            </div>
        </div>
    </div>
</x-guest-layout>