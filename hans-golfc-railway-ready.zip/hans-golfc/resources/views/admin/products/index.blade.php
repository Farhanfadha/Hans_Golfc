@extends('layouts.app')

@section('content')
<style>
    .admin-page {
        padding-bottom: 50px;
    }

    .admin-hero {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        border-radius: 28px;
        padding: 34px;
        margin-bottom: 24px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.16);
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 18px;
        flex-wrap: wrap;
    }

    .admin-hero h1 {
        font-size: 34px;
        font-weight: 900;
        margin-bottom: 8px;
    }

    .admin-hero p {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .btn-add {
        background: #16a34a;
        color: white;
        border-radius: 14px;
        padding: 12px 18px;
        text-decoration: none;
        font-weight: 900;
        display: inline-block;
    }

    .btn-add:hover {
        background: #15803d;
        color: white;
    }

    .admin-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 24px;
        padding: 24px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
    }

    .table-modern {
        margin-bottom: 0;
    }

    .table-modern thead th {
        color: #64748b;
        font-size: 13px;
        text-transform: uppercase;
        border-bottom: 1px solid #e5e7eb;
        white-space: nowrap;
    }

    .table-modern tbody td {
        vertical-align: middle;
        font-weight: 600;
    }

    .product-thumb {
        width: 72px;
        height: 72px;
        border-radius: 18px;
        object-fit: cover;
        border: 1px solid #e5e7eb;
        background: #f8fafc;
    }

    .product-placeholder {
        width: 72px;
        height: 72px;
        border-radius: 18px;
        background: #f1f5f9;
        border: 1px solid #e5e7eb;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #64748b;
        font-size: 26px;
    }

    .product-name {
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 4px;
    }

    .product-slug {
        color: #64748b;
        font-size: 13px;
    }

    .price-text {
        color: #ca8a04;
        font-weight: 900;
        white-space: nowrap;
    }

    .status-badge {
        display: inline-block;
        padding: 7px 12px;
        border-radius: 999px;
        font-size: 12px;
        font-weight: 900;
        white-space: nowrap;
    }

    .badge-green {
        background: #dcfce7;
        color: #166534;
    }

    .badge-red {
        background: #fee2e2;
        color: #991b1b;
    }

    .badge-yellow {
        background: #fef3c7;
        color: #92400e;
    }

    .badge-blue {
        background: #dbeafe;
        color: #1e40af;
    }

    .badge-muted {
        background: #f1f5f9;
        color: #334155;
    }

    .btn-action {
        border: none;
        border-radius: 12px;
        padding: 9px 13px;
        font-weight: 800;
        text-decoration: none;
        display: inline-block;
        font-size: 14px;
    }

    .btn-edit {
        background: #dbeafe;
        color: #1e40af;
    }

    .btn-edit:hover {
        background: #bfdbfe;
        color: #1e40af;
    }

    .btn-delete {
        background: #fee2e2;
        color: #991b1b;
    }

    .btn-delete:hover {
        background: #fecaca;
        color: #991b1b;
    }

    .empty-box {
        text-align: center;
        padding: 42px;
        color: #64748b;
    }
</style>

<div class="container admin-page">
    <div class="admin-hero">
        <div>
            <h1>Kelola Produk</h1>
            <p>Tambah, edit, dan atur produk yang tampil di katalog Hans Golf.</p>
        </div>

        <a href="{{ route('admin.products.create') }}" class="btn-add">
            + Tambah Produk
        </a>
    </div>

    @if(session('success'))
        <div class="alert alert-success mb-4">
            {{ session('success') }}
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger mb-4">
            {{ session('error') }}
        </div>
    @endif

    <div class="admin-card">
        <div class="table-responsive">
            <table class="table table-modern align-middle">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Kondisi</th>
                        <th>Status</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>

                <tbody>
                    @forelse($products as $product)
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-3">
                                    @if($product->image)
                                        <img src="{{ asset('storage/' . $product->image) }}"
                                             alt="{{ $product->name }}"
                                             class="product-thumb">
                                    @else
                                        <div class="product-placeholder">🏌️</div>
                                    @endif

                                    <div>
                                        <div class="product-name">{{ $product->name }}</div>
                                        <div class="product-slug">{{ $product->slug }}</div>
                                    </div>
                                </div>
                            </td>

                            <td>{{ optional($product->category)->name ?? '-' }}</td>

                            <td>
                                <span class="price-text">
                                    Rp {{ number_format($product->price, 0, ',', '.') }}
                                </span>
                            </td>

                            <td>
                                @if($product->stock > 10)
                                    <span class="status-badge badge-green">{{ $product->stock }} stok</span>
                                @elseif($product->stock > 0)
                                    <span class="status-badge badge-yellow">{{ $product->stock }} stok</span>
                                @else
                                    <span class="status-badge badge-red">Habis</span>
                                @endif
                            </td>

                            <td>
                                <span class="status-badge badge-blue">
                                    {{ $product->condition ?? 'Baru' }}
                                </span>
                            </td>

                            <td>
                                @if($product->is_active)
                                    <span class="status-badge badge-green">Aktif</span>
                                @else
                                    <span class="status-badge badge-red">Tidak Aktif</span>
                                @endif
                            </td>

                            <td class="text-end">
                                <a href="{{ route('admin.products.edit', $product->id) }}" class="btn-action btn-edit">
                                    Edit
                                </a>

                                <form action="{{ route('admin.products.destroy', $product->id) }}"
                                      method="POST"
                                      class="d-inline"
                                      onsubmit="return confirm('Yakin ingin menghapus produk ini?')">
                                    @csrf
                                    @method('DELETE')

                                    <button type="submit" class="btn-action btn-delete">
                                        Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7">
                                <div class="empty-box">
                                    Belum ada produk.
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection