<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    const SHIPPING_COST = 15000;
    const SHIPPING_COURIER = 'Anter Aja';

    public function index()
    {
        $cart = session()->get('cart', []);

        return view('cart.index', compact('cart'));
    }

    public function add(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $cart = session()->get('cart', []);

        $currentQty = isset($cart[$id]) ? $cart[$id]['quantity'] : 0;

        if ($currentQty + 1 > $product->stock) {
            return redirect()->back()->with('error', 'Stok "' . $product->name . '" tidak mencukupi. Sisa stok: ' . $product->stock . '.');
        }

        if (isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                'id' => $product->id,
                'name' => $product->name,
                'price' => $product->price,
                'image' => $product->image,
                'quantity' => 1,
            ];
        }

        session()->put('cart', $cart);

        return redirect()->route('cart.index')->with('success', 'Produk berhasil ditambahkan ke keranjang.');
    }

    public function update(Request $request, $id)
    {
        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            $product = Product::find($id);
            $quantity = max(1, (int) $request->quantity);

            if ($product && $quantity > $product->stock) {
                $quantity = $product->stock > 0 ? $product->stock : 1;
                session()->flash('error', 'Jumlah disesuaikan karena stok "' . $product->name . '" hanya tersisa ' . $product->stock . '.');
            }

            $cart[$id]['quantity'] = $quantity;
            session()->put('cart', $cart);
        }

        return redirect()->route('cart.index')->with('success', 'Keranjang berhasil diperbarui.');
    }

    public function remove($id)
    {
        $cart = session()->get('cart', []);

        if (isset($cart[$id])) {
            unset($cart[$id]);
            session()->put('cart', $cart);
        }

        return redirect()->route('cart.index')->with('success', 'Produk berhasil dihapus dari keranjang.');
    }

    public function checkout()
    {
        $cart = session()->get('cart', []);

        if (count($cart) == 0) {
            return redirect()->route('cart.index')->with('success', 'Keranjang masih kosong.');
        }

        $shippingCost = self::SHIPPING_COST;
        $shippingCourier = self::SHIPPING_COURIER;

        return view('cart.checkout', compact('cart', 'shippingCost', 'shippingCourier'));
    }

    public function processCheckout(Request $request)
    {
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_phone' => 'required|string|max:50',
            'customer_address' => 'required|string',
            'note' => 'nullable|string',
        ]);

        $cart = session()->get('cart', []);

        if (count($cart) == 0) {
            return redirect()->route('cart.index')->with('success', 'Keranjang masih kosong.');
        }

        try {
            $order = DB::transaction(function () use ($request, $cart) {
                $total = 0;

                foreach ($cart as $item) {
                    // Kunci baris produk supaya tidak terjadi race condition
                    // kalau ada 2 customer checkout barang yang sama bersamaan.
                    $product = Product::where('id', $item['id'])->lockForUpdate()->first();

                    if (! $product || $product->stock < $item['quantity']) {
                        throw new \RuntimeException(
                            'Stok "' . ($product->name ?? $item['name']) . '" tidak mencukupi. Sisa stok: ' . ($product->stock ?? 0) . '.'
                        );
                    }

                    $total += $item['price'] * $item['quantity'];
                }

                $shippingCost = self::SHIPPING_COST;
                $total += $shippingCost;

                $order = Order::create([
                    'user_id' => auth()->id(),
                    'order_code' => 'ORD-' . strtoupper(Str::random(8)),
                    'customer_name' => $request->customer_name,
                    'customer_phone' => $request->customer_phone,
                    'customer_address' => $request->customer_address,
                    'note' => $request->note,
                    'total_price' => $total,
                    'status' => 'new',
                    'payment_status' => 'pending',
                    'shipping_service' => 'reguler',
                    'shipping_courier' => self::SHIPPING_COURIER,
                    'shipping_cost' => $shippingCost,
                ]);

                foreach ($cart as $item) {
                    OrderItem::create([
                        'order_id' => $order->id,
                        'product_id' => $item['id'],
                        'product_name' => $item['name'],
                        'price' => $item['price'],
                        'quantity' => $item['quantity'],
                        'subtotal' => $item['price'] * $item['quantity'],
                    ]);

                    // Potong stok produk.
                    Product::where('id', $item['id'])->decrement('stock', $item['quantity']);
                }

                return $order;
            });
        } catch (\RuntimeException $e) {
            return redirect()->route('cart.index')->with('error', $e->getMessage());
        }

        session()->forget('cart');

        return redirect()->route('cart.success', $order->id);
    }

    public function success($id)
    {
        $order = Order::with('items')
            ->where('user_id', auth()->id())
            ->findOrFail($id);

        return view('cart.success', compact('order'));
    }

    public function uploadPaymentProof(Request $request, $id)
    {
        $order = Order::where('user_id', auth()->id())->findOrFail($id);

        if ($order->payment_status === 'paid') {
            return back()->with('error', 'Pembayaran pesanan ini sudah dikonfirmasi.');
        }

        $request->validate([
            'sender_name' => 'required|string|max:255',
            'payment_proof' => 'required|file|mimes:jpg,jpeg,png,webp,pdf|max:2048',
        ], [
            'sender_name.required' => 'Nama pengirim wajib diisi.',
            'payment_proof.required' => 'Bukti transfer wajib diupload.',
            'payment_proof.mimes' => 'Bukti transfer harus berupa JPG, JPEG, PNG, WEBP, atau PDF.',
            'payment_proof.max' => 'Ukuran bukti transfer maksimal 2 MB.',
        ]);

        if ($order->payment_proof) {
            Storage::disk('public')->delete($order->payment_proof);
        }

        $path = $request->file('payment_proof')->store('payment-proofs', 'public');

        $order->update([
            'sender_name' => $request->sender_name,
            'payment_proof' => $path,
            'payment_status' => 'waiting_confirmation',
        ]);

        return back()->with('success', 'Bukti transfer berhasil diupload. Pembayaran Anda sedang menunggu konfirmasi admin.');
    }
}
