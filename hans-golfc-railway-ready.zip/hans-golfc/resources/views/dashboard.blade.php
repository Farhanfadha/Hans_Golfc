@extends('layouts.app')

@section('content')
<style>
    .dash-page {
        padding-bottom: 50px;
    }

    .dash-hero {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        color: white;
        border-radius: 28px;
        padding: 34px;
        margin-bottom: 24px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.16);
    }

    .dash-hero h1 {
        font-size: 32px;
        font-weight: 900;
        margin-bottom: 6px;
    }

    .dash-hero p {
        color: #cbd5e1;
        margin-bottom: 0;
    }

    .stat-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
        margin-bottom: 24px;
    }

    .stat-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 20px;
        padding: 20px;
        box-shadow: 0 10px 26px rgba(15, 23, 42, 0.05);
    }

    .stat-label {
        color: #64748b;
        font-size: 13px;
        font-weight: 800;
        text-transform: uppercase;
        margin-bottom: 8px;
    }

    .stat-value {
        color: #0f172a;
        font-size: 26px;
        font-weight: 900;
    }

    .stat-card.warn .stat-value {
        color: #b45309;
    }

    .dash-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 24px;
        padding: 24px;
        box-shadow: 0 12px 28px rgba(15, 23, 42, 0.06);
        margin-bottom: 20px;
    }

    .dash-card h2 {
        font-size: 20px;
        font-weight: 900;
        color: #0f172a;
        margin-bottom: 18px;
    }

    .top-product-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 0;
        border-bottom: 1px solid #f1f5f9;
    }

    .top-product-row:last-child {
        border-bottom: none;
    }

    .top-product-name {
        font-weight: 700;
        color: #0f172a;
    }

    .top-product-qty {
        background: #ecfdf3;
        color: #166534;
        padding: 5px 12px;
        border-radius: 999px;
        font-weight: 800;
        font-size: 13px;
        white-space: nowrap;
    }

    .table-modern thead th {
        color: #64748b;
        font-size: 13px;
        text-transform: uppercase;
        border-bottom: 1px solid #e5e7eb;
        white-space: nowrap;
    }

    .table-modern tbody td {
        vertical-align: middle;
        font-weight: 600;
    }

    .badge-muted { background: #f1f5f9; color: #475569; padding: 6px 12px; border-radius: 999px; font-weight: 800; font-size: 12px; }
    .badge-blue { background: #dbeafe; color: #1e40af; padding: 6px 12px; border-radius: 999px; font-weight: 800; font-size: 12px; }
    .badge-green { background: #dcfce7; color: #166534; padding: 6px 12px; border-radius: 999px; font-weight: 800; font-size: 12px; }
    .badge-red { background: #fee2e2; color: #991b1b; padding: 6px 12px; border-radius: 999px; font-weight: 800; font-size: 12px; }

    .empty-box {
        text-align: center;
        padding: 30px;
        color: #64748b;
    }

    .quick-links a {
        text-decoration: none;
        display: block;
        background: #f8fafc;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        padding: 13px 16px;
        font-weight: 700;
        font-size: 14px;
        color: #0f172a;
        margin-bottom: 10px;
        transition: 0.2s;
    }

    .quick-links a:last-child { margin-bottom: 0; }

    .quick-links a:hover {
        background: #fffbeb;
        border-color: #fde68a;
        transform: translateY(-1px);
    }
</style>

<div class="container dash-page">
    <div class="dash-hero">
        <h1>Halo, {{ auth()->user()->name }} 👋</h1>
        <p>
            @if($isAdmin)
                Ringkasan performa toko Hans Golf hari ini.
            @else
                Selamat datang kembali di Hans Golf.
            @endif
        </p>
    </div>

    @if($isAdmin)
        {{-- ================= ADMIN DASHBOARD ================= --}}
        <div class="stat-grid">
            <div class="stat-card">
                <div class="stat-label">Penjualan Bulan Ini</div>
                <div class="stat-value">Rp {{ number_format($salesThisMonth, 0, ',', '.') }}</div>
            </div>

            <div class="stat-card">
                <div class="stat-label">Pesanan Baru</div>
                <div class="stat-value">{{ $newOrdersCount }}</div>
            </div>

            <div class="stat-card {{ $waitingConfirmationCount > 0 ? 'warn' : '' }}">
                <div class="stat-label">Menunggu Konfirmasi Bayar</div>
                <div class="stat-value">{{ $waitingConfirmationCount }}</div>
            </div>

            <div class="stat-card">
                <div class="stat-label">Total Produk</div>
                <div class="stat-value">{{ $totalProducts }}</div>
            </div>

            <div class="stat-card {{ $lowStockCount > 0 ? 'warn' : '' }}">
                <div class="stat-label">Stok Menipis (&le;3)</div>
                <div class="stat-value">{{ $lowStockCount }}</div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-5 mb-4">
                <div class="dash-card">
                    <h2>Produk Terlaris</h2>

                    @forelse($topProducts as $product)
                        <div class="top-product-row">
                            <span class="top-product-name">{{ $product->product_name }}</span>
                            <span class="top-product-qty">{{ $product->total_qty }} terjual</span>
                        </div>
                    @empty
                        <div class="empty-box">Belum ada penjualan.</div>
                    @endforelse
                </div>

                <div class="dash-card">
                    <h2>Akses Cepat</h2>
                    <div class="quick-links">
                        <a href="{{ route('admin.orders.index') }}">📦 Kelola Pesanan</a>
                        <a href="{{ route('admin.products.index') }}">🏌️ Kelola Produk</a>
                        <a href="{{ route('admin.categories.index') }}">🗂️ Kelola Kategori</a>
                        <a href="{{ route('admin.chats.index') }}">💬 Chat Pelanggan</a>
                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="dash-card">
                    <h2>Pesanan Terbaru</h2>

                    @php
                        $orderStatusLabels = [
                            'new' => 'Order Baru',
                            'processing' => 'Diproses',
                            'completed' => 'Selesai',
                            'cancelled' => 'Dibatalkan',
                        ];

                        $orderStatusClasses = [
                            'new' => 'badge-muted',
                            'processing' => 'badge-blue',
                            'completed' => 'badge-green',
                            'cancelled' => 'badge-red',
                        ];
                    @endphp

                    <div class="table-responsive">
                        <table class="table table-modern align-middle">
                            <thead>
                                <tr>
                                    <th>Kode</th>
                                    <th>Customer</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($recentOrders as $order)
                                    <tr>
                                        <td>{{ $order->order_code }}</td>
                                        <td>{{ $order->customer_name }}</td>
                                        <td>Rp {{ number_format($order->total_price, 0, ',', '.') }}</td>
                                        <td>
                                            <span class="{{ $orderStatusClasses[$order->status] ?? 'badge-muted' }}">
                                                {{ $orderStatusLabels[$order->status] ?? $order->status }}
                                            </span>
                                        </td>
                                        <td>
                                            <a href="{{ route('admin.orders.show', $order->id) }}">Lihat</a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">
                                            <div class="empty-box">Belum ada pesanan masuk.</div>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    @else
        {{-- ================= CUSTOMER DASHBOARD ================= --}}
        <div class="stat-grid">
            <div class="stat-card">
                <div class="stat-label">Total Pesanan</div>
                <div class="stat-value">{{ $totalOrdersCount }}</div>
            </div>

            <div class="stat-card">
                <div class="stat-label">Pesanan Selesai</div>
                <div class="stat-value">{{ $completedOrdersCount }}</div>
            </div>

            <div class="stat-card {{ $needsPaymentCount > 0 ? 'warn' : '' }}">
                <div class="stat-label">Perlu Dibayar</div>
                <div class="stat-value">{{ $needsPaymentCount }}</div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="dash-card">
                    <h2>Akses Cepat</h2>
                    <div class="quick-links">
                        <a href="{{ route('products.index') }}">🏌️ Belanja Produk</a>
                        <a href="{{ route('cart.index') }}">🛒 Keranjang</a>
                        <a href="{{ route('orders.index') }}">📦 Pesanan Saya</a>
                        <a href="{{ route('profile.edit') }}">👤 Akun Saya</a>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="dash-card">
                    <h2>Pesanan Terbaru</h2>

                    @php
                        $orderStatusLabels = [
                            'new' => 'Order Baru',
                            'processing' => 'Diproses',
                            'completed' => 'Selesai',
                            'cancelled' => 'Dibatalkan',
                        ];

                        $orderStatusClasses = [
                            'new' => 'badge-muted',
                            'processing' => 'badge-blue',
                            'completed' => 'badge-green',
                            'cancelled' => 'badge-red',
                        ];
                    @endphp

                    @forelse($recentOrders as $order)
                        <div class="top-product-row">
                            <div>
                                <div class="top-product-name">{{ $order->order_code }}</div>
                                <div style="color:#64748b; font-size:13px;">Rp {{ number_format($order->total_price, 0, ',', '.') }}</div>
                            </div>
                            <div class="d-flex align-items-center gap-2">
                                <span class="{{ $orderStatusClasses[$order->status] ?? 'badge-muted' }}">
                                    {{ $orderStatusLabels[$order->status] ?? $order->status }}
                                </span>
                                <a href="{{ route('orders.show', $order->id) }}">Lihat</a>
                            </div>
                        </div>
                    @empty
                        <div class="empty-box">Belum ada pesanan. Yuk mulai belanja!</div>
                    @endforelse
                </div>
            </div>
        </div>
    @endif
</div>
@endsection
