<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Chat;
use App\Models\ChatMessage;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function index()
    {
        $chats = Chat::with(['user', 'messages' => function ($query) {
                $query->latest();
            }])
            ->withCount([
                'messages as unread_admin_count' => function ($query) {
                    $query->where('sender_type', 'user')
                        ->where('is_read_admin', false);
                }
            ])
            ->latest()
            ->get();

        return view('admin.chats.index', compact('chats'));
    }

    public function show(Chat $chat)
    {
        ChatMessage::where('chat_id', $chat->id)
            ->where('sender_type', 'user')
            ->where('is_read_admin', false)
            ->update([
                'is_read_admin' => true,
            ]);

        $chat->load('user');

        $messages = $chat->messages()
            ->oldest()
            ->get();

        return view('admin.chats.show', compact('chat', 'messages'));
    }

    public function send(Request $request, Chat $chat)
    {
        $request->validate([
            'message' => 'required|string|max:2000',
        ]);

        ChatMessage::create([
            'chat_id' => $chat->id,
            'sender_type' => 'admin',
            'message' => $request->message,
            'is_read_admin' => true,
            'is_read_user' => false,
        ]);

        return redirect()->route('admin.chats.show', $chat->id)
            ->with('success', 'Balasan berhasil dikirim.');
    }
}